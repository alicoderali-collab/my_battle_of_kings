// ============================================================
// ⚔️ BATTLE OF KINGS - js/helpers.js (v9 - MASTER FINAL)
// ============================================================

const _isPlainObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const _isBadKey = (k) => k === '__proto__' || k === 'constructor' || k === 'prototype';

let isProcessing = false;
let lastActionTime = 0;
const ACTION_COOLDOWN_MS = 50;
let currentBuilding = null;
let isLoadingScreenActive = false;
let currentCraftItem = null;
let currentCraftQty = 1;
let currentCraftType = null;
let cancelArm = { smith: 0, lumber: 0 };
let profileConfirmArm = 0;
let profileConfirmId = null;
let lastNotifKey = '';
let toastTimer = null;
let audioCtxSFX = null;
let currentShopTab = 'resources';
let currentSpeedupTarget = null;
let _txDepth = 0;
const FORBIDDEN_KEYS = new Set(['__proto__', 'constructor', 'prototype']);

function safeNum(n, fallback = 0) {
  if (typeof n !== 'number') n = Number(n);
  if (!isFinite(n) || isNaN(n) || n < 0) return fallback;
  return n;
}
function safeInt(n, fallback = 0) { return Math.floor(safeNum(n, fallback)); }
function safeString(s, fallback = '') { return (s == null) ? fallback : String(s); }

function acquireLock() {
  const now = Date.now();
  if (isProcessing || (now - lastActionTime) < ACTION_COOLDOWN_MS) return false;
  isProcessing = true; lastActionTime = now; return true;
}
function releaseLock() { isProcessing = false; }

function takeSnapshot() {
  if (typeof state === 'undefined' || !state || typeof state !== 'object') return null;
  try { return JSON.parse(JSON.stringify(state)); } catch (e) { return null; }
}
function restoreSnapshot(snap) {
  if (typeof state === 'undefined' || !state || !snap) return;
  const snapKeys = Object.keys(snap);
  for (const key of Object.keys(state)) {
    if (FORBIDDEN_KEYS.has(key)) continue;
    if (!snapKeys.includes(key)) {
      try { delete state[key]; } catch (e) {}
    }
  }
  for (const key in snap) {
    if (FORBIDDEN_KEYS.has(key)) continue;
    try { state[key] = snap[key]; } catch (e) {}
  }
}
function transaction(fn, onRollback) {
  if (typeof fn !== 'function') return undefined;
  if (_txDepth > 0) { _txDepth++; try { return fn(); } finally { _txDepth--; } }
  const snapshot = takeSnapshot();
  _txDepth = 1;
  try {
    const result = fn();
    _txDepth = 0;
    return result;
  } catch (e) {
    if (!(e && /^(insufficient|insufficient funds|no gold|no_res|no_wounded|invalid time|gold spent failed)$/.test(String(e.message)))) {
      console.error('❌ تراکنش شکست خورد، بازگشت:', e);
    }
    try { restoreSnapshot(snapshot); } catch (re) { console.error('Rollback failed:', re); }
    _txDepth = 0;
    if (typeof onRollback === 'function') { try { onRollback(e); } catch (cbErr) {} }
    throw e;
  }
}
function transactionSafe(fn, onRollback) {
  try { return { ok: true, value: transaction(fn, onRollback) }; }
  catch (e) { return { ok: false, error: e }; }
}

window.addEventListener('error', (e) => {
  console.error('خطای پیش‌بینی نشده:', e.error || e.message);
  releaseLock();
});
window.addEventListener('unhandledrejection', (e) => {
  console.error('Promise Rejected:', e.reason);
  releaseLock();
});

const toFa = (n) => { n = safeInt(n, 0); return n.toLocaleString('fa-IR'); };

function escapeHtml(s) {
  if (s == null) return '';
  return String(s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

const faDigits = (n) => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
const pad2 = (n) => faDigits(n).padStart(2, '۰');

const formatTime = (ms) => {
  let total = Math.max(0, Math.ceil(safeNum(ms, 0) / 1000));
  const d = Math.floor(total / 86400); total %= 86400;
  const h = Math.floor(total / 3600); total %= 3600;
  const m = Math.floor(total / 60); const s = total % 60;
  const parts = [];
  if (d) parts.push(`${toFa(d)} روز`);
  if (h || d) parts.push(`${toFa(h)} ساعت`);
  if (m || h || d) parts.push(`${toFa(m)} دقیقه`);
  parts.push(`${toFa(s)} ثانیه`);
  return parts.join('، ');
};

const fmtDur = (ms) => formatTime(ms);

function showToast(msg, type = 'success') {
  const toast = $('toast'); if (!toast) return;
  toast.textContent = safeString(msg);
  toast.classList.toggle('error', type === 'error');
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2500);
}

function playSFX(type = 'click') {
  try {
    if (!audioCtxSFX) audioCtxSFX = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtxSFX.state === 'suspended') audioCtxSFX.resume();
    const osc = audioCtxSFX.createOscillator();
    const gain = audioCtxSFX.createGain();
    osc.connect(gain); gain.connect(audioCtxSFX.destination);
    const now = audioCtxSFX.currentTime;
    if (type === 'click') {
      osc.type = 'sine'; osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(300, now + 0.1);
      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
      osc.start(now); osc.stop(now + 0.1);
    } else if (type === 'success') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(400, now);
      osc.frequency.setValueAtTime(600, now + 0.1);
      osc.frequency.setValueAtTime(800, now + 0.2);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
      osc.start(now); osc.stop(now + 0.3);
    } else if (type === 'error') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(200, now);
      osc.frequency.setValueAtTime(150, now + 0.15);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
      osc.start(now); osc.stop(now + 0.2);
    }
  } catch (e) {}
}

function playSoundFile(filePath, volume = 0.6) {
  try {
    if (typeof filePath !== 'string' || !filePath) return;
    const audio = new Audio(filePath);
    audio.volume = Math.max(0, Math.min(1, Number(volume) || 0.6));
    audio.play().catch(() => {});
  } catch (e) {}
}

function deductResources(costs) {
  if (!costs || typeof costs !== 'object' || Array.isArray(costs)) return false;
  for (const r in costs) {
    if (!Object.prototype.hasOwnProperty.call(costs, r)) continue;
    if (FORBIDDEN_KEYS.has(r)) return false;
    const need = costs[r];
    if (typeof need !== 'number' || !isFinite(need) || need < 0) return false;
    if (need === 0) continue;
    const have = (state[r] !== undefined ? state[r] : ((state.inventory && state.inventory[r]) || 0));
    if (typeof have !== 'number' || !isFinite(have) || have < need) return false;
  }
  for (const r in costs) {
    if (!Object.prototype.hasOwnProperty.call(costs, r)) continue;
    const need = costs[r];
    if (need === 0) continue;
    if (state[r] !== undefined) {
      if (r === 'gold') {
        state.gold -= need;
        if (typeof missionAdd === 'function') missionAdd('spendGold', need);
      } else { state[r] -= need; }
    } else {
      if (!state.inventory) state.inventory = {};
      state.inventory[r] = (state.inventory[r] || 0) - need;
    }
  }
  return true;
}

function spendGold(amount) {
  if (typeof amount !== 'number' || !isFinite(amount) || amount <= 0) return false;
  if (safeNum(state.gold, 0) < amount) return false;
  state.gold -= amount;
  if (typeof missionAdd === 'function') missionAdd('spendGold', amount);
  return true;
}

function xpForLevel(level) {
  level = Math.max(1, Math.min(999, safeInt(level, 1)));
  if (level === 1) return 0;
  return Math.floor(100 * Math.pow(level - 1, 2.5));
}

function getLevelFromXP(xp) {
  xp = Math.max(0, Math.floor(Number(xp) || 0));
  if (!isFinite(xp) || xp <= 0) return 1;
  let level = Math.min(999, Math.floor(Math.pow(xp / 100, 0.4) + 1e-9) + 1);
  while (level > 1 && xpForLevel(level) > xp) level--;
  while (level < 999 && xpForLevel(level + 1) <= xp) level++;
  return Math.max(1, Math.min(999, level));
}

function addXP(amount, isBattle = false) {
  if (typeof amount !== 'number' || !isFinite(amount) || amount <= 0) return 0;
  const buffs = (typeof getAcademyBuffs === 'function') ? getAcademyBuffs() : { xp: 1 };
  const patrolBonus = (isBattle && typeof getPatrolXPBonus === 'function') ? getPatrolXPBonus() : 0;
  const totalMult = safeNum(buffs.xp, 1) * (1 + patrolBonus);
  const boosted = Math.floor(amount * totalMult);
  if (!isFinite(boosted) || boosted <= 0) return 0;
  const before = safeInt(state.player_level, 1);
  state.xp = safeNum(state.xp, 0) + boosted;
  state.player_level = getLevelFromXP(state.xp);
  if (typeof saveGame === 'function') saveGame();
  const gained = state.player_level - before;
  if (gained > 0) {
    state.unopenedLevelChests = Math.min(9999, safeInt(state.unopenedLevelChests, 0) + gained);
    if (typeof updateUI === 'function') updateUI();
    if (typeof showToast === 'function') showToast(`🎉 به سطح ${toFa(state.player_level)} رسیدی! ${toFa(gained)} صندوق جایزه گرفتی!`);
    if (typeof playSoundFile === 'function') playSoundFile('ghost/levelup.mp3', 0.8);
    return state.player_level;
  }
  return 0;
}

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

function checkMissionDay() {
  if (!_isPlainObj(state.missions)) state.missions = { day: '', progress: {}, claimed: {} };
  if (!_isPlainObj(state.missions.progress)) state.missions.progress = {};
  if (!_isPlainObj(state.missions.claimed)) state.missions.claimed = {};
  const key = todayKey();
  if (state.missions.day !== key) {
    state.missions = { day: key, progress: {}, claimed: {} };
    if (typeof saveGame === 'function') saveGame();
    if (typeof updateMissionBadge === 'function') updateMissionBadge();
    const modal = $('missionsModal');
    if (modal && modal.classList.contains('show') && typeof renderMissions === 'function') renderMissions();
  }
}

function missionAdd(id, n = 1) {
  if (typeof checkMissionDay === 'function') checkMissionDay();
  if (typeof id !== 'string' || !id || _isBadKey(id)) return;
  if (typeof n !== 'number' || !isFinite(n) || n <= 0) return;
  const aliases = {
    recruit: ['recruit5'], recruit10: ['recruit5'], upgrade: ['upgrade1','upgrade10'],
    attack: ['pveAttack'], attack3: ['pveAttack'], collectGold: ['collectTax2'],
    smithCraft: ['craft10'], lumberCraft: ['craft10'], spendGold: ['spend2000']
  };
  const targets = aliases[id] || [id];
  if (typeof MISSIONS === 'undefined' || !Array.isArray(MISSIONS)) return;
  if (!_isPlainObj(state.missions)) state.missions = { day: todayKey(), progress: {}, claimed: {} };
  if (!_isPlainObj(state.missions.progress)) state.missions.progress = {};
  targets.forEach(targetId => {
    const m = MISSIONS.find(x => x.id === targetId); if (!m) return;
    const before = safeNum(state.missions.progress[targetId], 0);
    state.missions.progress[targetId] = Math.min(m.target, before + n);
    if (before < m.target && state.missions.progress[targetId] >= m.target) {
      setTimeout(() => { if (typeof showToast === 'function') showToast(`✅ ماموریت کامل شد: ${m.title}`); }, 500);
    }
  });
  if (typeof saveGame === 'function') saveGame();
  if (typeof updateMissionBadge === 'function') updateMissionBadge();
  const modal = $('missionsModal');
  if (modal && modal.classList.contains('show') && typeof renderMissions === 'function') renderMissions();
}

function getMaxArmy(barracksLvl) { barracksLvl = Math.max(1, safeInt(barracksLvl, 1)); return 50 + ((barracksLvl - 1) * 100); }

function getTotalArmyCount() {
  if (!_isPlainObj(state.army)) return 0;
  let count = 0;
  for (const k in state.army) {
    if (!Object.prototype.hasOwnProperty.call(state.army, k)) continue;
    const v = state.army[k];
    if (typeof v === 'number' && isFinite(v) && v > 0) count += v;
  }
  return count;
}

function getUnitPower(unitKey, barracksLvl) {
  if (typeof UNITS_INFO === 'undefined' || !UNITS_INFO) return 0;
  const u = UNITS_INFO[unitKey];
  if (!u || typeof u.power !== 'number') return 0;
  barracksLvl = Math.max(1, safeInt(barracksLvl, 1));
  return Math.floor(u.power * (1 + (barracksLvl - 1) * 0.1));
}

function getAcademyBuffs() {
  if (!_isPlainObj(state.academyResearch)) state.academyResearch = { power: 0, gold: 0, defense: 0 };
  const p = safeInt(state.academyResearch.power, 0);
  const g = safeInt(state.academyResearch.gold, 0);
  const d = safeInt(state.academyResearch.defense, 0);
  return {
    armyPower: 1 + (p * 0.02),
    goldProd:  1 + (g * 0.02),
    defense:   1 + (d * 0.02),
    xp: 1 + (p * 0.01)
  };
}

function getDefensePower() {
  const b = _isPlainObj(state.buildings) ? state.buildings : {};
  const castle = Math.max(1, safeInt(b.castle, 1));
  const wall = Math.max(1, safeInt(b.wall, 1));
  const tower = Math.max(1, safeInt(b.watchtower, 1));
  const buff = getAcademyBuffs().defense;
  let base = (castle * 150 + wall * 450 + tower * 80) * buff;
  if (typeof getPatrolDefenseBonus === 'function') base *= (1 + getPatrolDefenseBonus());
  return Math.floor(base);
}

function getTotalPower() {
  if (typeof UNITS_INFO === 'undefined' || !UNITS_INFO) return 0;
  const b = Math.max(1, safeInt((state.buildings && state.buildings.barracks), 1));
  let t = 0;
  if (_isPlainObj(state.army)) {
    for (const k in state.army) {
      if (!Object.prototype.hasOwnProperty.call(state.army, k)) continue;
      if (!UNITS_INFO[k]) continue;
      const v = state.army[k];
      if (typeof v !== 'number' || !isFinite(v) || v <= 0) continue;
      t += v * getUnitPower(k, b);
    }
  }
  return Math.floor(t * getAcademyBuffs().armyPower);
}

const getUpgradeTime = (lvl) => {
  lvl = Math.max(1, safeInt(lvl, 1));
  if (lvl <= 5) return lvl * 20 * 60000;
  const baseTime = 100 * 60000;
  const time = baseTime * Math.pow(1.22, lvl - 5);
  const maxTime = 4 * 24 * 60 * 60 * 1000;
  return Math.min(maxTime, Math.floor(time));
};

function getUpgradeCost(type, level) {
  if (typeof BUILDINGS_INFO === 'undefined' || !BUILDINGS_INFO[type]) return { gold: 0, wood: 0, stone: 0, iron: 0 };
  const info = BUILDINGS_INFO[type];
  const base = info.baseCost || {};
  level = Math.max(1, safeInt(level, 1));
  const mul = Math.pow(1.175, level) * 2;
  return {
    gold:  Math.floor((base.gold  || 0) * mul),
    wood:  Math.floor((base.wood  || 0) * mul),
    stone: Math.floor((base.stone || 0) * mul),
    iron:  Math.floor((base.iron  || 0) * mul)
  };
}

function getSpeedupCost(endTime) {
  if (typeof endTime !== 'number' || !isFinite(endTime)) return 0;
  const left = endTime - Date.now();
  if (!isFinite(left) || left <= 0) return 0;
  const rate = (typeof SPEEDUP_GOLD_PER_MIN === 'number' && isFinite(SPEEDUP_GOLD_PER_MIN)) ? SPEEDUP_GOLD_PER_MIN : 120;
  return Math.max(2, Math.ceil(Math.min(left, 60000) / 60000 * rate));
}

function getTrainTime(unitKey, barracksLvl) {
  if (typeof UNITS_INFO === 'undefined' || !UNITS_INFO[unitKey]) return 10000;
  const u = UNITS_INFO[unitKey];
  const baseTime = (typeof u.trainTime === 'number' && u.trainTime > 0) ? u.trainTime : 10000;
  barracksLvl = Math.max(1, safeInt(barracksLvl, 1));
  const reduction = Math.min(0.6, 0.05 * (barracksLvl - 1));
  return Math.max(1000, Math.floor(baseTime * (1 - reduction)));
}

function getTrainSpeedupCost(endTime) {
  if (typeof endTime !== 'number' || !isFinite(endTime)) return 0;
  const left = endTime - Date.now();
  if (!isFinite(left) || left <= 0) return 0;
  const rate = (typeof SPEEDUP_GOLD_PER_MIN === 'number') ? SPEEDUP_GOLD_PER_MIN : 120;
  return Math.max(2, Math.ceil(Math.min(left, 60000) / 60000 * rate));
}

function iconHTML(path, size, fallback) {
  const s = Math.max(10, Math.min(64, Number(size) || 16));
  const fb = (fallback == null) ? '' : String(fallback);
  if (typeof path === 'string' && /\.(png|jpe?g|webp|svg|gif)$/i.test(path)) {
    const fbJs = fb.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    const onerr = "this.onerror=null;var sp=document.createElement('span');sp.textContent='" + fbJs + "';sp.style.cssText='display:inline-block;width:" + s + "px;height:" + s + "px;line-height:" + s + "px;text-align:center;font-size:" + Math.floor(s * 0.85) + "px;vertical-align:middle;';this.replaceWith(sp);";
    return '<img src="' + escapeHtml(path) + '" alt="" style="width:' + s + 'px;height:' + s + 'px;object-fit:contain;vertical-align:middle;display:inline-block;" onerror="' + escapeHtml(onerr) + '">';
  }
  return escapeHtml(path || fb);
}

function timerIconHTML(size) {
  return (typeof _ICON !== 'undefined' && _ICON.timer) ? iconHTML(_ICON.timer, size, '⏱️') : iconHTML('', size, '⏱️');
}
function messageIconHTML(size) {
  return (typeof _ICON !== 'undefined' && _ICON.message) ? iconHTML(_ICON.message, size, '📨') : iconHTML('', size, '📨');
}
function chestDayIconHTML(size) {
  return (typeof _ICON !== 'undefined' && _ICON.chestDay) ? iconHTML(_ICON.chestDay, size, '🎁') : iconHTML('', size, '🎁');
}

function addMessage(type, icon, title, body, data) {
  if (typeof title !== 'string' || !title) return false;
  const validTypes = ['battle', 'system', 'reward', 'upgrade', 'training'];
  if (!validTypes.includes(type)) type = 'system';
  if (!_isPlainObj(state)) return false;
  if (!Array.isArray(state.messages)) state.messages = [];
  state.messages.push({
    id: 'msg_' + Date.now() + '_' + Math.floor(Math.random() * 1e6),
    type: type,
    icon: typeof icon === 'string' ? icon.slice(0, 8) : '📜',
    title: title.slice(0, 120),
    body: typeof body === 'string' ? body.slice(0, 500) : '',
    ts: Date.now(),
    read: false,
    data: _isPlainObj(data) ? data : null
  });
  if (state.messages.length > 50) state.messages = state.messages.slice(-50);
  state.msgUnread = state.messages.filter(x => !x.read).length;
  if (typeof saveGame === 'function') saveGame();
  if (typeof updateCastleMessagesUI === 'function') updateCastleMessagesUI();
  return true;
}
