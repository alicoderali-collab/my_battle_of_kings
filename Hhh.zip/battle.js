// ============================================================
// ⚔️ BATTLE OF KINGS - js/battle.js (v5 - MASTER FINAL)
// ============================================================

let currentEnemyIndex = 0;
let battleModalTimer = null;
let rematchTimer = null;
window._viewingResult = null;

const _btNum = (v, fb) => { if (typeof v !== 'number') v = Number(v); return isFinite(v) && v >= 0 ? v : (fb || 0); };
const _btInt = (v, fb) => Math.floor(_btNum(v, fb));

function getBattleCooldown(enemyIndex = 0) {
  if (typeof BOSS_COOLDOWNS_MS !== 'undefined' && Array.isArray(BOSS_COOLDOWNS_MS)) {
    const idx = Math.max(0, Math.min(BOSS_COOLDOWNS_MS.length - 1, _btInt(enemyIndex, 0)));
    return _btNum(BOSS_COOLDOWNS_MS[idx], BATTLE_COOLDOWN_MS || 600000);
  }
  return (typeof BATTLE_COOLDOWN_MS === 'number' && isFinite(BATTLE_COOLDOWN_MS)) ? BATTLE_COOLDOWN_MS : 600000;
}
function getBattleDuration() {
  return (typeof BATTLE_DURATION_MS === 'number' && isFinite(BATTLE_DURATION_MS)) ? BATTLE_DURATION_MS : 180000;
}

function clearBattleTimer() {
  if (battleModalTimer) { clearInterval(battleModalTimer); battleModalTimer = null; }
}
function stopRematchTimer() {
  if (rematchTimer) { clearInterval(rematchTimer); rematchTimer = null; }
}
function startRematchTimer() {
  stopRematchTimer();
  rematchTimer = setInterval(() => { try { updateRematchButton(); } catch (e) {} }, 1000);
}

const rewardText = (r) => {
  if (!_isPlainObj(r)) return '';
  return Object.keys(r).map(k => {
    if (_isBadKey(k)) return '';
    const iconRaw = (typeof RES_ICON !== 'undefined' && RES_ICON[k]) || '🎁';
    const icon = (typeof iconHTML === 'function') ? iconHTML(iconRaw, 24, '🎁') : iconRaw;
    return `${icon} ${toFa(_btInt(r[k], 0))}`;
  }).filter(Boolean).join(' ');
};

const cdLeft = (i) => {
  if (!_isPlainObj(state.battle) || !_isPlainObj(state.battle.cd)) return 0;
  const cdValue = _btNum(state.battle.cd[i], 0);
  return Math.max(0, cdValue - Date.now());
};

function winChanceText(p, e) {
  p = _btNum(p, 0); e = _btNum(e, 1);
  const r = e > 0 ? p / e : (p > 0 ? Infinity : 0);
  if (r >= 1.3) return 'خیلی زیاد 🟢';
  if (r >= 1.05) return 'زیاد 🟢';
  if (r >= 0.9) return 'نزدیک، حدود نیمه‌نیمه 🟡';
  if (r >= 0.74) return 'کم 🟠';
  return 'تقریباً صفر 🔴';
}

const LOG_GOOD_UNIT = {
  spearman: 'نیزه‌داران شما خط مقدم دشمن را شکستند.',
  archer:   'باران تیر کمانداران صفوف دشمن را درهم کوبید.',
  cavalry:  'سواره‌نظام شما از جناح دشمن عبور کرد!',
  wizard:   'جادوگر شما شهاب‌سنگی بر سر دشمن فرود آورد! 🔥'
};

function generateBattleLogEvent(b, elapsedMs) {
  if (!_isPlainObj(b) || typeof ENEMIES === 'undefined') return '';
  const enemy = ENEMIES[b.enemyIndex];
  if (!enemy) return '';
  const dur = _btNum(b.endTime, 0) - _btNum(b.startTime, 0);
  const progress = dur > 0 ? Math.min(1, Math.max(0, elapsedMs / dur)) : 0;
  const goodChance = b.win ? 0.4 + 0.5 * progress : 0.6 - 0.5 * progress;
  const units = _isPlainObj(b.units) ? Object.keys(b.units).filter(k => _btNum(b.units[k], 0) > 0 && LOG_GOOD_UNIT[k]) : [];
  const good = units.map(k => LOG_GOOD_UNIT[k]).concat([`${enemy.name || ''} در حال عقب‌نشینی است...`, 'روحیه‌ی سربازان شما بالاست.']);
  const bad = [`${enemy.name || ''} حمله‌ی غافلگیرکننده‌ای کرد!`, `${enemy.name || ''} صفوف شما را عقب راند.`, 'تعدادی از سربازان شما زخمی شدند.'];
  const pool = Math.random() < goodChance ? good : bad;
  const s = Math.floor(elapsedMs / 1000);
  const t = `${toFa(Math.floor(s / 60))}:${toFa(s % 60).padStart(2, '۰')}`;
  return `${t} — ${pool[Math.floor(Math.random() * pool.length)]}`;
}

// ============================================================
// ⚔️ VS Screen
// ============================================================
function openVsScreen(enemyIndex) {
  if (isProcessing) return;
  if (typeof isPeaceTreatyActive === 'function' && isPeaceTreatyActive()) {
    showToast('🕊️ پیمان صلح فعال است — تا پایان آن نمی‌توانی حمله کنی!', 'error');
    playSFX('error'); return;
  }
  if (!_isPlainObj(state.battle)) state.battle = { cd: {}, inProgress: null, lastResult: null, log: [] };
  if (state.battle.inProgress) { showToast('نبرد دیگری در جریان است! ⚔️', 'error'); playSFX('error'); return; }
  if (cdLeft(enemyIndex) > 0) { showToast('ارتش هنوز در حال استراحت است ⏳', 'error'); playSFX('error'); return; }
  if (typeof ENEMIES === 'undefined' || !ENEMIES[enemyIndex]) { showToast('دشمن نامعتبر است! ❌', 'error'); playSFX('error'); return; }
  const enemy = ENEMIES[enemyIndex];
  if (_btInt(state.player_level, 1) < _btInt(enemy.minLevel, 1)) {
    showToast(`برای جنگ با ${escapeHtml(enemy.name || '')} باید سطح ${toFa(enemy.minLevel)} باشی! 🔒`, 'error');
    playSFX('error'); return;
  }

  const pp = (typeof getTotalPower === 'function') ? getTotalPower() : 0;
  let profileImg = 'ghost/castle.png';
  if (typeof profilesData !== 'undefined' && Array.isArray(profilesData)) {
    const profile = profilesData.find(p => p.id === state.active_profile) || profilesData[0];
    if (profile && profile.img) profileImg = profile.img;
  }
  const share = Math.round(pp / Math.max(1, pp + _btNum(enemy.power, 1)) * 100);
  const enemyImg = enemy.img || 'ghost/bg_war.png';
  const durationStr = formatTime(getBattleDuration());

  const html = `
    <div class="vs-half blue"></div><div class="vs-half red"></div><div class="vs-line"></div>
    <div class="vs-content">
      <div class="vs-title">⚔️ رویارویی ⚔️</div>
      <div class="vs-arena">
        <div class="vs-side player">
          <div class="vs-portrait-wrap">
            <img src="${escapeHtml(profileImg)}" class="vs-portrait" onerror="this.onerror=null;this.src='ghost/castle.png'">
            <span class="vs-badge">سطح ${toFa(state.player_level)}</span>
          </div>
          <div class="vs-name">${escapeHtml(state.commanderName || 'فرمانده')}</div>
          <div class="vs-chip">⚔️ ${toFa(pp)} قدرت</div>
        </div>
        <div class="vs-center">
          <div class="vs-text">VS</div>
          <div class="vs-timer">${durationStr}</div>
        </div>
        <div class="vs-side enemy">
          <div class="vs-portrait-wrap">
            <img src="${escapeHtml(enemyImg)}" class="vs-portrait" onerror="this.onerror=null;this.src='ghost/bg_war.png'">
            <span class="vs-badge">سطح ${toFa(enemy.minLevel)}</span>
          </div>
          <div class="vs-name">${escapeHtml(enemy.icon || '')} ${escapeHtml(enemy.name || '')}</div>
          <div class="vs-chip">${rewardText(enemy.reward)}</div>
        </div>
      </div>
      <div class="vs-info">
        <div class="vs-bar"><div style="width:${share}%"></div></div>
        <div class="vs-hint">${pp <= 0 ? '⚠️ هنوز سربازی نداری!' : 'شانس پیروزی: ' + winChanceText(pp, _btNum(enemy.power, 1))}</div>
      </div>
      <div class="vs-actions">
        <button class="btn-retreat" onclick="closeVsScreen()">عقب‌نشینی</button>
        <button class="btn-fight" ${pp <= 0 ? 'disabled' : ''} onclick="startBattle(${enemyIndex})">شروع نبرد ⚔️</button>
      </div>
    </div>`;
  let el = document.getElementById('vsScreen');
  if (!el) { el = document.createElement('div'); el.id = 'vsScreen'; el.className = 'vs-screen'; document.body.appendChild(el); }
  el.innerHTML = html;
  el.classList.add('show');
  playSFX('click');
}

function closeVsScreen() {
  const el = document.getElementById('vsScreen');
  if (el) el.classList.remove('show');
}

function startBattle(enemyIndex) {
  if (!acquireLock()) return;
  try {
    if (typeof isPeaceTreatyActive === 'function' && isPeaceTreatyActive()) {
      showToast('🕊️ پیمان صلح فعال است — تا پایان آن نمی‌توانی حمله کنی!', 'error');
      playSFX('error'); return;
    }
    if (!_isPlainObj(state.battle)) state.battle = { cd: {}, inProgress: null, lastResult: null, log: [] };
    if (state.battle.inProgress) { showToast('نبرد دیگری در جریان است! ⚔️', 'error'); playSFX('error'); return; }
    if (cdLeft(enemyIndex) > 0) { showToast('ارتش هنوز در حال استراحت است ⏳', 'error'); playSFX('error'); return; }
    if (typeof ENEMIES === 'undefined' || !ENEMIES[enemyIndex]) { showToast('دشمن نامعتبر است! ❌', 'error'); playSFX('error'); return; }
    const enemy = ENEMIES[enemyIndex];
    if (_btInt(state.player_level, 1) < _btInt(enemy.minLevel, 1)) {
      showToast(`برای جنگ با ${escapeHtml(enemy.name || '')} باید سطح ${toFa(enemy.minLevel)} باشی! 🔒`, 'error');
      playSFX('error'); return;
    }
    const pp = (typeof getTotalPower === 'function') ? getTotalPower() : 0;
    if (pp <= 0) { showToast('اول سرباز استخدام کن! ⚔️', 'error'); playSFX('error'); return; }

    playSoundFile('ghost/Sword.mp3', 0.8);
    const pr = pp * (0.85 + Math.random() * 0.3);
    const er = _btNum(enemy.power, 1) * (0.85 + Math.random() * 0.3);
    const now = Date.now();

    transaction(() => {
      state.battle.inProgress = {
        enemyIndex, startTime: now, endTime: now + getBattleDuration(), resolved: false,
        playerPowerAtStart: pp, enemyPowerAtStart: _btNum(enemy.power, 0),
        win: pr >= er, units: JSON.parse(JSON.stringify(state.army || {})), lastLogTime: 0
      };
      state.battle.log = [];
    });

    saveGame();
    if (typeof missionAdd === 'function') missionAdd('pveAttack', 1);
    if (typeof updateSpecialOfferProgress === 'function') updateSpecialOfferProgress('attack', enemyIndex);
    closeVsScreen();
    currentBuilding = 'battle';
    const enemyBg = enemy.img || 'ghost/bg_war.png';
    const gm = $('gameModal');
    if (gm) {
      gm.style.backgroundImage = `linear-gradient(rgba(10,16,20,0.7), rgba(10,16,20,0.9)), url('${escapeHtml(enemyBg)}')`;
      gm.style.backgroundSize = 'cover';
      gm.style.backgroundPosition = 'center';
    }
    const mc = $('modal-content'); if (mc) mc.innerHTML = '';
    renderBattleInProgress();
    if (gm) gm.classList.add('show');
    showToast(`نبرد با ${escapeHtml(enemy.name || '')} آغاز شد! ⏳`);
    playSFX('success');
  } catch (e) {
    console.error('startBattle failed:', e);
    showToast('خطا در شروع نبرد! ❌', 'error');
    playSFX('error');
  } finally { releaseLock(); }
}

function renderBattleInProgress() {
  const b = state.battle && state.battle.inProgress;
  if (!b) return;
  const enemy = (typeof ENEMIES !== 'undefined' && ENEMIES[b.enemyIndex]);
  if (!enemy) {
    state.battle.inProgress = null; saveGame();
    showToast('دشمن نامعتبر است، نبرد لغو شد.', 'error');
    return;
  }
  const mt = $('modal-title'); if (mt) mt.textContent = `⚔️ نبرد با ${escapeHtml(enemy.name || '')}`;
  const mi = $('modal-img'); if (mi) mi.style.display = 'none';
  const mIcon = $('modal-icon'); if (mIcon) { mIcon.textContent = '⚔️'; mIcon.style.display = 'block'; }

  if (!$('battle-inprogress-content')) {
    const mc = $('modal-content');
    if (mc) mc.innerHTML = `
      <div id="battle-inprogress-content" style="width:100%;padding:10px;">
        <div style="text-align:center;font-family:'Lalezar';font-size:22px;color:var(--gold);margin-bottom:8px;">⚔️ نبرد در جریان است ⚔️</div>
        <div style="text-align:center;font-size:14px;color:#ccc;margin-bottom:14px;">${escapeHtml(enemy.icon || '')} ${escapeHtml(enemy.name || '')} در حال مقاومت است...</div>
        <div class="progress-container" style="height:30px;">
          <div class="progress-bar" id="battle-progress-bar" style="width:0%;background:linear-gradient(90deg,#f5c66b,#ff9800);"></div>
          <div class="progress-text" id="battle-timer-text" style="font-size:14px;"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:12px;color:#aaa;margin-top:8px;">
          <span>⚔️ شما: ${toFa(_btInt(b.playerPowerAtStart, 0))}</span>
          <span>⭐ سطح: ${toFa((ENEMIES[b.enemyIndex] && ENEMIES[b.enemyIndex].minLevel) || 1)}</span>
        </div>
        <div style="font-size:12px;color:var(--gold);margin-top:12px;text-align:center;">📜 گزارش زنده‌ی نبرد</div>
        <div id="battle-log-live" style="margin-top:8px;max-height:170px;overflow-y:auto;background:rgba(0,0,0,.4);border-radius:10px;padding:10px;text-align:right;"></div>
        <div style="text-align:center;margin-top:14px;font-size:12px;color:#888;">نتیجه بعد از پایان زمان خودکار اعلام می‌شود</div>
      </div>`;
  }
  const total = _btNum(b.endTime, 0) - _btNum(b.startTime, 0);
  const elapsed = Date.now() - _btNum(b.startTime, 0);
  const pct = total > 0 ? Math.min(100, (elapsed / total) * 100) : 0;
  const bar = $('battle-progress-bar'); if (bar) bar.style.width = pct + '%';
  const timer = $('battle-timer-text'); if (timer) timer.textContent = formatTime(_btNum(b.endTime, 0) - Date.now()) + ' باقی مانده';
  const box = $('battle-log-live');
  if (box) {
    const log = Array.isArray(state.battle.log) ? state.battle.log : [];
    const logCount = String(log.length);
    if (box.dataset.n !== logCount) {
      box.dataset.n = logCount;
      box.innerHTML = log.length
        ? log.map(l => `<div style="font-size:12px;color:#ccc;padding:4px 0;border-bottom:1px solid rgba(255,255,255,.05);">${escapeHtml(l)}</div>`).join('')
        : `<div style="font-size:12px;color:#888;text-align:center;">هنوز اتفاقی نیفتاده...</div>`;
      box.scrollTop = box.scrollHeight;
    }
  }
}

function tickBattleInProgress() {
  const b = state.battle && state.battle.inProgress;
  if (!b || b.resolved) return;
  const now = Date.now();
  const elapsed = now - _btNum(b.startTime, 0);
  if (!Array.isArray(state.battle.log)) state.battle.log = [];
  if (elapsed - _btNum(b.lastLogTime, 0) >= 20000 && state.battle.log.length < 9 && _btNum(b.endTime, 0) - now > 3000) {
    b.lastLogTime = elapsed;
    const logEntry = generateBattleLogEvent(b, elapsed);
    if (logEntry) state.battle.log.push(logEntry);
    saveGame();
  }
  const navBattleBtn = document.querySelector('.nav button[data-nav="نبرد"]');
  if (navBattleBtn && !navBattleBtn.classList.contains('battle-active')) navBattleBtn.classList.add('battle-active');
  if (now >= _btNum(b.endTime, 0)) {
    if (typeof resolveBattle === 'function') resolveBattle();
    if (navBattleBtn) navBattleBtn.classList.remove('battle-active');
  } else if (currentBuilding === 'battle') {
    renderBattleInProgress();
  }
}

function showBattleResult(customResult) {
  const r = _isPlainObj(customResult) ? customResult : (state.battle && state.battle.lastResult);
  if (!r) return;
  window._viewingResult = _isPlainObj(customResult) ? customResult : null;
  const navBattleBtn = document.querySelector('.nav button[data-nav="نبرد"]');
  if (navBattleBtn) navBattleBtn.classList.remove('battle-active');
  const gm = $('gameModal');
  if (gm && gm.classList.contains('show') && currentBuilding === 'battle') closeGameModal();
  const durSec = _btInt(r.duration, 0);
  const dur = formatTime(durSec * 1000);
  const activeRemaining = Math.max(0, _btInt(r.survivors, 0));
  const enemyNameSafe = escapeHtml(r.enemyName || '');
  const levelUpText = r.levelUp ? ` — 🎉 به سطح ${toFa(r.levelUp)} رسیدی!` : '';
  const rReward = _isPlainObj(r.reward) ? r.reward : {};
  const rLog = Array.isArray(r.log) ? r.log : [];
  const enemyLvl = (typeof ENEMIES !== 'undefined' && ENEMIES[r.enemyIndex] && ENEMIES[r.enemyIndex].minLevel) || 1;

  const html = `<div class="result-scroll">
    <div class="result-banner">${r.victory ? 'پیروزی! 🏆' : 'شکست! 💀'}</div>
    <div class="result-sub">نبرد با ${enemyNameSafe}${levelUpText}</div>
    <div class="result-stats">
      <div class="stat-card"><div class="stat-label">قدرت ارتش شما</div><div class="stat-value" style="color:#4caf50;">⚔️ ${toFa(_btInt(r.playerPower, 0))}</div></div>
      <div class="stat-card"><div class="stat-label">سطح دشمن</div><div class="stat-value" style="color:#e57373;">⭐ ${toFa(enemyLvl)}</div></div>
      <div class="stat-card"><div class="stat-label">مدت نبرد</div><div class="stat-value">${dur}</div></div>
      <div class="stat-card"><div class="stat-label">باقی‌مانده</div><div class="stat-value" style="color:#8bc34a;">${toFa(activeRemaining)}</div></div>
      <div class="stat-card"><div class="stat-label">🩹 زخمی‌ها</div><div class="stat-value" style="color:#ff9800;">${toFa(_btInt(r.wounded, 0))}</div></div>
      <div class="stat-card"><div class="stat-label">💀 کشته‌ها</div><div class="stat-value" style="color:#ff5252;">${toFa(_btInt(r.totalLost, 0))}</div></div>
    </div>
    <div class="result-box" style="border-color:var(--gold); background:rgba(245,198,107,0.1); padding:15px; margin-top: 15px;"><button class="btn-epic-report" onclick="openEpicBattleReport()">📜 مشاهده گزارش کامل نبرد</button></div>
    <div class="result-box" style="border-color:#a855f7;"><div class="box-title">⭐ تجربه کسب‌شده</div><div class="box-items" style="color:#c084fc;">+${toFa(_btInt(r.xpGain, 0))} XP</div></div>
    ${r.victory && Object.keys(rReward).length ? `<div class="result-box"><div class="box-title">🎁 غنائم</div><div class="box-items">${rewardText(rReward)}</div></div>` : `<div class="result-box" style="border-color:#ff5252;"><div class="box-title">💔 این بار جایزه‌ای نیست</div><div style="font-size:13px;color:#ff8a80;">ارتشت را قوی‌تر کن و دوباره برگرد.</div></div>`}
    ${rLog.length ? `<div class="result-log"><div style="font-size:11px;color:var(--gold);margin-bottom:5px;text-align:center;">📜 گزارش نبرد</div>${rLog.map(l => `<div class="log-line">${escapeHtml(l)}</div>`).join('')}</div>` : ''}
    </div>
    <div class="result-actions"><button class="btn-rematch" id="rematch-btn" onclick="rematchFromResult()">نبرد مجدد ⚔️</button><button class="btn-result-close" onclick="closeResultScreen()">بستن</button></div>`;
  let el = document.getElementById('resultScreen');
  if (!el) { el = document.createElement('div'); el.id = 'resultScreen'; document.body.appendChild(el); }
  el.className = `result-screen ${r.victory ? 'victory' : 'defeat'}`;
  el.innerHTML = html;
  el.classList.add('show');
  startRematchTimer();
  if (r.victory) {
    if (typeof confetti === 'function') { try { confetti(); } catch (e) {} }
    if (typeof buzz === 'function') { try { buzz([80, 60, 80]); } catch (e) {} }
    playSFX('success');
  } else {
    if (typeof buzz === 'function') { try { buzz(250); } catch (e) {} }
    playSFX('error');
  }
}

function openEpicBattleReport() {
  const r = window._viewingResult || (state.battle && state.battle.lastResult);
  if (!r) return;
  if (typeof generateEpicReportData !== 'function') { showToast('گزارش در دسترس نیست ❌', 'error'); return; }
  let data;
  try { data = generateEpicReportData(r); }
  catch (e) { console.error('epic report failed', e); showToast('خطا در گزارش ❌', 'error'); return; }
  const html = `
    <div class="epic-report-overlay" onclick="closeEpicReport(event)">
      <div class="epic-report-box" onclick="event.stopPropagation()">
        <div class="epic-title">${escapeHtml(data.title || '')}</div>
        <div class="epic-subtitle">نبرد با ${escapeHtml(r.enemyName || '')}</div>
        <div class="epic-text"><p>${escapeHtml(data.intro || '')}</p></div>
        <div class="epic-section"><div class="epic-section-title">🛡️ سرنوشت سپاه تو</div><div class="epic-section-text">${data.playerLossText || ''}</div></div>
        <div class="epic-section"><div class="epic-section-title">⚔️ سرنوشت دشمن</div><div class="epic-section-text">${escapeHtml(data.enemyLossText || '')}</div></div>
        <div class="epic-divider"></div>
        <button class="btn-close-epic" onclick="closeEpicReport()">بستن طومار</button>
      </div>
    </div>`;
  let el = document.getElementById('epicReportOverlay');
  if (!el) { el = document.createElement('div'); el.id = 'epicReportOverlay'; document.body.appendChild(el); }
  el.innerHTML = html;
  if (r.victory) playSFX('success'); else playSFX('error');
  if (typeof buzz === 'function') { try { buzz(50); } catch (e) {} }
}

function closeEpicReport(e) {
  if (e && e.target.id !== 'epicReportOverlay') return;
  const el = document.getElementById('epicReportOverlay');
  if (el) el.remove();
}

function updateRematchButton() {
  const b = $('rematch-btn');
  const r = window._viewingResult || (state.battle && state.battle.lastResult);
  if (!b || !r) return;
  const l = cdLeft(r.enemyIndex);
  b.disabled = l > 0;
  b.textContent = l > 0 ? `نبرد مجدد (${formatTime(l)})` : 'نبرد مجدد ⚔️';
}

function closeResultScreen() {
  stopRematchTimer();
  window._viewingResult = null;
  const el = document.getElementById('resultScreen');
  if (el) el.classList.remove('show');
  const epic = document.getElementById('epicReportOverlay');
  if (epic) epic.remove();
}

function rematchFromResult() {
  const r = window._viewingResult || (state.battle && state.battle.lastResult);
  if (!r) return;
  if (typeof isPeaceTreatyActive === 'function' && isPeaceTreatyActive()) {
    showToast('🕊️ پیمان صلح فعال است — تا پایان آن نمی‌توانی حمله کنی!', 'error');
    playSFX('error'); return;
  }
  if (typeof ENEMIES === 'undefined' || !ENEMIES[r.enemyIndex]) return;
  if (cdLeft(r.enemyIndex) > 0) { showToast('ارتش هنوز در حال استراحت است ⏳', 'error'); playSFX('error'); return; }
  closeResultScreen();
  setTimeout(() => openVsScreen(r.enemyIndex), 350);
}

function openBattleModal() {
  currentBuilding = 'battle';
  const mi = $('modal-img'); if (mi) mi.style.display = 'none';
  const mIcon = $('modal-icon'); if (mIcon) { mIcon.textContent = '⚔️'; mIcon.style.display = 'block'; }
  const gm = $('gameModal');
  if (gm) {
    gm.style.backgroundImage = "linear-gradient(rgba(10,16,20,0.65), rgba(10,16,20,0.85)), url('ghost/bg_war.png')";
    gm.style.backgroundSize = 'cover';
    gm.style.backgroundPosition = 'center';
  }
  if (state.battle && state.battle.inProgress) {
    const mc = $('modal-content'); if (mc) mc.innerHTML = '';
    renderBattleInProgress();
  } else { openBattleMenu(); }
  if (gm) gm.classList.add('show');
}

function openBattleMenu() {
  currentBuilding = 'battle';
  const mt = $('modal-title'); if (mt) mt.textContent = '⚔️ انتخاب میدان نبرد';
  const mi = $('modal-img'); if (mi) mi.style.display = 'none';
  const mIcon = $('modal-icon'); if (mIcon) { mIcon.textContent = '⚔️'; mIcon.style.display = 'block'; }
  const gm = $('gameModal');
  if (gm) gm.style.backgroundImage = "radial-gradient(circle at 50% 10%, #1a2930, #0a1014 90%)";
  const html = `
    <div style="display:flex; flex-direction:column; gap:20px; width:100%; padding:20px;">
      <div class="unit-card" style="cursor:pointer; border-color:var(--gold);" onclick="openPvEScreen()">
        <div style="font-size:40px; width:60px; text-align:center;">🤖</div>
        <div class="unit-info">
          <div class="unit-name" style="font-size:20px;">جنگ با ربات‌ها (PvE)</div>
          <div class="unit-stats">تمرین و کسب غنائم از دشمنان هوشمند</div>
        </div>
        <div style="font-size:24px; color:var(--gold);">❯</div>
      </div>
      <div class="unit-card" style="opacity:0.5; cursor:not-allowed;">
        <div style="font-size:40px; width:60px; text-align:center;">👑</div>
        <div class="unit-info">
          <div class="unit-name" style="font-size:20px;">جنگ با فرمانروا (PvP)</div>
          <div class="unit-stats">به‌زودی... آماده‌سازی سرورهای نبرد واقعی</div>
        </div>
        <div style="font-size:24px; color:#aaa;">🔒</div>
      </div>
    </div>`;
  const mc = $('modal-content'); if (mc) mc.innerHTML = html;
}

function openPvEScreen() {
  if (typeof ENEMIES === 'undefined' || !ENEMIES.length) { showToast('دشمنی موجود نیست! ❌', 'error'); return; }
  currentEnemyIndex = Math.max(0, Math.min(currentEnemyIndex, ENEMIES.length - 1));
  const enemy = ENEMIES[currentEnemyIndex];
  if (!enemy) return;
  clearBattleTimer();
  renderPvEContent();
  battleModalTimer = setInterval(() => {
    const gm = $('gameModal');
    if (currentBuilding === 'battle' && gm && gm.classList.contains('show')) {
      const cd = cdLeft(currentEnemyIndex);
      const btn = document.querySelector('.btn-fight');
      const playerLvl = _btInt(state.player_level, 1);
      const isLocked = playerLvl < _btInt(enemy.minLevel, 1);
      if (btn && !isLocked) {
        if (cd > 0) { btn.disabled = true; btn.textContent = `استراحت ارتش (${formatTime(cd)})`; }
        else { btn.disabled = false; btn.textContent = 'اعلام جنگ ⚔️'; btn.onclick = () => openVsScreen(currentEnemyIndex); }
      }
    } else { clearBattleTimer(); }
  }, 1000);
}

function renderPvEContent() {
  if (typeof ENEMIES === 'undefined' || !ENEMIES.length) return;
  const enemy = ENEMIES[currentEnemyIndex];
  if (!enemy) return;
  const cd = cdLeft(currentEnemyIndex);
  const enemyImg = enemy.img || 'ghost/bg_war.png';
  const playerLvl = _btInt(state.player_level, 1);
  const isLocked = playerLvl < _btInt(enemy.minLevel, 1);
  const mt = $('modal-title'); if (mt) mt.textContent = '🎯 انتخاب هدف';

  if (!document.getElementById('pve-fit-css')) {
    const st = document.createElement('style');
    st.id = 'pve-fit-css';
    st.textContent = `
      #modal-content .pve-root { width:100%; max-width:100%; display:flex; flex-direction:column; gap:10px; box-sizing:border-box; }
      #modal-content .pve-nav { display:flex; align-items:center; justify-content:space-between; width:100%; flex-shrink:0; }
      #modal-content .pve-img-wrap { width:95%; max-width:380px; height:clamp(140px, 30vh, 220px); border-radius:20px; overflow:hidden; margin:0 auto; background:#0a1014; position:relative; flex-shrink:0; }
      #modal-content .pve-title-row { text-align:center; width:100%; flex-shrink:0; }
      #modal-content .pve-reward { display:flex; justify-content:center; width:100%; background:rgba(0,0,0,0.4); padding:8px; border-radius:10px; flex-shrink:0; }
      #modal-content .pve-dock { position:sticky; bottom:0; width:100%; padding-top:10px; margin-top:auto; z-index:5; background:linear-gradient(to top, rgba(10,16,20,0.98) 55%, rgba(10,16,20,0.9) 80%, rgba(10,16,20,0) 100%); }
    `;
    document.head.appendChild(st);
  }

  const html = `
    <div class="pve-root">
      <div class="pve-nav">
        <button class="btn-action" style="width:45px; padding:5px; font-size:20px; margin:0;" onclick="changeEnemy(1)">❮</button>
        <div style="font-family:'Lalezar'; font-size:16px; color:#aaa;">هدف ${toFa(currentEnemyIndex + 1)} از ${toFa(ENEMIES.length)}</div>
        <button class="btn-action" style="width:45px; padding:5px; font-size:20px; margin:0;" onclick="changeEnemy(-1)">❯</button>
      </div>
      <div class="pve-img-wrap" style="border: 3px solid ${isLocked ? '#8a2a2a' : 'var(--gold)'}; box-shadow: ${isLocked ? '0 0 20px rgba(255,82,82,0.35)' : '0 0 25px rgba(245,198,107,0.5)'};">
        <img src="${escapeHtml(enemyImg)}" style="width:100%; height:100%; object-fit:cover; ${isLocked ? 'filter: brightness(0.85) saturate(0.95);' : ''}" onerror="this.onerror=null;this.src='ghost/bg_war.png'">
        ${isLocked ? `<div style="position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; background:linear-gradient(to bottom, rgba(0,0,0,0.15) 0%, rgba(0,0,0,0.45) 60%, rgba(0,0,0,0.7) 100%);">
          <div style="font-size:58px; margin-bottom:8px; filter:drop-shadow(0 0 14px #000) drop-shadow(0 4px 8px rgba(0,0,0,0.95));">🔒</div>
          <div style="font-family:'Lalezar'; color:#ff5252; font-size:15px; text-shadow:0 2px 6px #000, 0 0 10px #000; background:rgba(0,0,0,0.55); padding:4px 14px; border-radius:20px; border:1px solid rgba(255,82,82,0.6);">قفل شده — نیاز به سطح ${toFa(enemy.minLevel || 1)}</div>
        </div>` : ''}
      </div>
      <div class="pve-title-row">
        <div style="font-family:'Lalezar'; font-size:20px; color:${isLocked ? '#888' : 'var(--gold)'}; margin-bottom:4px;">${escapeHtml(enemy.icon || '')} ${escapeHtml(enemy.name || '')}</div>
        <div style="font-size:12px; color:#ccc; line-height:1.5; padding:0 10px;">${escapeHtml(enemy.lore || '')}</div>
      </div>
      <div class="pve-reward">
        <div style="text-align:center;">
          <div style="font-size:11px; color:#aaa; margin-bottom:3px;">غنائم در صورت پیروزی</div>
          <div style="font-family:'Lalezar'; color:var(--gold); font-size:14px;">${rewardText(enemy.reward)}</div>
        </div>
      </div>
      <div class="pve-dock">
        ${isLocked
          ? `<button class="btn-fight" style="width:100%; padding:14px; font-size:17px; border-radius:15px; background:#333; border-color:#555; color:#aaa; cursor:not-allowed; margin:0;" disabled>نیاز به سطح ${toFa(enemy.minLevel)} 🔒</button>`
          : `<button class="btn-fight" style="width:100%; padding:14px; font-size:17px; border-radius:15px; margin:0;" onclick="openVsScreen(${currentEnemyIndex})" ${cd > 0 ? 'disabled' : ''}>${cd > 0 ? `استراحت ارتش (${formatTime(cd)})` : 'اعلام جنگ ⚔️'}</button>`}
      </div>
    </div>
  `;
  const mc = $('modal-content'); if (mc) mc.innerHTML = html;
}

function changeEnemy(dir) {
  if (typeof ENEMIES === 'undefined' || !ENEMIES.length) return;
  currentEnemyIndex += dir;
  if (currentEnemyIndex < 0) currentEnemyIndex = ENEMIES.length - 1;
  if (currentEnemyIndex >= ENEMIES.length) currentEnemyIndex = 0;
  openPvEScreen();
  playSFX('click');
}

function resolveBattle() {
  const b = state.battle && state.battle.inProgress;
  if (!b || b.resolved) return;
  if (typeof ENEMIES === 'undefined' || !ENEMIES[b.enemyIndex]) {
    state.battle.inProgress = null; saveGame();
    showToast('نبرد لغو شد (دشمن نامعتبر)', 'error');
    return;
  }
  const enemy = ENEMIES[b.enemyIndex];

  try {
    transaction(() => {
      b.resolved = true;
      const win = (typeof b.win === 'boolean') ? b.win : (_btNum(b.playerPowerAtStart, 0) * (0.85 + Math.random() * 0.3) >= _btNum(b.enemyPowerAtStart, 1) * (0.85 + Math.random() * 0.3));
      const hospitalLvl = Math.max(1, _btInt(state.buildings && state.buildings.hospital, 1));
      const healRate = Math.min(0.80, 0.10 + (hospitalLvl - 1) * 0.02);
      if (!_isPlainObj(state.hospital)) state.hospital = { wounded: {} };
      if (!_isPlainObj(state.hospital.wounded)) state.hospital.wounded = {};
      const lostDead = [];
      let totalBefore = 0, totalLost = 0, totalWounded = 0;
      for (const k in state.army) {
        if (_isBadKey(k) || !Object.prototype.hasOwnProperty.call(state.army, k)) continue;
        const n = _btInt(state.army[k], 0);
        totalBefore += n;
        if (!n || typeof UNITS_INFO === 'undefined' || !UNITS_INFO[k]) continue;
        let sent = (b.units && typeof b.units[k] === 'number' && isFinite(b.units[k])) ? Math.floor(b.units[k]) : n;
        sent = Math.max(0, Math.min(n, sent));
        if (sent <= 0) continue;
        const baseRate = win ? 0.1 : 0.25;
        const exp = sent * (baseRate + Math.random() * 0.05);
        const totalCasualties = Math.min(sent, Math.floor(exp) + (Math.random() < exp - Math.floor(exp) ? 1 : 0));
        if (totalCasualties > 0) {
          const woundedCount = Math.floor(totalCasualties * healRate);
          const deadCount = totalCasualties - woundedCount;
          state.army[k] = n - totalCasualties;
          if (woundedCount > 0) {
            state.hospital.wounded[k] = _btInt(state.hospital.wounded[k], 0) + woundedCount;
            totalWounded += woundedCount;
          }
          if (deadCount > 0) {
            totalLost += deadCount;
            lostDead.push({ name: UNITS_INFO[k].name || k, n: deadCount });
          }
        }
      }
      const reward = win && _isPlainObj(enemy.reward) ? { ...enemy.reward } : {};
      if (win) {
        if (b.enemyIndex >= 4 && b.enemyIndex <= 6 && Math.random() < 0.35) reward.ironKey = 1;
        if (b.enemyIndex >= 7 && b.enemyIndex <= 9 && Math.random() < 0.25) reward.goldKey = 1;
        if (b.enemyIndex === ENEMIES.length - 1 && Math.random() < 0.10) reward.purpleKey = 1;
      }
      for (const rKey in reward) {
        if (_isBadKey(rKey)) continue;
        const rVal = _btNum(reward[rKey], 0);
        if (rVal <= 0) continue;
        if (state[rKey] !== undefined) { state[rKey] = _btNum(state[rKey], 0) + rVal; }
        else {
          if (!_isPlainObj(state.inventory)) state.inventory = {};
          state.inventory[rKey] = _btNum(state.inventory[rKey], 0) + rVal;
        }
      }
      if (win && typeof missionAdd === 'function') {
        missionAdd('win3', 1); missionAdd('win5', 1);
        if (b.enemyIndex === ENEMIES.length - 1) missionAdd('dragon', 1);
      }
      const xpGain = win ? Math.floor(_btNum(enemy.power, 0) / 5) : Math.floor(_btNum(enemy.power, 0) / 10);
      let newLevel = 0;
      try { newLevel = addXP(xpGain, true); } catch (e) { console.warn('addXP failed', e); }
      
      // ✅ آپدیت ماموریت زنده برای نبرد
      if (win && typeof updateLiveTaskProgress === 'function') {
        try { updateLiveTaskProgress('battle'); } catch (e) {}
      }

      state.battle.lastResult = {
        victory: win, enemyName: enemy.name || '', enemyIndex: b.enemyIndex,
        playerPower: _btNum(b.playerPowerAtStart, 0), enemyPower: _btNum(b.enemyPowerAtStart, 0),
        reward, lost: lostDead, totalLost, wounded: totalWounded,
        survivors: Math.max(0, totalBefore - totalLost - totalWounded),
        duration: Math.round((_btNum(b.endTime, 0) - _btNum(b.startTime, 0)) / 1000),
        log: Array.isArray(state.battle.log) ? [...state.battle.log] : [],
        xpGain, levelUp: _btInt(newLevel, 0)
      };
      state.battle.inProgress = null;
      state.battle.cd[b.enemyIndex] = Date.now() + getBattleCooldown(b.enemyIndex);
    });

    if (typeof updateUI === 'function') updateUI();
    saveGame();

    const _result = state.battle.lastResult;
    if (_result && typeof addMessage === 'function') {
      const title = _result.victory ? `🏆 پیروزی بر ${_result.enemyName}` : `💀 شکست از ${_result.enemyName}`;
      const rewardTextPlain = Object.keys(_result.reward || {}).map(k => {
        const name = (typeof resNames !== 'undefined' && resNames[k]) || k;
        return `${toFa(_result.reward[k])} ${name}`;
      }).join('، ');

      const body = _result.victory
        ? `نبرد با ${_result.enemyName} پیروز شد. غنائم: ${rewardTextPlain || 'بدون غنیمت'}`
        : `نبرد با ${_result.enemyName} شکست خورد. تلفات: ${toFa(_result.totalLost)}`;

      addMessage('battle', _result.victory ? '🏆' : '💀', title, body, {
        victory: _result.victory, enemyName: _result.enemyName, enemyIndex: _result.enemyIndex,
        playerPower: _result.playerPower, enemyPower: _result.enemyPower, totalLost: _result.totalLost,
        wounded: _result.wounded, survivors: _result.survivors, duration: _result.duration,
        xpGain: _result.xpGain, levelUp: _result.levelUp, reward: _result.reward,
        lost: _result.lost, log: _result.log
      });
    }
    if (currentBuilding === 'battle') {
      if (typeof showBattleResult === 'function') showBattleResult();
    } else if (_result) {
      showToast(_result.victory ? '🏆 نبرد تمام شد! نتیجه به پیغام‌ها رفت' : '💀 نبرد تمام شد!', _result.victory ? 'success' : 'error');
    }
  } catch (err) {
    console.error('خطا در پایان نبرد (rollback شد):', err);
    state.battle.inProgress = null;
    saveGame();
    showToast('خطا در پایان نبرد ❌', 'error');
  }
}

function generateEpicReportData(r) {
  if (!_isPlainObj(r)) return { title: '📜 گزارش نبرد', intro: '', playerLossText: '', enemyLossText: '' };
  const lostList = Array.isArray(r.lost) ? r.lost.filter(x => _isPlainObj(x) && typeof x.name === 'string' && isFinite(x.n) && x.n > 0) : [];
  const woundedN = _btInt(r.wounded, 0);
  let playerLossText = '';
  if (lostList.length === 0 && woundedN === 0) {
    playerLossText = '✨ سپاه تو همچون کوهی استوار بود و هیچ سربازی از دست نرفت. افسانه‌ی شکست‌ناپذیری تو در تاریخ ثبت شد.';
  } else {
    const lostLines = lostList.map(x => `💀 ${escapeHtml(x.name)}: ${toFa(x.n)} سرباز`).join('<br>');
    let text = `این نبرد بهای سنگینی داشت. خون پاک سربازان تو بر خاک ریخت:<br><div style="color:#ff8a80; margin-top:10px;">${lostLines}</div>`;
    if (woundedN > 0) text += `<br><div style="color:#4caf50; margin-top:5px;">🩹 ${toFa(woundedN)} سرباز زخمی به بیمارستان منتقل شدند.</div>`;
    playerLossText = text;
  }
  const enemyPower = _btNum(r.enemyPower, 0);
  const simulatedEnemyLoss = Math.floor((enemyPower / 50) * (r.victory ? 1.5 : 0.8));
  const enemyLossText = r.victory
    ? `دشمن در برابر عظمت سپاه تو زانو زد. حدود ${toFa(simulatedEnemyLoss)} نفر از نیروهایشان به هلاکت رسیدند و مابقی پای به فرار گذاشتند.`
    : `اگرچه ما شکست خوردیم، اما ضربات سنگینی بر پیکره‌ی دشمن وارد کردیم. تخمین زده می‌شود حدود ${toFa(simulatedEnemyLoss)} نفر از دشمنان نیز در این نبرد جان باخته باشند.`;
  return {
    title: r.victory ? '🏆 فتح بزرگ' : '💀 میدان خون',
    intro: r.victory
      ? 'آسمان از دود آتش سرخ شده بود و زمین از ضربه‌ی شمشیرها می‌لرزید. اما در نهایت، پرچم تو بر فراز تپه‌های خونین برافراشته شد...'
      : 'میدان نبرد به گورستانی تاریک تبدیل شد. دشمن با نیرویی شیطانی هجوم آورد و صفوف ما را در هم شکست. اما نام تو با افتخار در تاریخ باقی خواهد ماند...',
    playerLossText,
    enemyLossText
  };
}