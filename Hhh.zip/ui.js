// ============================================================
// ⚔️ BATTLE OF KINGS - js/ui.js (v11 - MASTER FINAL)
// ============================================================

const _uiNum = (v, fb) => { if (typeof v !== 'number') v = Number(v); return isFinite(v) && v >= 0 ? v : (fb || 0); };
const _uiInt = (v, fb) => Math.floor(_uiNum(v, fb));
const _uiIsPlainObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const _uiIsBadKey = (k) => k === '__proto__' || k === 'constructor' || k === 'prototype';
const _uiSafeString = (s, fb) => (s == null) ? (fb || '') : String(s);

function updateXPBar() {
  const xp = _uiNum(state.xp, 0);
  const level = Math.max(1, Math.min(999, (typeof getLevelFromXP === 'function') ? getLevelFromXP(xp) : 1));
  const cur = (typeof xpForLevel === 'function') ? xpForLevel(level) : 0;
  const next = level >= 999 ? cur : ((typeof xpForLevel === 'function') ? xpForLevel(level + 1) : 100);
  const range = next - cur;
  const progress = Math.max(0, xp - cur);
  const percent = range > 0 ? Math.min(100, (progress / range * 100)) : 0;
  const bar = $('xp-bar-fill'), text = $('xp-bar-text');
  if (bar) bar.style.width = (isFinite(percent) ? percent : 0) + '%';
  if (text) text.textContent = `⭐ سطح ${toFa(level)} — ${toFa(progress)} / ${toFa(range)} XP`;
}

function confetti(hostId = 'resultScreen') {
  const host = document.getElementById(hostId); if (!host) return;
  const colors = ['#ffd700', '#ff5252', '#4caf50', '#40c4ff', '#e040fb', '#ffffff'];
  for (let i = 0; i < 45; i++) {
    try {
      const p = document.createElement('i'); p.className = 'confetti';
      p.style.cssText = `left:${Math.random()*100}%;background:${colors[i%6]};width:${6+Math.random()*6}px;height:${10+Math.random()*8}px;animation-duration:${2.2+Math.random()*2.2}s;animation-delay:${Math.random()*.8}s`;
      host.appendChild(p);
      setTimeout(() => { if (p.parentNode) p.parentNode.removeChild(p); }, 5500);
    } catch (e) {}
  }
}

function updateUI() {
  if ($('ui-gold')) $('ui-gold').textContent = toFa(_uiNum(state.gold, 0));
  if ($('ui-wood')) $('ui-wood').textContent = toFa(_uiNum(state.wood, 0));
  if ($('ui-azooghe')) $('ui-azooghe').textContent = toFa(_uiNum(state.azooghe, 0));
  if ($('ui-stone')) $('ui-stone').textContent = toFa(_uiNum(state.stone, 0));
  if ($('ui-iron')) $('ui-iron').textContent = toFa(_uiNum(state.iron, 0));
  if ($('ui-coal')) $('ui-coal').textContent = toFa(_uiNum(state.coal, 0));
  if ($('ui-diamond')) $('ui-diamond').textContent = toFa(_uiNum(state.diamond, 0));
  if ($('ui-crystal')) $('ui-crystal').textContent = toFa(_uiNum(state.crystal, 0));
  if ($('player-level')) $('player-level').textContent = toFa(_uiInt(state.player_level, 1));
  const chestBtn = $('level-chest-btn');
  if (chestBtn) {
    const count = _uiInt(state.unopenedLevelChests, 0);
    chestBtn.style.display = count > 0 ? 'flex' : 'none';
    const badge = chestBtn.querySelector('.badge'); if (badge) badge.textContent = toFa(count);
    let img = chestBtn.querySelector('img.chest-icon');
    const targetSrc = (typeof _ICON !== 'undefined' && _ICON.chestDay) ? _ICON.chestDay : 'ghost/chest_for_upg_player.png';
    if (!img) { img = document.createElement('img'); img.className='chest-icon'; img.src=targetSrc; img.alt=''; img.style.cssText='width:28px;height:28px;object-fit:contain;'; chestBtn.insertBefore(img,chestBtn.firstChild); }
    img.onerror = function(){ this.onerror=null; this.src='ghost/chest1.png'; };
  }
  if ($('ui-army-power') && typeof getTotalPower === 'function') $('ui-army-power').textContent = toFa(getTotalPower());
  if (typeof profilesData !== 'undefined' && Array.isArray(profilesData)) {
    const ap = profilesData.find(p => p.id === state.active_profile) || profilesData[0];
    if (ap && $('main-profile-avatar')) { $('main-profile-avatar').src=ap.img; $('main-profile-avatar').onerror=function(){this.onerror=null;this.src='ghost/castle.png';}; }
  }
  const commander = document.querySelector('.commander-name');
  if (commander) commander.firstChild.textContent = `نام فرمانده: ${_uiSafeString(state.commanderName, 'آرش')} `;
  updateXPBar();
  if (typeof updateMissionBadge === 'function') updateMissionBadge();
  if (typeof renderSpecialOfferBtn === 'function') renderSpecialOfferBtn();
  if (typeof updateNotifications === 'function') updateNotifications();
}

function updateNotifications() {
  const map = $('gameMap'); if (!map) return;
  const b = (state.buildings && _uiIsPlainObj(state.buildings)) ? state.buildings : {};
  const need = {};
  if (state.farm && state.farm.isProducing && (_uiNum(state.farm.accumulatedAzooghe, 0) + _uiNum(state.farm.accumulatedWood, 0)) >= ((typeof getProdCapacity === 'function' ? getProdCapacity('farm') : (200 + (_uiInt(b.farm, 1) - 1) * 400)) - 0.5)) need.farm = '🔔';
  if (state.mine && state.mine.isProducing && (_uiNum(state.mine.accumulatedStone, 0) + _uiNum(state.mine.accumulatedCoal, 0) + _uiNum(state.mine.accumulatedDiamond, 0)) >= ((typeof getProdCapacity === 'function' ? getProdCapacity('mine') : (300 + (_uiInt(b.mine, 1) - 1) * 500)) - 0.5)) need.mine = '🔔';
  if (state.lumberProd && state.lumberProd.isProducing && _uiNum(state.lumberProd.accumulatedWood, 0) >= ((typeof getProdCapacity === 'function' ? getProdCapacity('lumberProd') : (200 + (_uiInt(b.lumber, 1) - 1) * 400)) - 0.5)) need.lumber = '🔔';
  if (state.lumber && state.lumber.isReady) need.lumber = '✅';
  if (state.smith && state.smith.isReady) need.smith = '✅';
  if (state.upgrade && !need[state.upgrade.type]) need[state.upgrade.type] = '🔨';
  if (state.academyResearch && state.academyResearch.activeResearch && state.academyResearch.activeResearch.branch) {
    if (!need.academy) need.academy = '🔬';
  }

  const key = JSON.stringify(need);
  if (key === lastNotifKey) return;
  lastNotifKey = key;
  map.querySelectorAll('.notif-icon').forEach(el => el.remove());
  Object.keys(need).forEach(cls => {
    const img = map.querySelector('.building.' + cls);
    if (!img) return;
    const n = document.createElement('div');
    n.className = 'notif-icon'; n.dataset.cls = cls; n.textContent = need[cls];
    n.style.background = need[cls] === '✅' ? '#4caf50' : need[cls] === '🔨' ? '#ff9800' : need[cls] === '🔬' ? '#a855f7' : '#f44336';
    const cw = map.clientWidth || 1;
    const ch = map.clientHeight || 1;
    n.style.left = ((img.offsetLeft + img.offsetWidth * 0.5) / cw * 100) + '%';
    n.style.top = ((img.offsetTop + img.offsetHeight * 0.2) / ch * 100) + '%';
    map.appendChild(n);
  });
}

function repositionNotifIcons() {
  const map = $('gameMap'); if (!map) return;
  const cw = map.clientWidth || 1;
  const ch = map.clientHeight || 1;
  map.querySelectorAll('.notif-icon').forEach(el => {
    const cls = el.dataset.cls;
    const img = map.querySelector('.building.' + cls); if (!img) return;
    el.style.left = ((img.offsetLeft + img.offsetWidth * 0.5) / cw * 100) + '%';
    el.style.top = ((img.offsetTop + img.offsetHeight * 0.2) / ch * 100) + '%';
  });
}

function openInventory() {
  const grid = $('inv-grid'); if (!grid) return;
  let html = '';
  const allItems = ['gold','wood','azooghe','stone','iron','coal','diamond','crystal','steel','spear','helmet','shield','armor','horseArmor','bow','arrow','staff','wall','catapult', 'speedup_1m', 'speedup_10m', 'speedup_1h', 'speedup_1d', 'magicBook', 'ironKey', 'goldKey', 'purpleKey'];
  allItems.forEach(k => {
    if (_uiIsBadKey(k)) return;
    const val = state[k] !== undefined ? state[k] : ((state.inventory && state.inventory[k]) || 0);
    const name = (typeof resNames !== 'undefined' && resNames[k]) || k;
    const iconRaw = (typeof RES_ICON !== 'undefined' && RES_ICON[k]) || '';
    const iconHtml = (typeof iconHTML === 'function') ? iconHTML(iconRaw, 24, '') : iconRaw;
    html += `<div class="inv-item">${iconHtml} ${escapeHtml(name)}<b>${toFa(_uiNum(val, 0))}</b></div>`;
  });
  grid.innerHTML = html;
  const debugBtn = $('btn-debug-res'); if (debugBtn) debugBtn.style.display = (typeof DEBUG !== 'undefined' && DEBUG) ? 'inline-flex' : 'none';
  const modal = $('inventoryModal'); if (modal) modal.classList.add('show');
}

function closeInventory() { const m = $('inventoryModal'); if (m) m.classList.remove('show'); }

function debugAddResources() {
  if (typeof DEBUG === 'undefined' || !DEBUG) return;
  transaction(() => {
    ['gold','wood','azooghe','stone','iron','coal','diamond','crystal'].forEach(k => {
      state[k] = _uiNum(state[k], 0) + 1000;
    });
    if (!_uiIsPlainObj(state.inventory)) state.inventory = {};
    Object.keys(state.inventory).forEach(k => {
      if (_uiIsBadKey(k)) return;
      state.inventory[k] = _uiNum(state.inventory[k], 0) + 1000;
    });
  });
  updateUI(); saveGame();
  if ($('inventoryModal') && $('inventoryModal').classList.contains('show')) openInventory();
  showToast('🎁 ۱۰۰۰ واحد به همه منابع و آیتم‌ها اضافه شد! (تست)');
}

function openProfileShop() {
  renderProfiles();
  const m = $('profileShopModal'); if (m) m.classList.add('show');
}
function closeProfileShop() {
  profileConfirmId = null;
  profileConfirmArm = 0;
  const m = $('profileShopModal');
  if (m) m.classList.remove('show');
}

function renderProfiles() {
  const list = $('profile-list'); if (!list) return;
  if (typeof profilesData === 'undefined' || !Array.isArray(profilesData)) return;
  list.innerHTML = '';
  profilesData.forEach(p => {
    if (!p || !p.id) return;
    const isOwned = Array.isArray(state.owned_profiles) && state.owned_profiles.includes(p.id);
    const isSelected = (p.id === state.active_profile);
    const cost = _uiNum(p.cost, 0);
    const canAfford = _uiNum(state.gold, 0) >= cost;
    let btnText = 'خرید', btnClass = '', isDisabled = '';
    if (isOwned) {
      if (isSelected) { btnText = 'انتخاب شده'; btnClass = 'selected-btn'; }
      else { btnText = 'انتخاب'; btnClass = 'owned'; }
    } else {
      if (!canAfford) { btnText = 'طلا کم است'; isDisabled = 'disabled'; }
    }
    const card = document.createElement('div');
    card.className = `profile-card ${isSelected ? 'selected' : ''}`;
    card.innerHTML = `<img src="${escapeHtml(p.img)}" alt="${escapeHtml(p.name)}" onerror="this.onerror=null;this.src='ghost/castle.png'"><div class="p-name">${escapeHtml(p.name)}</div><div class="p-price">${isOwned ? 'خریداری شده' : 'قیمت: ' + toFa(cost) + ' ' + iconHTML(_ICON.gold, 18, '🪙')}</div><button class="p-btn ${btnClass}" ${isDisabled} onclick="handleProfileClick('${escapeHtml(p.id)}')">${btnText}</button>`;
    list.appendChild(card);
  });
}

function handleProfileClick(id) {
  if (!acquireLock()) return;
  try {
    if (_uiIsBadKey(id)) return;
    const profile = Array.isArray(profilesData) ? profilesData.find(p => p && p.id === id) : null;
    if (!profile) { showToast('پروفایل نامعتبر است!', 'error'); return; }
    const cost = _uiNum(profile.cost, 0);
    if (!Array.isArray(state.owned_profiles)) state.owned_profiles = ['castle'];
    if (state.owned_profiles.includes(id)) {
      state.active_profile = id;
      saveGame(); updateUI();
      if (typeof renderProfiles === 'function') renderProfiles();
      showToast('پروفایل انتخاب شد! ✨'); playSFX('success');
    } else {
      if (_uiNum(state.gold, 0) >= cost) {
        if (profileConfirmId !== id || Date.now() > profileConfirmArm) {
          profileConfirmId = id; profileConfirmArm = Date.now() + 3000;
          showToast(`برای خرید به قیمت ${toFa(cost)} طلا، دوباره کلیک کن ⚠️`);
          return;
        }
        profileConfirmId = null; profileConfirmArm = 0;
        try {
          transaction(() => {
            if (!spendGold(cost)) throw new Error('gold spent failed');
            state.owned_profiles.push(id);
            state.active_profile = id;
          });
        } catch (e) { showToast('خطا در خرید! ❌', 'error'); playSFX('error'); return; }
        saveGame(); updateUI();
        if (typeof renderProfiles === 'function') renderProfiles();
        showToast('پروفایل خریداری شد! 🎉');
        playSFX('success'); playSoundFile('ghost/dropping-single-coin.mp3', 0.6);
      } else {
        showToast('طلا کافی نیست! ❌', 'error'); playSFX('error');
      }
    }
  } finally { releaseLock(); }
}

function renderLeaderboard() {
  const playerLvl = _uiNum(state.player_level, 1);
  const playerPower = (typeof getTotalPower === 'function') ? getTotalPower() : 0;
  
  let playerLeagueName = '🥉 لیگ برنز';
  let leagueColor = '#cd7f32';
  if (playerLvl > 5 && playerLvl < 20) { playerLeagueName = '🥈 لیگ نقره'; leagueColor = '#c0c0c0'; }
  else if (playerLvl >= 20) { playerLeagueName = '🥇 لیگ طلا'; leagueColor = '#ffd700'; }

  const myAttacks = _uiNum(state.player_level * 2, 0); // شبیه‌سازی تعداد حمله برای نمایش
  const botNames = ['شاهین', 'سردار فولاد', 'لرد اژدها', 'پادشاه شمال', 'نگهبان تاریکی', 'روح جنگجو', 'فرمانده سرخ', 'سایه شب'];
  const botAvatars = ['ghost/knight.jpg', 'ghost/robot.jpg', 'ghost/blood.jpg', 'ghost/kingn.jpg', 'ghost/wich.jpg', 'ghost/doktor.jpg', 'ghost/castle.png'];
  
  let dynamicBots = [];
  for (let i = 0; i < 7; i++) {
    let botLevel = Math.max(1, playerLvl + Math.floor(Math.random() * 5) - 2);
    let botAttacks;
    if (myAttacks > 0) { botAttacks = Math.max(1, myAttacks + Math.floor(Math.random() * 15) - 5); }
    else { botAttacks = Math.floor(Math.random() * 10) + 1; }
    let botPower = botLevel * 300 + Math.floor(Math.random() * 500);

    dynamicBots.push({
      name: botNames[i % botNames.length],
      level: botLevel,
      power: botPower,
      bossAttacks: botAttacks,
      avatar: botAvatars[i % botAvatars.length],
      isPlayer: false
    });
  }

  const playerEntry = {
    name: (state.commanderName || 'آرش') + ' (شما)',
    level: playerLvl,
    power: playerPower,
    bossAttacks: myAttacks,
    avatar: (typeof profilesData !== 'undefined') ? (profilesData.find(p => p.id === state.active_profile)?.img || 'ghost/castle.png') : 'ghost/castle.png',
    isPlayer: true
  };

  const allPlayers = [...dynamicBots, playerEntry];
  allPlayers.sort((a, b) => b.bossAttacks - a.bossAttacks);

  let html = `
    <div style="width:100%; display:flex; flex-direction:column; gap:10px; padding-bottom:20px;">
      <div style="background:rgba(245,198,107,0.1); border:1px solid var(--gold); border-radius:12px; padding:10px; text-align:center; margin-bottom:10px;">
        <div style="font-family:'Lalezar'; color:var(--gold); font-size:18px; margin-bottom:5px;">میدان نبرد شبانه</div>
        <div style="font-size:12px; color:#ccc;">امشب بیشترین حمله به باس‌ها رو داشته باش و جایزه بگیر!</div>
        <div style="font-size:12px; color:${leagueColor}; margin-top:5px; font-weight:bold;">لیگ فعلی شما: ${playerLeagueName} (سطح ${toFa(playerLvl)})</div>
      </div>
  `;

  allPlayers.forEach((p, index) => {
    let rankIcon = toFa(index + 1);
    if (index === 0) rankIcon = '🥇'; else if (index === 1) rankIcon = '🥈'; else if (index === 2) rankIcon = '🥉';
    const isTop3 = index < 3;
    const borderColor = p.isPlayer ? '#4caf50' : (isTop3 ? '#f5c66b' : 'rgba(255,255,255,0.1)');
    const bgColor = p.isPlayer ? 'rgba(76,175,80,0.15)' : (isTop3 ? 'rgba(245,198,107,0.1)' : 'rgba(0,0,0,0.5)');
    const boxShadow = p.isPlayer ? '0 0 15px rgba(76,175,80,0.4)' : (isTop3 ? '0 0 10px rgba(245,198,107,0.3)' : 'none');
    const rewardBadge = isTop3 ? `<div style="font-size:10px; color:#ffd700; margin-top:2px;">🎁 جایزه شبانه</div>` : '';

    html += `<div style="display:flex; align-items:center; gap:10px; background:${bgColor}; border:1px solid ${borderColor}; border-radius:12px; padding:10px; box-shadow:${boxShadow}; text-align:right; position:relative;">
      <div style="font-size:20px; font-weight:bold; font-family:'Lalezar'; width:35px; text-align:center; color:${isTop3 ? '#f5c66b' : '#ccc'};">${rankIcon}</div>
      <img src="${escapeHtml(p.avatar || 'ghost/castle.png')}" style="width:45px; height:45px; border-radius:50%; border:2px solid ${borderColor}; object-fit:cover; background:#1a2930;" onerror="this.src='ghost/castle.png'">
      <div style="flex:1;">
        <div style="font-size:15px; font-family:'Lalezar'; color:${p.isPlayer ? '#4caf50' : '#fff'};">${escapeHtml(p.name || '')} <span style="font-size:11px; color:#aaa;">(سطح ${toFa(p.level)})</span></div>
        <div style="font-size:12px; color:#e57373; margin-top:3px;">⚔️ حملات به باس: <b>${toFa(p.bossAttacks)}</b></div>
        ${rewardBadge}
      </div>
    </div>`;
  });

  html += `</div>`;
  const mc = $('modal-content'); if (mc) mc.innerHTML = html;
}

function _missionTierReady(tier) {
  const list = MISSIONS.filter(m => m.tier === tier);
  const progress = state.missions && state.missions.progress || {};
  return list.length > 0 && list.every(m => _uiNum(progress[m.id], 0) >= m.target);
}

function updateMissionBadge() {
  const badge = $('mission-badge'); if (!badge) return;
  const claimed = state.missions && state.missions.claimed || {};
  const ready = ['beginner','intermediate','special'].filter(t => _missionTierReady(t) && !claimed[t]).length;
  badge.textContent = ready ? toFa(ready) : '';
  badge.classList.toggle('show', ready > 0);
}

function renderMissions() {
  const list = $('missions-list'); if (!list) return;
  if (typeof checkMissionDay === 'function') checkMissionDay();
  const progress = state.missions && state.missions.progress || {};
  const claimed = state.missions && state.missions.claimed || {};
  const tiers = [
    { id:'beginner', title:'🟢 مبتدی', reward:'آهن و فولاد + ۵ تا ۵۰ الماس + ۱۰۰ تا ۳۰۰ XP' },
    { id:'intermediate', title:'🟡 حرفه‌ای', reward:'۵۰ تا ۵۰۰ طلا + ۱ تا ۳ کلید آهنی + ۱ کلید طلایی + ۳۰۰ تا ۸۰۰ XP' },
    { id:'special', title:'🔴 ویژه', reward:'۱۰ تا ۲۰ کریستال + ۱ کلید بنفش + ۸۰۰ تا ۱۲۰۰ XP' }
  ];
  list.innerHTML = `<div class="mission-note">ماموریت‌ها هر روز ساعت ۰۰:۰۰ به وقت محلی دستگاه ریست می‌شوند. جایزه هر دسته پس از تکمیل همه مأموریت‌های همان دسته قابل دریافت است.</div>` +
    tiers.map(t => {
      const ms = MISSIONS.filter(m => m.tier === t.id);
      const done = ms.filter(m => _uiNum(progress[m.id],0) >= m.target).length;
      const ready = done === ms.length;
      const isClaimed = !!claimed[t.id];
      return `<section class="mission-tier mission-tier-${t.id}">
        <div class="mission-tier-head"><div><strong>${t.title}</strong><div class="mission-tier-reward">جایزه نهایی: ${t.reward}</div></div><span>${toFa(done)} / ${toFa(ms.length)}</span></div>
        ${ms.map(m => {
          const p = Math.min(m.target, _uiNum(progress[m.id],0));
          return `<div class="mission-card ${p >= m.target ? 'done' : ''}"><div class="mission-icon">${escapeHtml(m.icon)}</div><div class="mission-info"><div class="mission-title">${escapeHtml(m.title)}</div><div class="mission-bar"><div style="width:${(p / m.target * 100).toFixed(1)}%"></div></div><div class="mission-progress">${toFa(p)} / ${toFa(m.target)}</div></div>${p >= m.target ? '<span class="mission-check">✓</span>' : ''}</div>`;
        }).join('')}
        <button class="btn-recruit mission-claim" onclick="claimMission('${t.id}')" ${(!ready || isClaimed) ? 'disabled' : ''}>${isClaimed ? '✅ جایزه دریافت شد' : ready ? '🎁 دریافت جایزه دسته' : '🔒 تکمیل همه مأموریت‌ها'}</button>
      </section>`;
    }).join('');
}

function claimMission(tier) {
  if (!['beginner','intermediate','special'].includes(tier) || !acquireLock()) return;
  try {
    if (typeof checkMissionDay === 'function') checkMissionDay();
    if (!_missionTierReady(tier) || state.missions.claimed[tier]) return;
    const rand = (min,max) => Math.floor(Math.random() * (max-min+1)) + min;
    const reward = tier === 'beginner'
      ? { iron: rand(5,15), steel: rand(1,3), diamond: rand(5,50), xp: rand(100,300) }
      : tier === 'intermediate'
        ? { gold: rand(50,500), ironKey: rand(1,3), goldKey: 1, xp: rand(300,800) }
        : { crystal: rand(10,20), purpleKey: 1, xp: rand(800,1200) };
    try {
      transaction(() => {
        state.missions.claimed[tier] = true;
        for (const key of Object.keys(reward)) {
          if (key === 'xp') { addXP(reward[key]); continue; }
          if (['gold','wood','azooghe','stone','iron','coal','diamond','crystal'].includes(key)) state[key] = _uiNum(state[key],0) + reward[key];
          else {
            if (!_uiIsPlainObj(state.inventory)) state.inventory = {};
            state.inventory[key] = _uiNum(state.inventory[key],0) + reward[key];
          }
        }
      });
    } catch(e) { showToast('خطا در دریافت جایزه!', 'error'); return; }
    updateUI(); saveGame(); renderMissions();
    showToast('🎁 جایزه دسته مأموریت دریافت شد!');
    playSFX('success');
  } finally { releaseLock(); }
}

function openMissions() { renderMissions(); const m = $('missionsModal'); if (m) m.classList.add('show'); }
function closeMissions() { const m = $('missionsModal'); if (m) m.classList.remove('show'); }

const SHOP_CATEGORIES = [
  { id: 'resources',     name: 'منابع',  icon: (typeof _ICON !== 'undefined' && _ICON.wood) || '' },
  { id: 'speedups',      name: 'تسریع', icon: (typeof _ICON !== 'undefined' && _ICON.timer) || '' },
  { id: 'exchange',      name: 'صرافی', icon: (typeof _ICON !== 'undefined' && _ICON.diamond) || '' },
  { id: 'diamond_packs', name: 'الماس', icon: (typeof _ICON !== 'undefined' && _ICON.diamond) || '' },
  { id: 'gold_packs',    name: 'سکه',   icon: (typeof _ICON !== 'undefined' && _ICON.gold) || '' },
  { id: 'crates',        name: 'صندوق', icon: (typeof _ICON !== 'undefined' && _ICON.chestDay) || '' }
];

const SPEEDUP_SHOP_ITEMS = [
  { name: 'تسریع ۱ دقیقه',  icon: (typeof _ICON !== 'undefined' && _ICON.timer) || '', cost: { diamond: 1 },              give: { inv: 'speedup_1m', n: 1 } },
  { name: 'تسریع ۱۰ دقیقه', icon: (typeof _ICON !== 'undefined' && _ICON.timer) || '', cost: { diamond: 7 },              give: { inv: 'speedup_10m', n: 1 } },
  { name: 'تسریع ۱ ساعت',   icon: (typeof _ICON !== 'undefined' && _ICON.timer) || '', cost: { diamond: 30, gold: 10 },   give: { inv: 'speedup_1h', n: 1 } },
  { name: 'تسریع ۱ روز',    icon: (typeof _ICON !== 'undefined' && _ICON.timer) || '', cost: { crystal: 1, diamond: 20 }, give: { inv: 'speedup_1d', n: 1 } }
];

const EXCHANGE_PACKAGES = [
  { name: 'تبدیل ۱۰ الماس',  icon: (typeof _ICON !== 'undefined' && _ICON.diamond) || '', cost: { diamond: 10 },  give: { gold: 100 },  bonus: 0 },
  { name: 'تبدیل ۵۰ الماس',  icon: (typeof _ICON !== 'undefined' && _ICON.diamond) || '', cost: { diamond: 50 },  give: { gold: 550 },  bonus: 0 },
  { name: 'تبدیل ۱۰۰ الماس', icon: (typeof _ICON !== 'undefined' && _ICON.diamond) || '', cost: { diamond: 100 }, give: { gold: 1200 }, bonus: 0 },
  { name: 'تبدیل ۵۰۰ الماس', icon: (typeof _ICON !== 'undefined' && _ICON.diamond) || '', cost: { diamond: 500 }, give: { gold: 7000 }, bonus: 0 }
];

const _DIAMOND_PACKAGES = (typeof DIAMOND_PACKAGES !== 'undefined' && Array.isArray(DIAMOND_PACKAGES)) ? DIAMOND_PACKAGES : [
  { id: 'dia_100',   name: 'بسته شروع',      amount: 100,   bonusGold: 100,   price: 20000,   discount: 0  },
  { id: 'dia_300',   name: 'بسته ماجراجو',    amount: 300,   bonusGold: 500,   price: 55000,   discount: 8  },
  { id: 'dia_1000',  name: 'بسته استراتژیست', amount: 1000,  bonusGold: 700,   price: 149000,  discount: 25 },
  { id: 'dia_2000',  name: 'بسته فرمانده',    amount: 2000,  bonusGold: 2000,  price: 259000,  discount: 35, bonusCrystal: 3  },
  { id: 'dia_3000',  name: 'بسته امپراتور',   amount: 3000,  bonusGold: 5000,  price: 349000,  discount: 42, bonusCrystal: 10 },
  { id: 'dia_5000',  name: 'بسته سلطان',      amount: 5000,  bonusGold: 10000, price: 499000,  discount: 50, bonusCrystal: 30 },
  { id: 'dia_10000', name: 'بسته افسانه‌ای', amount: 10000, bonusGold: 30000, price: 899000,  discount: 55, bonusCrystal: 50 }
];

const _GOLD_PACKAGES = (typeof GOLD_PACKAGES !== 'undefined' && Array.isArray(GOLD_PACKAGES)) ? GOLD_PACKAGES : [
  { id: 'gold_100',    name: 'کیف پول',        amount: 100,    price: 10000,    discount: 0  },
  { id: 'gold_500',    name: 'صندوقچه',        amount: 500,    price: 45000,    discount: 10 },
  { id: 'gold_1000',   name: 'گنج کوچک',       amount: 1000,   price: 80000,    discount: 20 },
  { id: 'gold_2000',   name: 'گنج بزرگ',       amount: 2000,   price: 149000,   discount: 25 },
  { id: 'gold_5000',   name: 'خزانه',          amount: 5000,   price: 349000,   discount: 30 },
  { id: 'gold_10000',  name: 'خزانه سلطنتی',   amount: 10000,  price: 649000,   discount: 35 },
  { id: 'gold_50000',  name: 'ثروت پادشاه',    amount: 50000,  price: 2999000,  discount: 40 },
  { id: 'gold_100000', name: 'گنج افسانه‌ای', amount: 100000, price: 5499000,  discount: 45, bonusCrystal: 10 },
  { id: 'gold_300000', name: 'خدای ثروت',     amount: 300000, price: 14999000, discount: 50, bonusCrystal: 30 }
];

function _renderShopHeader() {
  let html = `<div class="shop-header">
    <div class="shop-balance">
      <span>${iconHTML((_ICON && _ICON.gold) || 'ghost/coin.jpg', 22, '🪙')} ${toFa(_uiNum(state.gold, 0))}</span>
      <span>${iconHTML((_ICON && _ICON.diamond) || 'ghost/ic_dimond.png', 22, '💎')} ${toFa(_uiNum(state.diamond, 0))}</span>
      <span>${iconHTML((_ICON && _ICON.crystal) || 'ghost/cristal.png', 22, '🔮')} ${toFa(_uiNum(state.crystal, 0))}</span>
    </div>
    <div class="shop-tabs">`;
  SHOP_CATEGORIES.forEach(cat => {
    const catIcon = iconHTML(cat.icon, 20, '');
    html += `<button class="shop-tab ${currentShopTab === cat.id ? 'active' : ''}" onclick="switchShopTab('${cat.id}')">${catIcon} ${cat.name}</button>`;
  });
  html += `</div></div>`;
  return html;
}

function renderShop() {
  if (currentShopTab === 'resources') return renderShopResources();
  if (currentShopTab === 'speedups') return renderShopSpeedups();
  if (currentShopTab === 'exchange') return renderShopExchange();
  if (currentShopTab === 'diamond_packs') return renderShopDiamondPacks();
  if (currentShopTab === 'gold_packs') return renderShopGoldPacks();
  if (currentShopTab === 'crates') return renderCrates();
  renderShopResources();
}

function _costHtml(cost) {
  let html = '';
  for (const r in cost) {
    if (_uiIsBadKey(r)) continue;
    const iconRaw = (typeof RES_ICON !== 'undefined' && RES_ICON[r]) || '🪙';
    const iconHtml = (typeof iconHTML === 'function') ? iconHTML(iconRaw, 20, '🪙') : iconRaw;
    html += `${iconHtml} ${toFa(_uiNum(cost[r], 0))} `;
  }
  return html;
}

function _afford(cost) {
  for (const r in cost) {
    if (_uiIsBadKey(r)) continue;
    if (_uiNum(state[r], 0) < _uiNum(cost[r], 0)) return false;
  }
  return true;
}

function renderShopResources() {
  let html = _renderShopHeader() + `<div class="shop-items">`;
  const items = (typeof SHOP_ITEMS !== 'undefined' && SHOP_ITEMS.resources) || [];
  items.forEach((it, i) => {
    if (!it || !it.cost) return;
    const afford = _afford(it.cost);
    const costHtml = _costHtml(it.cost);
    const cardIcon = (it.icon && /\.(png|jpe?g|webp|svg|gif)$/i.test(it.icon))
      ? `<img src="${escapeHtml(it.icon)}" style="width:54px;height:54px;object-fit:contain;" alt="" onerror="this.style.display='none';this.parentNode.textContent='🎁';this.parentNode.style.fontSize='32px';">`
      : escapeHtml(it.icon || '🎁');
    html += `<div class="shop-card">
      <div class="shop-card-icon">${cardIcon}</div>
      <div class="shop-card-info">
        <div class="shop-card-name">${escapeHtml(it.name || '')}</div>
        <div class="shop-card-cost">${costHtml}</div>
      </div>
      <button class="btn-buy" onclick="buyShopItem('resources', ${i})" ${afford ? '' : 'disabled'}>خرید</button>
    </div>`;
  });
  html += `</div>`;
  const mc = $('modal-content'); if (mc) mc.innerHTML = html;
}

function renderShopSpeedups() {
  let html = _renderShopHeader() + `<div class="shop-items">`;
  SPEEDUP_SHOP_ITEMS.forEach((it, i) => {
    if (!it || !it.cost) return;
    const afford = _afford(it.cost);
    const costHtml = _costHtml(it.cost);
    const cardIcon = iconHTML(it.icon, 54, '⏱️');
    html += `<div class="shop-card">
      <div class="shop-card-icon">${cardIcon}</div>
      <div class="shop-card-info">
        <div class="shop-card-name">${escapeHtml(it.name || '')}</div>
        <div class="shop-card-cost">${costHtml}</div>
      </div>
      <button class="btn-buy" onclick="buyShopItem('speedups', ${i})" ${afford ? '' : 'disabled'}>خرید</button>
    </div>`;
  });
  html += `</div>`;
  const mc = $('modal-content'); if (mc) mc.innerHTML = html;
}

function renderShopExchange() {
  let html = _renderShopHeader() + `<div class="shop-items" style="margin-top:5px;">
    <div style="background:rgba(245,198,107,0.1);border:1px solid rgba(245,198,107,0.3);border-radius:10px;padding:10px;margin-bottom:8px;text-align:center;font-size:13px;color:#f5c66b;">
      💱 نرخ صرافی: ۱۰ 💎 = ۱۰۰ 🪙
    </div>`;
  EXCHANGE_PACKAGES.forEach((it, i) => {
    if (!it || !it.cost) return;
    const afford = _afford(it.cost);
    const costHtml = _costHtml(it.cost);
    const bonusBadge = it.bonus > 0 ? `<span style="background:#4caf50;color:#fff;padding:2px 8px;border-radius:10px;font-size:10px;margin-right:5px;">+${toFa(it.bonus)}٪</span>` : '';
    html += `<div class="shop-card">
      <div class="shop-card-icon">${iconHTML(it.icon, 54, '💎')}</div>
      <div class="shop-card-info">
        <div class="shop-card-name">${escapeHtml(it.name || '')} ${bonusBadge}</div>
        <div class="shop-card-cost">${costHtml} ${iconHTML(_ICON.gold, 20, '🪙')} ${toFa(_uiNum(it.give.gold, 0))}</div>
      </div>
      <button class="btn-buy" onclick="buyShopItem('exchange', ${i})" ${afford ? '' : 'disabled'}>تبدیل</button>
    </div>`;
  });
  html += `</div>`;
  const mc = $('modal-content'); if (mc) mc.innerHTML = html;
}

function renderShopDiamondPacks() {
  let html = _renderShopHeader() + `<div class="shop-items" style="margin-top:5px;">
    <div style="background:rgba(233,30,99,0.15);border:1px solid rgba(233,30,99,0.4);border-radius:10px;padding:8px;margin-bottom:8px;text-align:center;font-size:12px;color:#ff80ab;">
      💳 پرداخت تومانی — در نسخه نهایی به درگاه متصل می‌شود${(typeof DEBUG !== 'undefined' && DEBUG) ? ' (DEBUG: رایگان)' : ''}
    </div>`;
  _DIAMOND_PACKAGES.forEach((pkg, i) => {
    const discBadge = pkg.discount > 0 ? `<span style="background:#e53935;color:#fff;padding:2px 8px;border-radius:10px;font-size:10px;">${toFa(pkg.discount)}٪ تخفیف</span>` : '';
    const bonusText = pkg.bonusGold > 0 ? `+ ${toFa(pkg.bonusGold)} 🪙` : '';
    const crystalText = pkg.bonusCrystal > 0 ? `+ ${toFa(pkg.bonusCrystal)} 🔮` : '';
    html += `<div class="shop-card" style="border-color:${pkg.discount >= 40 ? '#e91e63' : 'rgba(245,198,107,0.3)'};">
      <div class="shop-card-icon">${iconHTML(_ICON.diamond, 54, '💎')}</div>
      <div class="shop-card-info">
        <div class="shop-card-name">${escapeHtml(pkg.name)} ${discBadge}</div>
        <div class="shop-card-desc" style="font-size:12px;color:#8bc34a;">${toFa(pkg.amount)} 💎 ${bonusText} ${crystalText}</div>
        <div class="shop-card-cost" style="color:#fff;">${toFa(pkg.price)} تومان</div>
      </div>
      <button class="btn-buy" style="background:linear-gradient(180deg,#e91e63,#c2185b);" onclick="buyDiamondPack(${i})">خرید</button>
    </div>`;
  });
  html += `</div>`;
  const mc = $('modal-content'); if (mc) mc.innerHTML = html;
}

function renderShopGoldPacks() {
  let html = _renderShopHeader() + `<div class="shop-items" style="margin-top:5px;">
    <div style="background:rgba(233,30,99,0.15);border:1px solid rgba(233,30,99,0.4);border-radius:10px;padding:8px;margin-bottom:8px;text-align:center;font-size:12px;color:#ff80ab;">
      💳 پرداخت تومانی — در نسخه نهایی به درگاه متصل می‌شود${(typeof DEBUG !== 'undefined' && DEBUG) ? ' (DEBUG: رایگان)' : ''}
    </div>`;
  _GOLD_PACKAGES.forEach((pkg, i) => {
    const discBadge = pkg.discount > 0 ? `<span style="background:#e53935;color:#fff;padding:2px 8px;border-radius:10px;font-size:10px;">${toFa(pkg.discount)}٪ تخفیف</span>` : '';
    const crystalText = pkg.bonusCrystal > 0 ? `+ ${toFa(pkg.bonusCrystal)} 🔮` : '';
    html += `<div class="shop-card" style="border-color:${pkg.discount >= 40 ? '#e91e63' : 'rgba(245,198,107,0.3)'};">
      <div class="shop-card-icon">${iconHTML(_ICON.gold, 54, '🪙')}</div>
      <div class="shop-card-info">
        <div class="shop-card-name">${escapeHtml(pkg.name)} ${discBadge}</div>
        <div class="shop-card-desc" style="font-size:12px;color:#8bc34a;">${toFa(pkg.amount)} 🪙 ${crystalText}</div>
        <div class="shop-card-cost" style="color:#fff;">${toFa(pkg.price)} تومان</div>
      </div>
      <button class="btn-buy" style="background:linear-gradient(180deg,#e91e63,#c2185b);" onclick="buyGoldPack(${i})">خرید</button>
    </div>`;
  });
  html += `</div>`;
  const mc = $('modal-content'); if (mc) mc.innerHTML = html;
}

function switchShopTab(tabId) {
  if (isProcessing) return;
  const validTabs = ['resources', 'speedups', 'exchange', 'diamond_packs', 'gold_packs', 'crates'];
  if (!validTabs.includes(tabId)) return;
  currentShopTab = tabId;
  renderShop();
  playSFX('click');
}

function buyShopItem(catId, index) {
  if (!acquireLock()) return;
  try {
    let it = null;
    if (catId === 'resources') {
      it = (typeof SHOP_ITEMS !== 'undefined' && SHOP_ITEMS.resources && SHOP_ITEMS.resources[index]);
    } else if (catId === 'speedups') {
      it = SPEEDUP_SHOP_ITEMS[index];
    } else if (catId === 'exchange') {
      it = EXCHANGE_PACKAGES[index];
    }
    if (!it || !it.cost || !it.give) return;
    try {
      transaction(() => {
        if (!deductResources(it.cost)) throw new Error('insufficient funds');
        for (const k in it.give) {
          if (_uiIsBadKey(k)) continue;
          if (k === 'inv') {
            if (!_uiIsPlainObj(state.inventory)) state.inventory = {};
            state.inventory[it.give.inv] = _uiNum(state.inventory[it.give.inv], 0) + _uiNum(it.give.n, 1);
          } else if (k !== 'n') {
            if (state[k] !== undefined) {
              state[k] = _uiNum(state[k], 0) + _uiNum(it.give[k], 0);
            } else {
              if (!_uiIsPlainObj(state.inventory)) state.inventory = {};
              state.inventory[k] = _uiNum(state.inventory[k], 0) + _uiNum(it.give[k], 0);
            }
          }
        }
      });
    } catch (e) {
      showToast('منابع کافی نیست! ❌', 'error'); playSFX('error'); return;
    }
    updateUI(); saveGame();
    if (catId === 'exchange' && typeof missionAdd === 'function') missionAdd('exchange100', _uiNum(it.cost.diamond, 0));
    renderShop();
    showToast(`${it.name} خریداری شد! 🎉`);
    playSFX('success'); playSoundFile('ghost/dropping-single-coin.mp3', 0.6);
  } finally { releaseLock(); }
}

function buyDiamondPack(idx) {
  if (!acquireLock()) return;
  try {
    const pkg = _DIAMOND_PACKAGES[idx];
    if (!pkg) return;
    if (typeof DEBUG !== 'undefined' && DEBUG) {
      try {
        transaction(() => {
          state.diamond = _uiNum(state.diamond, 0) + _uiNum(pkg.amount, 0);
          if (pkg.bonusGold) state.gold = _uiNum(state.gold, 0) + _uiNum(pkg.bonusGold, 0);
          if (pkg.bonusCrystal) state.crystal = _uiNum(state.crystal, 0) + _uiNum(pkg.bonusCrystal, 0);
        });
      } catch (e) { showToast('خطا ❌', 'error'); return; }
      updateUI(); saveGame();
      showToast(`🎁 ${pkg.name} فعال شد (DEBUG)!`, 'success');
      playSFX('success');
      renderShopDiamondPacks();
    } else {
      showToast('⚠️ درگاه پرداخت هنوز متصل نیست. در نسخه نهایی فعال می‌شود.', 'error');
      playSFX('error');
    }
  } finally { releaseLock(); }
}

function buyGoldPack(idx) {
  if (!acquireLock()) return;
  try {
    const pkg = _GOLD_PACKAGES[idx];
    if (!pkg) return;
    if (typeof DEBUG !== 'undefined' && DEBUG) {
      try {
        transaction(() => {
          state.gold = _uiNum(state.gold, 0) + _uiNum(pkg.amount, 0);
          if (pkg.bonusCrystal) state.crystal = _uiNum(state.crystal, 0) + _uiNum(pkg.bonusCrystal, 0);
        });
      } catch (e) { showToast('خطا ❌', 'error'); return; }
      updateUI(); saveGame();
      showToast(`🎁 ${pkg.name} فعال شد (DEBUG)!`, 'success');
      playSFX('success');
      renderShopGoldPacks();
    } else {
      showToast('⚠️ درگاه پرداخت هنوز متصل نیست.', 'error');
      playSFX('error');
    }
  } finally { releaseLock(); }
}

function renderCrates() {
  let html = _renderShopHeader() + `<div class="shop-items"><div class="mission-note">صندوق‌ها فقط با کلید هم‌نوع باز می‌شوند و محدودیت روزانه ندارند. محتوای صندوق تا زمان باز شدن مخفی است.</div>`;
  for (const id of Object.keys(CRATE_DEFS || {})) {
    const def = CRATE_DEFS[id]; if (!def) continue;
    const keyCount = _uiNum(state.inventory && state.inventory[def.key], 0);
    html += `<div class="crate-card">
      <div class="crate-icon"><img src="${escapeHtml(def.icon)}" alt="${escapeHtml(def.name)}" style="width:100%;height:100%;object-fit:contain"></div>
      <div class="crate-info"><div class="crate-name">${escapeHtml(def.name)}</div>
      <div class="crate-meta">کلید موردنیاز: ${escapeHtml(resNames[def.key] || def.key)} — موجودی: ${toFa(keyCount)}</div></div>
      <button class="btn-buy" onclick="purchaseCrate('${id}')" ${keyCount < 1 ? 'disabled' : ''}>${keyCount ? 'باز کردن' : 'کلید نداری'}</button>
    </div>`;
  }
  html += `</div>`;
  const mc = $('modal-content'); if (mc) mc.innerHTML = html;
}

function getCrateRemaining(id) {
  return (CRATE_DEFS && CRATE_DEFS[id]) ? Number.MAX_SAFE_INTEGER : 0;
}
function canAffordCrate(id) {
  const def = CRATE_DEFS && CRATE_DEFS[id];
  return !!(def && state.inventory && _uiNum(state.inventory[def.key],0) >= 1);
}
function purchaseCrate(id) {
  if (!acquireLock()) return;
  try {
    const def = CRATE_DEFS && CRATE_DEFS[id];
    if (!def || !def.key) return;
    let rewards = null;
    try {
      transaction(() => {
        if (!_uiIsPlainObj(state.inventory)) state.inventory = {};
        if (_uiNum(state.inventory[def.key],0) < 1) throw new Error('no_key');
        state.inventory[def.key] -= 1;
        rewards = rollCrateRewards(id);
        applyReward(rewards);
      });
    } catch(e) {
      showToast(e.message === 'no_key' ? 'کلید مناسب این صندوق را نداری.' : 'باز کردن صندوق ناموفق بود.', 'error');
      return;
    }
    updateUI(); saveGame(); renderCrates();
    playCrateCinematic(def, rewards); playSFX('success');
  } finally { releaseLock(); }
}

function weightedPick(list) {
  if (!Array.isArray(list) || !list.length) return null;
  const total = list.reduce((sum, item) => sum + _uiNum(item.w, 1), 0);
  if (!isFinite(total) || total <= 0) return list[0];
  let roll = Math.random() * total;
  for (const item of list) {
    roll -= _uiNum(item.w, 1);
    if (roll <= 0) return item;
  }
  return list[list.length - 1];
}

function rollCrateRewards(id) {
  if (typeof CRATE_DEFS === 'undefined' || !CRATE_DEFS[id]) return {};
  const def = CRATE_DEFS[id];
  if (!def) return {};
  const rewards = {};
  const addReward = (key, amount) => {
    if (!key || _uiIsBadKey(key)) return;
    const a = _uiNum(amount, 0);
    if (a <= 0) return;
    rewards[key] = _uiNum(rewards[key], 0) + a;
  };
  let chosen = null;
  if (Math.random() < _uiNum(def.rareChance, 0)) {
    const rares = Array.isArray(def.pool) ? def.pool.filter(x => x && x.rare) : [];
    if (rares.length) chosen = weightedPick(rares);
  }
  if (!chosen) {
    const normals = Array.isArray(def.pool) ? def.pool.filter(x => x && !x.rare) : [];
    chosen = normals.length ? weightedPick(normals) : (Array.isArray(def.pool) ? weightedPick(def.pool) : null);
  }
  if (chosen) {
    if (chosen.res) addReward(chosen.res, chosen.n);
    if (chosen.inv) addReward(chosen.inv, chosen.n);
  }
  return rewards;
}

function applyReward(rewards) {
  if (!_uiIsPlainObj(rewards)) return;
  for (const key in rewards) {
    if (_uiIsBadKey(key)) continue;
    const amount = _uiNum(rewards[key], 0);
    if (amount <= 0) continue;
    if (state[key] !== undefined) {
      state[key] = _uiNum(state[key], 0) + amount;
    } else {
      if (!_uiIsPlainObj(state.inventory)) state.inventory = {};
      state.inventory[key] = _uiNum(state.inventory[key], 0) + amount;
    }
  }
}

function formatReward(rewards) {
  if (!_uiIsPlainObj(rewards)) return '—';
  const keys = Object.keys(rewards);
  if (!keys.length) return '—';
  return keys.filter(k => !_uiIsBadKey(k)).map(k => {
    const iconRaw = (typeof RES_ICON !== 'undefined' && RES_ICON[k]) || '🎁';
    const iconHtml = (typeof iconHTML === 'function') ? iconHTML(iconRaw, 18, '🎁') : iconRaw;
    const name = (typeof resNames !== 'undefined' && resNames[k]) || k;
    const amt = _uiNum(rewards[k], 0);
    if (amt <= 0) return '';
    return `${iconHtml} ${toFa(amt)} ${escapeHtml(name)}`;
  }).filter(Boolean).join(' | ');
}

function playCrateCinematic(def, rewards) {
  if (!def) return;
  const old = document.getElementById('crateCinematic'); if (old) old.remove();
  const overlay = document.createElement('div');
  overlay.id = 'crateCinematic';
  overlay.className = 'chest-anim-overlay show';
  overlay.innerHTML = `
    <img src="${escapeHtml(def.icon || 'ghost/chest1.png')}" class="chest-img-anim chest-shaking" id="animChestImg" alt="chest" onerror="this.src='ghost/chest1.png'">
    <div class="flash-effect" id="animFlash"></div>
    <div class="chest-reward-box" id="animRewardBox">
      <div class="chest-reward-title">🎉 صندوق باز شد!</div>
      <div class="chest-reward-text">${typeof formatReward === 'function' ? formatReward(rewards) : '—'}</div>
      <button class="btn-buy" onclick="document.getElementById('crateCinematic').remove()">دریافت جایزه ✅</button>
    </div>
  `;
  document.body.appendChild(overlay);
  const chest = document.getElementById('animChestImg');
  const flash = document.getElementById('animFlash');
  const rewardBox = document.getElementById('animRewardBox');
  setTimeout(() => {
    if (chest) chest.style.display = 'none';
    if (flash) flash.classList.add('flash-active');
    overlay.classList.add('overlay-flashing');
    playSoundFile('ghost/chest_bouns.mp3', 1.0);
    setTimeout(() => {
      if (flash) flash.style.display = 'none';
      overlay.classList.remove('overlay-flashing');
      if (rewardBox) rewardBox.style.display = 'flex';
    }, 1400);
  }, 1000);
}

function playLevelChestCinematic(goldReward) {
  const old = document.getElementById('levelChestCinematic'); if (old) old.remove();
  const overlay = document.createElement('div');
  overlay.id = 'levelChestCinematic';
  overlay.className = 'chest-anim-overlay show';
  const chestIcon = (_ICON && _ICON.chestDay) ? _ICON.chestDay : 'ghost/chest_for_upg_player.png';
  overlay.innerHTML = `
    <img src="${escapeHtml(chestIcon)}" class="chest-img-anim chest-shaking" id="lvlChestImg" alt="chest" onerror="this.onerror=null;this.src='ghost/chest1.png'">
    <div class="flash-effect" id="lvlChestFlash"></div>
    <div class="coin-burst-layer" id="lvlCoinLayer"></div>
    <div class="chest-reward-box" id="lvlChestRewardBox">
      <div class="chest-reward-title">🎉 صندوق لول‌آپ باز شد!</div>
      <div class="chest-reward-text">${iconHTML((_ICON && _ICON.gold) || 'ghost/coin.jpg', 22, '🪙')} +${toFa(goldReward)} طلا</div>
      <button class="btn-buy" onclick="document.getElementById('levelChestCinematic').remove()">دریافت جایزه ✅</button>
    </div>
  `;
  document.body.appendChild(overlay);
  const chest = document.getElementById('lvlChestImg');
  const flash = document.getElementById('lvlChestFlash');
  const coinLayer = document.getElementById('lvlCoinLayer');
  const rewardBox = document.getElementById('lvlChestRewardBox');
  const coinSrc = (_ICON && _ICON.gold) ? _ICON.gold : 'ghost/coin.jpg';

  setTimeout(() => {
    if (chest) chest.style.display = 'none';
    if (flash) flash.classList.add('flash-active');
    overlay.classList.add('overlay-flashing');
    playSoundFile('ghost/chest_bouns.mp3', 1.0);

    if (coinLayer) {
      const total = 50;
      for (let i = 0; i < total; i++) {
        const coin = document.createElement('img');
        coin.src = coinSrc;
        coin.className = 'burst-coin';
        coin.alt = '';
        const angle = (Math.PI * 2 * i) / total + (Math.random() - 0.5) * 0.4;
        const distance = 140 + Math.random() * 280;
        const tx = Math.cos(angle) * distance;
        const ty = Math.sin(angle) * distance;
        const rot = Math.random() * 1080 - 540;
        const dur = 1.3 + Math.random() * 0.9;
        const delay = Math.random() * 0.25;
        coin.style.setProperty('--tx', tx + 'px');
        coin.style.setProperty('--ty', ty + 'px');
        coin.style.setProperty('--rot', rot + 'deg');
        coin.style.setProperty('--dur', dur + 's');
        coin.style.setProperty('--delay', delay + 's');
        coinLayer.appendChild(coin);
      }
    }

    setTimeout(() => {
      if (flash) flash.style.display = 'none';
      overlay.classList.remove('overlay-flashing');
      if (rewardBox) rewardBox.style.display = 'flex';
    }, 1400);
  }, 1000);
}

function openLevelChest() {
  if (typeof acquireLock !== 'function' || !acquireLock()) return;
  try {
    if (!isFinite(state.unopenedLevelChests)) state.unopenedLevelChests = 0;
    state.unopenedLevelChests = Math.min(9999, Math.max(0, _uiInt(state.unopenedLevelChests, 0)));
    if (state.unopenedLevelChests <= 0) return;
    const lvl = Math.max(1, _uiInt(state.player_level, 1));
    const goldReward = Math.floor(lvl * 100 * (0.8 + Math.random() * 0.4));
    try {
      transaction(() => {
        state.unopenedLevelChests--;
        state.gold = _uiNum(state.gold, 0) + Math.max(0, goldReward);
      });
    } catch (e) { return; }
    updateUI(); saveGame();
    playLevelChestCinematic(goldReward);
    playSFX('success'); playSoundFile('ghost/chest_bouns.mp3', 0.8);
  } finally {
    if (typeof releaseLock === 'function') releaseLock();
  }
}

function toggleMusic() {
  const audio = $('bg-music'), btn = $('music-btn');
  if (!audio) return;
  try {
    if (audio.paused) {
      audio.play().then(() => {
        audio.volume = 1.0;
        if (btn) btn.textContent = '🔊';
        if (typeof lsSet === 'function') lsSet('bok_music', 'on');
      }).catch(() => {
        showToast('مرورگر اجازه پخش موسیقی را نمی‌دهد! ❌', 'error');
      });
    } else {
      audio.pause();
      if (btn) btn.textContent = '🔇';
      if (typeof lsSet === 'function') lsSet('bok_music', 'off');
    }
  } catch (e) {}
}

document.querySelectorAll('.building').forEach(img => {
  img.addEventListener('click', () => {
    if (typeof openBuildingModal === 'function') {
      openBuildingModal(img.dataset.type, img.getAttribute('src'));
    }
  });
});

document.querySelectorAll('.nav button').forEach(btn => {
  btn.addEventListener('click', () => {
    if (isLoadingScreenActive) return;
    document.querySelectorAll('.nav button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentBuilding = null;
    const navName = btn.dataset.nav;
    const icon = btn.dataset.icon;
    const bgUrl = btn.dataset.bg;
    const ls = $('loadingScreen');
    if (ls) {
      if (bgUrl) { ls.style.backgroundImage = `url('${escapeHtml(bgUrl)}')`; }
      else { ls.style.backgroundColor = '#0a1014'; ls.style.backgroundImage = 'none'; }
    }
    const lb = $('loadingBar');
    if (lb) {
      lb.style.animation = 'none';
      lb.offsetHeight;
      lb.style.animation = 'fillBar 0.8s ease-in-out forwards';
    }
    isLoadingScreenActive = true;
    if (ls) ls.classList.add('show');
    setTimeout(() => {
      if (ls) ls.classList.remove('show');
      isLoadingScreenActive = false;
      if (navName === 'نبرد') {
        if (typeof openBattleModal === 'function') openBattleModal();
        return;
      }
      if (navName === 'ماموریت‌ها') {
        if (typeof openMissions === 'function') openMissions();
        return;
      }
      const gm = $('gameModal');
      if (navName === 'برترین‌ها') {
        const mt = $('modal-title'); if (mt) mt.textContent = '🏆 برترین‌های پادشاهی';
        const mi = $('modal-img'); if (mi) mi.style.display = 'none';
        const mIcon = $('modal-icon'); if (mIcon) { mIcon.textContent = '🏆'; mIcon.style.display = 'block'; }
        try { if (typeof renderLeaderboard === 'function') renderLeaderboard(); } catch (e) { console.error(e); }
        if (gm) {
          if (bgUrl) { gm.style.backgroundImage = `linear-gradient(rgba(10,16,20,0.6), rgba(10,16,20,0.8)), url('${escapeHtml(bgUrl)}')`; }
          else { gm.style.backgroundImage = 'radial-gradient(circle at 50% 10%, #1a2930, #0a1014 90%)'; }
          gm.style.backgroundSize = 'cover';
          gm.style.backgroundPosition = 'center';
          gm.classList.add('show');
        }
        return;
      }
      if (navName === 'فروشگاه') {
        const mt = $('modal-title'); if (mt) mt.textContent = '🛒 بازار پادشاهی';
        const mi = $('modal-img'); if (mi) mi.style.display = 'none';
        const mIcon = $('modal-icon'); if (mIcon) { mIcon.textContent = '🛒'; mIcon.style.display = 'block'; }
        currentShopTab = 'resources';
        try { if (typeof renderShop === 'function') renderShop(); } catch (e) { console.error(e); }
        if (gm) {
          if (bgUrl) { gm.style.backgroundImage = `linear-gradient(rgba(10,16,20,0.7), rgba(10,16,20,0.9)), url('${escapeHtml(bgUrl)}')`; }
          else { gm.style.backgroundImage = 'radial-gradient(circle at 50% 10%, #1a2930, #0a1014 90%)'; }
          gm.style.backgroundSize = 'cover';
          gm.style.backgroundPosition = 'center';
          gm.classList.add('show');
        }
        return;
      }
      const mt = $('modal-title'); if (mt) mt.textContent = navName || '';
      const mi = $('modal-img'); if (mi) mi.style.display = 'none';
      const mIcon = $('modal-icon'); if (mIcon) { mIcon.textContent = icon || ''; mIcon.style.display = 'block'; }
      const mc = $('modal-content');
      if (mc) mc.innerHTML = `<div style="background:rgba(10,16,20,0.85);padding:30px;border-radius:15px;border:1px solid var(--gold);font-family:'Lalezar';font-size:20px;color:var(--gold);text-align:center;box-shadow:0 10px 30px rgba(0,0,0,0.8);margin-top:20px;">این بخش به‌زودی با امکانات کامل ساخته می‌شود...</div>`;
      if (gm) {
        if (bgUrl) { gm.style.backgroundImage = `linear-gradient(rgba(10,16,20,0.6), rgba(10,16,20,0.8)), url('${escapeHtml(bgUrl)}')`; }
        else { gm.style.backgroundImage = 'radial-gradient(circle at 50% 10%, #1a2930, #0a1014 90%)'; }
        gm.style.backgroundSize = 'cover';
        gm.style.backgroundPosition = 'center';
        gm.classList.add('show');
      }
    }, 800);
  });
});

document.addEventListener('click', (e) => {
  const btn = e.target.closest('button, .building, .nav button');
  if (!btn) return;
  const actualBtn = e.target.closest('button');
  if (actualBtn && actualBtn.disabled) playSFX('error');
  else playSFX('click');
});

document.addEventListener('click', (e) => {
  const interactiveEl = e.target.closest('button, .building, .btn-recruit, .btn-action, .btn-buy, .btn-upgrade, .btn-craft, .btn-speedup, .qty-btn, .p-btn');
  if (interactiveEl && isProcessing) {
    e.preventDefault();
    e.stopPropagation();
    if (!document.body.dataset.spamWarned) {
      document.body.dataset.spamWarned = "1";
      showToast('⏳ لطفاً صبر کنید...', 'error');
      setTimeout(() => { delete document.body.dataset.spamWarned; }, 800);
    }
  }
}, true);

// ============================================================
// ➕ باز کردن فروشگاه در تب الماس تومانی
// ============================================================
function openShopPaidTab() {
  const shopBtn = document.querySelector('.nav button[data-nav="فروشگاه"]');
  if (shopBtn) shopBtn.click();
  setTimeout(() => {
    if (typeof switchShopTab === 'function') switchShopTab('diamond_packs');
  }, 900);
}

// ============================================================
// ⚙️ مودال تنظیمات
// ============================================================
function openSettingsModal() {
  let overlay = document.getElementById('settingsModal');
  if (overlay) overlay.remove();
  
  overlay = document.createElement('div');
  overlay.id = 'settingsModal';
  overlay.className = 'full-modal show';
  overlay.style.background = 'radial-gradient(circle at 50% 10%,#1a2930,#0a1014 90%)';
  overlay.innerHTML = `
    <div class="modal-header">
      <h2 class="modal-title" style="padding-left:0;padding-right:15px;display:flex;align-items:center;gap:8px;">
        <img src="ghost/setting.png" style="width:28px;height:28px;object-fit:contain;" onerror="this.style.display='none'"> تنظیمات
      </h2>
    </div>
    <div class="modal-body" style="align-items:center;justify-content:flex-start;padding-top:20px;">
      <div style="background:rgba(0,0,0,0.5);padding:20px;border-radius:15px;border:1px solid var(--gold);width:100%;max-width:350px;text-align:right;display:flex;flex-direction:column;gap:18px;">
        
        <div>
          <div style="color:var(--gold);font-family:var(--font-persian);font-size:18px;margin-bottom:10px;">👤 حساب کاربری</div>
          <div style="display:flex;gap:5px;">
            <input type="text" id="set-username" value="${escapeHtml(state.commanderName || 'آرش')}" style="flex:1;padding:8px;border-radius:8px;border:1px solid #555;background:#0a1014;color:#fff;font-family:var(--font-persian);" maxlength="20">
            <button class="btn-action" style="margin:0;width:auto;padding:8px 15px;font-size:13px;" onclick="
              state.commanderName = document.getElementById('set-username').value.trim().slice(0,20) || 'آرش';
              if(typeof saveGame === 'function') saveGame();
              if(typeof updateUI === 'function') updateUI();
              if(typeof showToast === 'function') showToast('نام تغییر کرد ✅');
            ">ذخیره</button>
          </div>
        </div>

        <div>
          <div style="color:var(--gold);font-family:var(--font-persian);font-size:18px;margin-bottom:10px;">🔊 موسیقی</div>
          <button class="btn-action" style="margin:0;font-size:14px;" onclick="toggleMusic(); setTimeout(()=>{document.getElementById('settingsModal').remove();openSettingsModal();}, 300);">${($('bg-music') && !$('bg-music').paused) ? '🔇 قطع موسیقی' : '🔊 پخش موسیقی'}</button>
        </div>

        <div>
          <div style="color:var(--gold);font-family:var(--font-persian);font-size:18px;margin-bottom:10px;">✒️ فونت بازی</div>
          <div style="font-size:12px;color:#aaa;margin-bottom:8px;">فونت پیش‌فرض (PersianFont) فعال است.</div>
          <button class="btn-action" style="margin:0;font-size:14px;background:#555;color:#ccc;cursor:not-allowed;" disabled>🔒 به‌زودی: ۳ فونت</button>
        </div>

        <div>
          <div style="color:var(--gold);font-family:var(--font-persian);font-size:18px;margin-bottom:10px;">📞 پشتیبانی</div>
          <button class="btn-action" style="margin:0;margin-bottom:8px;font-size:13px;background:linear-gradient(180deg,#64b5f6,#1976d2);color:#fff;" onclick="
            if(typeof addMessage === 'function') addMessage('system', '🐞', 'گزارش باگ', 'سیستم گزارش باگ به‌زودی فعال می‌شود.');
            if(typeof showToast === 'function') showToast('📞 سیستم پشتیبانی به‌زودی فعال می‌شود');
          ">🐞 گزارش باگ</button>
          <button class="btn-action" style="margin:0;font-size:13px;background:linear-gradient(180deg,#81c784,#388e3c);color:#fff;" onclick="
            if(typeof addMessage === 'function') addMessage('system', '💡', 'پیشنهاد', 'سیستم پیشنهادات به‌زودی فعال می‌شود.');
            if(typeof showToast === 'function') showToast('💡 سیستم پیشنهادات به‌زودی فعال می‌شود');
          ">💡 پیشنهادات</button>
        </div>

        <div>
          <div style="color:#ff5252;font-family:var(--font-persian);font-size:18px;margin-bottom:10px;">⚠️ خطرناک</div>
          <button class="btn-action" style="margin:0;background:linear-gradient(180deg,#e53935,#b71c1c);color:#fff;font-size:13px;" onclick="
            if(confirm('⚠️ آیا واقعا می‌خواهی کل بازی را ریست کنی؟ تمام پیشرفتت پاک می‌شود و قابل بازگشت نیست!')) {
              localStorage.removeItem('bok_local_save');
              localStorage.removeItem('bok_backup');
              location.reload();
            }
          ">🗑️ ریست کامل بازی</button>
        </div>

      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn-close-full" onclick="document.getElementById('settingsModal').remove()">بستن تنظیمات</button>
    </div>
  `;
  document.body.appendChild(overlay);
  if (typeof playSFX === 'function') playSFX('click');
}


const FOMO_INTERVAL_MS = 20 * 60 * 1000;
const FOMO_VISIBLE_MS = 10 * 1000;
let _fomoActiveMs = 0;
let _fomoNextAt = FOMO_INTERVAL_MS;
let _fomoLastTickAt = Date.now();
let _fomoVisibleUntil = 0;
function tickFomoOffer(now = Date.now()) {
  const container = $('fomoOfferContainer');
  if (!container) return;
  if (document.hidden) {
    _fomoLastTickAt = now;
    if (_fomoVisibleUntil) {
      _fomoVisibleUntil = 0;
      _fomoNextAt = _fomoActiveMs + FOMO_INTERVAL_MS;
    }
    if (container.style.display !== 'none') { container.style.display = 'none'; container.innerHTML = ''; }
    return;
  }
  _fomoActiveMs += Math.max(0, now - _fomoLastTickAt);
  _fomoLastTickAt = now;
  if (_fomoVisibleUntil && now >= _fomoVisibleUntil) {
    _fomoVisibleUntil = 0;
    _fomoNextAt = _fomoActiveMs + FOMO_INTERVAL_MS;
    container.style.display = 'none'; container.innerHTML = '';
    return;
  }
  if (_fomoVisibleUntil > now) return;
  if (_fomoActiveMs >= _fomoNextAt) {
    _fomoVisibleUntil = now + FOMO_VISIBLE_MS;
    container.style.display = 'block';
    container.innerHTML = `<button class="fomo-rainbow-btn" type="button" onclick="openMissions()">🌈 فرصت ویژه! مأموریت‌ها را ببین</button>`;
  }
}
document.addEventListener('visibilitychange', () => {
  _fomoLastTickAt = Date.now();
  const c = $('fomoOfferContainer');
  if (document.hidden) {
    if (_fomoVisibleUntil) {
      _fomoVisibleUntil = 0;
      _fomoNextAt = _fomoActiveMs + FOMO_INTERVAL_MS;
    }
    if (c) { c.style.display = 'none'; c.innerHTML = ''; }
  }
});

function triggerFlashEvent() {
  if (!_uiIsPlainObj(state.flashEvent)) state.flashEvent = { active:false, target:'', expiresAt:0 };
  if (state.flashEvent.active && state.flashEvent.expiresAt > Date.now()) return;
  const targets = ['farm','mine','lumber'];
  state.flashEvent = { active:true, target:targets[Math.floor(Math.random()*targets.length)], expiresAt:Date.now()+60000 };
  saveGame();
  const targetName = state.flashEvent.target === 'farm' ? 'مزرعه' : state.flashEvent.target === 'mine' ? 'معدن' : 'چوب‌بری';
  showToast(`⚡ فرصت طلایی! برداشت بعدی از ${targetName} تا ۶۰ ثانیه دوبرابر است.`);
}
function triggerLiveTask() {
  const types = [
    { type:'harvest', title:'یک بار از منابع برداشت کن', target:1 },
    { type:'battle', title:'یک نبرد را پیروز شو', target:1 },
    { type:'upgrade', title:'یک ساختمان را ارتقا بده', target:1 },
    { type:'tax', title:'مالیات قلعه را جمع‌آوری کن', target:1 }
  ];
  const task = types[Math.floor(Math.random()*types.length)];
  state.liveTask = { active:true, type:task.type, title:task.title, progress:0, target:task.target, expiresAt:Date.now()+3*60*1000, cooldownUntil:Date.now()+8*60*1000 };
  saveGame();
  showToast(`⏱️ مأموریت فوری: ${task.title} — ۳ دقیقه فرصت داری!`);
}
function updateLiveTaskProgress(type, amount = 1) {
  const task = state.liveTask;
  if (!_uiIsPlainObj(task) || !task.active || task.type !== type || Date.now() > _uiNum(task.expiresAt,0)) return;
  task.progress = Math.min(_uiNum(task.target,1), _uiNum(task.progress,0) + Math.max(1,_uiNum(amount,1)));
  if (task.progress >= task.target) {
    task.active = false;
    const gold = 100, xp = 50;
    state.gold = _uiNum(state.gold,0) + gold;
    if (typeof addXP === 'function') addXP(xp);
    showToast(`🎉 مأموریت فوری کامل شد! ${toFa(gold)} طلا و ${toFa(xp)} XP`);
    updateUI();
  }
  saveGame();
}

// ============================================================
// 😍 سیستم پیشنهاد ویژه (Special Offer)
// ============================================================
function generateSpecialOffer() {
  const now = Date.now();
  if (!_uiIsPlainObj(state.specialOffer)) state.specialOffer = { active: false, nextOfferTime: 0 };
  if (state.specialOffer.active) return;
  if (now < _uiNum(state.specialOffer.nextOfferTime, 0)) return;

  const rAttack = Math.floor(Math.random() * 5) + 1;
  const rFarm = Math.floor(Math.random() * 5) + 1;
  const rMine = Math.floor(Math.random() * 5) + 1;
  const rLumber = Math.floor(Math.random() * 5) + 1;

  let isAnyMax = false;
  if (_uiIsPlainObj(state.buildings)) {
    for (const b in state.buildings) {
      if (state.buildings[b] >= 30) { isAnyMax = true; break; }
    }
  }

  let goldReward = Math.floor(Math.random() * 4000) + 1000;
  if (isAnyMax) goldReward = Math.floor(goldReward / 2);

  transaction(() => {
    state.specialOffer = {
      active: true,
      attackTarget: 0, attackReq: rAttack, attackCur: 0,
      farmReq: rFarm, farmCur: 0,
      mineReq: rMine, mineCur: 0,
      lumberReq: rLumber, lumberCur: 0,
      upgradeReq: isAnyMax ? 0 : 1, upgradeCur: 0,
      rewardGold: goldReward, rewardXP: 1000,
      isHalved: isAnyMax,
      nextOfferTime: 0
    };
  });
  saveGame();
  renderSpecialOfferBtn();
}

function renderSpecialOfferBtn() {
  const container = $('specialOfferContainer');
  if (!container) return;
  
  if (state.specialOffer && state.specialOffer.active) {
    container.style.display = 'block';
    container.innerHTML = `<button id="specialOfferBtn" onclick="openSpecialOfferModal()">😍 پیشنهاد ویژه!</button>`;
  } else {
    container.style.display = 'none';
    container.innerHTML = '';
  }
}

function openSpecialOfferModal() {
  const so = state.specialOffer;
  if (!so || !so.active) return;

  let tasksHtml = '';
  const createTask = (name, req, cur, icon) => {
    if (req === 0) return '';
    const isDone = cur >= req;
    return `<div class="offer-task ${isDone ? 'done' : ''}">
      <span>${icon} ${name}</span>
      <span class="offer-task-count">${toFa(cur)} / ${toFa(req)} ${isDone ? '✅' : ''}</span>
    </div>`;
  };

  tasksHtml += createTask(`حمله به راهزنان`, so.attackReq, so.attackCur, '⚔️');
  tasksHtml += createTask(`برداشت کامل از مزرعه`, so.farmReq, so.farmCur, '🌾');
  tasksHtml += createTask(`برداشت کامل از معدن`, so.mineReq, so.mineCur, '⛏️');
  tasksHtml += createTask(`برداشت کامل از چوب‌بری`, so.lumberReq, so.lumberCur, '🪵');
  tasksHtml += createTask(`ارتقای یک ساختمان`, so.upgradeReq, so.upgradeCur, '🏗️');

  const allDone = 
    (so.attackCur >= so.attackReq) &&
    (so.farmCur >= so.farmReq) &&
    (so.mineCur >= so.mineReq) &&
    (so.lumberCur >= so.lumberReq) &&
    (so.upgradeCur >= so.upgradeReq);

  const halvedText = so.isHalved ? `<br><span style="color:#ff5252; font-size:12px;">(به دلیل مکس بودن یکی از ساختمان‌ها، جایزه نصف شده است)</span>` : '';

  const html = `
    <div id="specialOfferModal" class="show" onclick="if(event.target===this) closeSpecialOfferModal()">
      <div class="offer-box" onclick="event.stopPropagation()">
        <div class="offer-title">😍 پیشنهاد ویژه پادشاه</div>
        <div style="font-size:12px; color:#aaa; text-align:center; margin-bottom:15px;">این کارها را انجام بده تا جایزه بگیری!</div>
        ${tasksHtml}
        <div class="offer-reward-box">
          🎁 جایزه شما:<br>
          <b style="color:#f5c66b; font-size:20px;">${toFa(so.rewardGold)} 🪙</b><br>
          <b style="color:#a855f7;">${toFa(so.rewardXP)} ⭐ XP</b>
          ${halvedText}
        </div>
        <button class="offer-btn-claim" id="offer-claim-btn" onclick="claimSpecialOffer()" ${allDone ? '' : 'disabled'}>
          ${allDone ? '🎁 دریافت جایزه' : '⏳ هنوز کامل نشده'}
        </button>
        <button class="offer-close" onclick="closeSpecialOfferModal()">✖</button>
      </div>
    </div>
  `;
  
  let modal = $('specialOfferModal');
  if (modal) modal.remove();
  
  const div = document.createElement('div');
  div.innerHTML = html;
  document.body.appendChild(div.firstElementChild);
}

function closeSpecialOfferModal() {
  const modal = $('specialOfferModal');
  if (modal) modal.classList.remove('show');
  setTimeout(() => { if (modal) modal.remove(); }, 300);
}

function claimSpecialOffer() {
  const so = state.specialOffer;
  if (!so || !so.active) return;
  
  const allDone = 
    (so.attackCur >= so.attackReq) &&
    (so.farmCur >= so.farmReq) &&
    (so.mineCur >= so.mineReq) &&
    (so.lumberCur >= so.lumberReq) &&
    (so.upgradeCur >= so.upgradeReq);
    
  if (!allDone) return;

  transaction(() => {
    state.gold = _uiNum(state.gold, 0) + so.rewardGold;
    addXP(so.rewardXP);
    state.specialOffer.active = false;
    state.specialOffer.nextOfferTime = Date.now() + 30 * 60 * 1000;
  });
  
  updateUI(); saveGame();
  closeSpecialOfferModal();
  renderSpecialOfferBtn();
  if (typeof showToast === 'function') showToast(`🎉 پیشنهاد ویژه انجام شد! ${toFa(so.rewardGold)} طلا و ${toFa(so.rewardXP)} XP گرفتی!`);
  if (typeof playSoundFile === 'function') playSoundFile('ghost/chest_bouns.mp3', 1.0);
}

function updateSpecialOfferProgress(type, detail) {
  const so = state.specialOffer;
  if (!so || !so.active) return;
  if (type === 'attack' && detail !== 0) return;
  
  if (type === 'attack' && so.attackCur < so.attackReq) so.attackCur++;
  if (type === 'farm' && so.farmCur < so.farmReq) so.farmCur++;
  if (type === 'mine' && so.mineCur < so.mineReq) so.mineCur++;
  if (type === 'lumber' && so.lumberCur < so.lumberReq) so.lumberCur++;
  if (type === 'upgrade' && so.upgradeCur < so.upgradeReq) so.upgradeCur++;
  
  saveGame();
  
  const modal = $('specialOfferModal');
  if (modal && modal.classList.contains('show')) {
    openSpecialOfferModal();
  }
}