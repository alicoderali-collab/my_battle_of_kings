// ============================================================
// 🕊️ BATTLE OF KINGS - js/peace.js (v2 - FINAL)
// پیمان صلح + انتقال تجهیزات
// لود: بعد از buildings.js، قبل از battle.js
// ============================================================

const _pNum = (v, fb = 0) => { v = Number(v); return isFinite(v) && v >= 0 ? v : fb; };
const _pInt = (v, fb = 0) => Math.floor(_pNum(v, fb));
const _pObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const _pTx  = (fn) => (typeof transaction === 'function') ? transaction(fn) : fn();
const _pIcon = (path, size, fb) => (typeof iconHTML === 'function') ? iconHTML(path, size, fb) : (fb || '');

function _getPeaceCfg() {
  if (typeof PEACE_TREATY_CONFIG !== 'undefined' && PEACE_TREATY_CONFIG) {
    return PEACE_TREATY_CONFIG;
  }
  return { costPerHour: 50, wallPerTreaty: 1, durations: [1, 5, 10, 24, 48, 72], maxDuration: 72 };
}

function _getEqDef() {
  if (typeof EQUIPMENT_DEFENSE !== 'undefined' && EQUIPMENT_DEFENSE) {
    return EQUIPMENT_DEFENSE;
  }
  return { wall: 2, catapult: 10 };
}

function fmtClock(ms) {
  return typeof fmtDur === 'function' ? fmtDur(ms) : formatTime(ms);
}

function resetPeaceTreaty() {
  state.peaceTreaty = { activeUntil: 0, startTime: 0, hours: 0, totalCost: { gold: 0, wall: 0 } };
}

function ensurePeaceState() {
  if (!_pObj(state.peaceTreaty)) resetPeaceTreaty();
  const pt = state.peaceTreaty;
  pt.activeUntil = _pNum(pt.activeUntil, 0);
  pt.startTime = _pNum(pt.startTime, 0);
  pt.hours = Math.min(_getPeaceCfg().maxDuration, _pInt(pt.hours, 0));
  if (!_pObj(pt.totalCost)) pt.totalCost = { gold: 0, wall: 0 };
  pt.totalCost.gold = _pInt(pt.totalCost.gold, 0);
  pt.totalCost.wall = _pInt(pt.totalCost.wall, 0);
  const maxFuture = Date.now() + (_getPeaceCfg().maxDuration + 1) * 3600000;
  if (pt.activeUntil > maxFuture) pt.activeUntil = maxFuture;
  if (pt.activeUntil > 0 && pt.activeUntil <= Date.now()) resetPeaceTreaty();
  if (!_pObj(state.watchtowerEquipment)) state.watchtowerEquipment = { wall: 0, catapult: 0 };
  state.watchtowerEquipment.wall = Math.min(99999, _pInt(state.watchtowerEquipment.wall, 0));
  state.watchtowerEquipment.catapult = Math.min(99999, _pInt(state.watchtowerEquipment.catapult, 0));
}

function isPeaceTreatyActive() {
  if (typeof state === 'undefined' || !_pObj(state.peaceTreaty)) return false;
  return _pNum(state.peaceTreaty.activeUntil, 0) > Date.now();
}

function getPeaceTreatyRemainingMs() {
  return isPeaceTreatyActive() ? Math.max(0, state.peaceTreaty.activeUntil - Date.now()) : 0;
}

function getWatchtowerDefenseCapacity() {
  const lvl = Math.max(1, Math.min(30, _pInt(state.buildings && state.buildings.watchtower, 1)));
  if (lvl <= 6) return 10 * Math.pow(2, lvl - 1);
  return Math.floor(320 + (lvl - 6) * (1000 - 320) / 24);
}

function getUsedDefenseCapacity() {
  const eq = _pObj(state.watchtowerEquipment) ? state.watchtowerEquipment : { wall: 0, catapult: 0 };
  const def = _getEqDef();
  return _pInt(eq.wall, 0) * def.wall + _pInt(eq.catapult, 0) * def.catapult;
}

function getRemainingDefenseCapacity() {
  return Math.max(0, getWatchtowerDefenseCapacity() - getUsedDefenseCapacity());
}

function activatePeaceTreaty(hours) {
  if (!acquireLock()) return;
  try {
    ensurePeaceState();
    const cfg = _getPeaceCfg();
    hours = _pInt(hours, 0);
    if (!cfg.durations.includes(hours)) { showToast('مدت نامعتبر ❌', 'error'); playSFX('error'); return; }
    if (isPeaceTreatyActive()) { showToast('پیمان صلح فعال است ⏳', 'error'); playSFX('error'); return; }
    if (state.battle && state.battle.inProgress) { showToast('تا پایان نبرد جاری صبر کن ⚔️', 'error'); playSFX('error'); return; }
    const goldCost = cfg.costPerHour * hours;
    const wallCost = cfg.wallPerTreaty;
    if (_pNum(state.gold, 0) < goldCost) { showToast(`طلا کافی نیست (${toFa(goldCost)} طلا) ❌`, 'error'); playSFX('error'); return; }
    if (_pInt(state.inventory && state.inventory.wall, 0) < wallCost) { showToast(`دیوار کافی نیست (${toFa(wallCost)} دیوار) ❌`, 'error'); playSFX('error'); return; }
    try {
      _pTx(() => {
        if (!spendGold(goldCost)) throw new Error('no gold');
        if (!_pObj(state.inventory)) state.inventory = {};
        state.inventory.wall = Math.max(0, _pInt(state.inventory.wall, 0) - wallCost);
        const now = Date.now();
        state.peaceTreaty = { activeUntil: now + hours * 3600000, startTime: now, hours: hours, totalCost: { gold: goldCost, wall: wallCost } };
      });
    } catch (e) { showToast('خطا در فعال‌سازی ❌', 'error'); playSFX('error'); return; }
    updateUI(); saveGame();
    if (hours === 24 && typeof missionAdd === 'function') missionAdd('peace24', 1);
    if (currentBuilding === 'watchtower') updatePeaceTreatyUI();
    if (typeof addMessage === 'function') addMessage('system', '🕊️', 'پیمان صلح فعال شد', `قلعه تا ${toFa(hours)} ساعت در امان است.`);
    showToast(`🕊️ پیمان صلح ${toFa(hours)} ساعته فعال شد!`);
    playSFX('success'); playSoundFile('ghost/dropping-single-coin.mp3', 0.6);
  } finally { releaseLock(); }
}

function showPeaceTreatyCancelConfirm() {
  if (!isPeaceTreatyActive()) { showToast('پیمان صلح فعالی نیست', 'error'); return; }
  const old = document.getElementById('peaceCancelConfirm'); if (old) old.remove();
  const cost = _pObj(state.peaceTreaty.totalCost) ? state.peaceTreaty.totalCost : { gold: 0, wall: 0 };
  const overlay = document.createElement('div');
  overlay.id = 'peaceCancelConfirm';
  overlay.className = 'epic-report-overlay';
  overlay.setAttribute('onclick', 'if(event.target===this) this.remove()');
  overlay.innerHTML = `
    <div class="epic-report-box" style="max-width:420px;" onclick="event.stopPropagation()">
      <div class="epic-title" style="color:#ff5252;">⚠️ لغو پیمان صلح</div>
      <div class="epic-subtitle">آیا واقعاً می‌خواهی این کار را انجام بدهی؟</div>
      <div class="epic-section" style="border-color:#ff5252;background:rgba(255,82,82,0.1);">
        <div class="epic-section-title" style="color:#ff5252;">🚨 هشدار مهم</div>
        <div class="epic-section-text" style="color:#fff;">با لغو پیمان، <b style="color:#ff5252;">هیچ‌کدام از منابع خرج‌شده برنمی‌گردد</b> و محافظت قلعه فوراً از بین می‌رود.</div>
      </div>
      <div class="epic-section">
        <div class="epic-section-title">💸 منابعی که از دست می‌دهی</div>
        <div class="epic-section-text">${_pIcon(_ICON.gold, 16, '🪙')} ${toFa(cost.gold)} طلا<br>${_pIcon(_ICON.wall, 16, '🧱')} ${toFa(cost.wall)} دیوار</div>
      </div>
      <div class="epic-section"><div class="epic-section-text" style="color:#f5c66b;">⏳ زمان باقی‌مانده: ${fmtClock(getPeaceTreatyRemainingMs())}</div></div>
      <div style="display:flex;gap:8px;margin-top:15px;">
        <button class="btn-close-epic" style="background:linear-gradient(180deg,#e53935,#b71c1c);" onclick="confirmCancelPeaceTreaty()">بله، لغو کن ❌</button>
        <button class="btn-close-epic" style="background:linear-gradient(180deg,#4caf50,#2e7d32);" onclick="document.getElementById('peaceCancelConfirm').remove()">نه، ادامه بده ✅</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  playSFX('error');
}

function confirmCancelPeaceTreaty() {
  const overlay = document.getElementById('peaceCancelConfirm'); if (overlay) overlay.remove();
  if (!acquireLock()) return;
  try {
    if (!isPeaceTreatyActive()) { showToast('پیمان صلح فعالی نیست', 'error'); return; }
    try { _pTx(() => { resetPeaceTreaty(); }); }
    catch (e) { showToast('خطا در لغو ❌', 'error'); playSFX('error'); return; }
    updateUI(); saveGame();
    if (currentBuilding === 'watchtower') updatePeaceTreatyUI();
    if (typeof addMessage === 'function') addMessage('system', '🕊️', 'پیمان صلح لغو شد', 'محافظت قلعه از بین رفت. منابع بازگشت نداشتند.');
    showToast('پیمان صلح لغو شد — منابع بازنگشتند', 'error');
    playSFX('error');
  } finally { releaseLock(); }
}

function updatePeaceTreatyUI() {
  if (currentBuilding !== 'watchtower') return;
  const c = $('watchtower-dynamic-content'); if (!c) return;
  ensurePeaceState();
  const cfg = _getPeaceCfg();
  const def = _getEqDef();
  const lvl = Math.max(1, _pInt(state.buildings && state.buildings.watchtower, 1));
  const active = isPeaceTreatyActive();
  const capacity = getWatchtowerDefenseCapacity();
  const used = getUsedDefenseCapacity();
  const free = Math.max(0, capacity - used);
  const eq = state.watchtowerEquipment;
  const eqWall = _pInt(eq.wall, 0);
  const eqCat = _pInt(eq.catapult, 0);
  const invWall = _pInt(state.inventory && state.inventory.wall, 0);
  const invCat = _pInt(state.inventory && state.inventory.catapult, 0);

  let html = `<div class="farm-ui">
    <div class="level-text">🕊️ پیمان‌نامه صلح (سطح برج ${toFa(lvl)})</div>
    <div style="font-size:12px;color:#8bc34a;">هزینه: ${toFa(cfg.costPerHour)} طلا در ساعت + ${toFa(cfg.wallPerTreaty)} دیوار</div>
    <div style="font-size:12px;color:#ccc;">در طول پیمان قلعه امن است، ولی خودت هم نمی‌توانی حمله کنی.</div>
  </div>`;

  if (active) {
    html += `<div class="farm-ui" style="border-color:#4caf50;border-width:2px;">
      <div style="font-size:16px;color:#4caf50;font-weight:bold;">✅ پیمان صلح فعال است</div>
      <div style="font-size:20px;color:var(--gold);margin-top:6px;">${_pIcon(_ICON.timer, 18, '⏱️')} <b id="peace-timer">${fmtClock(getPeaceTreatyRemainingMs())}</b></div>
      <button class="btn-cancel-craft" onclick="showPeaceTreatyCancelConfirm()">⚠️ لغو پیمان صلح</button>
    </div>`;
  } else {
    html += `<div class="farm-ui"><div class="level-text">⏰ انتخاب مدت پیمان</div>
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px;">` +
      cfg.durations.map(h => {
        const g = cfg.costPerHour * h;
        const can = _pNum(state.gold, 0) >= g && invWall >= cfg.wallPerTreaty;
        return `<button class="btn-action" style="margin:0;padding:10px 6px;font-size:13px;" onclick="activatePeaceTreaty(${h})" ${can ? '' : 'disabled'}>${toFa(h)} ساعت<br><span style="font-size:11px;">${_pIcon(_ICON.gold, 12, '🪙')} ${toFa(g)} + ${_pIcon(_ICON.wall, 12, '🧱')} ${toFa(cfg.wallPerTreaty)}</span></button>`;
      }).join('') + `</div></div>`;
  }

  html += `<div class="farm-ui">
    <div class="level-text">🛡️ ظرفیت دفاعی برج</div>
    <div class="progress-container" style="height:24px;margin:8px 0;">
      <div class="progress-bar" style="width:${capacity > 0 ? Math.min(100, used / capacity * 100) : 0}%;background:linear-gradient(90deg,#1976d2,#42a5f5);"></div>
      <div class="progress-text" style="font-size:12px;">${toFa(used)} / ${toFa(capacity)} واحد</div>
    </div>
    
    <div style="background:rgba(0,0,0,0.35);border-radius:10px;padding:12px;margin:8px 0;border:1px solid rgba(255,255,255,0.1);">
      <div style="display:flex;align-items:center;justify-content:space-between;font-size:13px;color:#eee;margin-bottom:8px;padding-bottom:8px;border-bottom:1px solid rgba(255,255,255,0.1);">
        <span style="display:flex;align-items:center;gap:6px;">${_pIcon(_ICON.wall, 22, '🧱')} <b>دیوار نصب‌شده:</b></span>
        <span style="text-align:left;">
          <b style="color:#4caf50;font-size:16px;">${toFa(eqWall)}</b> عدد 
          <span style="color:#888;">×</span> 
          <span style="color:#aaa;">${toFa(def.wall)} واحد</span> 
          <span style="color:#888;">=</span> 
          <b style="color:#f5c66b;font-size:15px;">${toFa(eqWall * def.wall)} واحد</b>
        </span>
      </div>
      <div style="display:flex;align-items:center;justify-content:space-between;font-size:13px;color:#eee;">
        <span style="display:flex;align-items:center;gap:6px;">${_pIcon(_ICON.catapult, 22, '🪃')} <b>منجنیق نصب‌شده:</b></span>
        <span style="text-align:left;">
          <b style="color:#4caf50;font-size:16px;">${toFa(eqCat)}</b> عدد 
          <span style="color:#888;">×</span> 
          <span style="color:#aaa;">${toFa(def.catapult)} واحد</span> 
          <span style="color:#888;">=</span> 
          <b style="color:#f5c66b;font-size:15px;">${toFa(eqCat * def.catapult)} واحد</b>
        </span>
      </div>
    </div>
    
    <div style="display:flex;justify-content:space-between;font-size:12px;color:#ccc;padding:0 4px;">
      <span>📦 استفاده‌شده: <b style="color:#f5c66b;">${toFa(used)}</b> واحد</span>
      <span>✨ خالی: <b style="color:#4caf50;">${toFa(free)}</b> واحد</span>
    </div>
    
    <button class="btn-action" style="background:linear-gradient(180deg,#64b5f6,#1976d2);color:#fff;margin-top:10px;" onclick="openEquipmentTransferModal()">📦 انتقال تجهیزات</button>
  </div>
  
  <div class="farm-ui">
    <div class="level-text">📊 موجودی انبار (آماده برای نصب)</div>
    <div style="font-size:13px;color:#eee;line-height:1.8;">
      ${_pIcon(_ICON.wall, 18, '🧱')} دیوار: <b style="color:#f5c66b;">${toFa(invWall)}</b> عدد<br>
      ${_pIcon(_ICON.catapult, 18, '🪃')} منجنیق: <b style="color:#f5c66b;">${toFa(invCat)}</b> عدد
    </div>
  </div>`;

  if (c.dataset.h !== html) { c.dataset.h = html; c.innerHTML = html; }

  if (window._peaceTimerInterval) clearInterval(window._peaceTimerInterval);
  if (active) {
    window._peaceTimerInterval = setInterval(() => {
      if (currentBuilding !== 'watchtower') { clearInterval(window._peaceTimerInterval); window._peaceTimerInterval = null; return; }
      const el = document.getElementById('peace-timer');
      if (!el) { clearInterval(window._peaceTimerInterval); window._peaceTimerInterval = null; return; }
      const rem = getPeaceTreatyRemainingMs();
      if (rem <= 0) {
        clearInterval(window._peaceTimerInterval); window._peaceTimerInterval = null;
        // ✅ FIX: پیمان رو ریست نمی‌کنیم و toast نمی‌زنیم. تایمر global (پایین) این کار رو انجام می‌ده.
        // فقط UI رو آپدیت می‌کنیم.
        try { updatePeaceTreatyUI(); } catch (e) {}
      } else { el.textContent = fmtClock(rem); }
    }, 1000);
  }
}

function openEquipmentTransferModal() {
  ensurePeaceState();
  const cfg = _getPeaceCfg();
  const def = _getEqDef();
  const free = getRemainingDefenseCapacity();
  const capacity = getWatchtowerDefenseCapacity();
  const invWall = _pInt(state.inventory && state.inventory.wall, 0);
  const invCat = _pInt(state.inventory && state.inventory.catapult, 0);
  const stWall = _pInt(state.watchtowerEquipment.wall, 0);
  const stCat = _pInt(state.watchtowerEquipment.catapult, 0);
  const old = document.getElementById('equipmentTransferModal'); if (old) old.remove();

  const row = (key, name, icon, fb, inv, stored, val) => `
    <div style="background:rgba(0,0,0,0.4);padding:12px;border-radius:10px;margin-bottom:12px;border:1px solid rgba(255,255,255,0.1);">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
        ${_pIcon(icon, 24, fb)}<span style="font-size:15px;color:#fff;">${name}</span>
        <span style="font-size:11px;color:#aaa;margin-right:auto;">${toFa(val)} واحد هر عدد</span>
      </div>
      <div style="font-size:12px;color:#ccc;margin-bottom:8px;">انبار: <b style="color:#f5c66b;">${toFa(inv)}</b> | نصب‌شده: <b style="color:#4caf50;">${toFa(stored)}</b></div>
      <div style="display:flex;gap:6px;">
        <button class="btn-action" onclick="installEquipment('${key}', 1)" style="background:linear-gradient(180deg,#4caf50,#2e7d32);color:#fff;margin:0;flex:1;padding:8px;font-size:13px;">⬆️ نصب ۱</button>
        <button class="btn-action" onclick="uninstallEquipment('${key}', 1)" style="background:linear-gradient(180deg,#f57c00,#e65100);color:#fff;margin:0;flex:1;padding:8px;font-size:13px;">⬇️ برداشت ۱</button>
      </div>
    </div>`;

  const overlay = document.createElement('div');
  overlay.id = 'equipmentTransferModal';
  overlay.style.cssText = 'position:fixed;inset:0;z-index:5000;background:rgba(0,0,0,0.9);backdrop-filter:blur(5px);display:flex;align-items:center;justify-content:center;padding:15px;';
  overlay.setAttribute('onclick', 'if(event.target===this) this.remove()');
  overlay.innerHTML = `
    <div style="background:linear-gradient(180deg,#1a252b,#0a1014);border:2px solid var(--gold);border-radius:15px;width:100%;max-width:450px;max-height:85vh;overflow-y:auto;padding:20px;" onclick="event.stopPropagation()">
      <div style="text-align:center;color:var(--gold);font-size:20px;margin-bottom:10px;">📦 انتقال تجهیزات</div>
      <div style="text-align:center;color:#aaa;font-size:12px;margin-bottom:15px;">ظرفیت آزاد: <b style="color:#4caf50;">${toFa(free)}</b> از ${toFa(capacity)}</div>
      ${row('wall', 'دیوار', _ICON.wall, '🧱', invWall, stWall, def.wall)}
      ${row('catapult', 'منجنیق', _ICON.catapult, '🪃', invCat, stCat, def.catapult)}
      <button class="btn-action" onclick="document.getElementById('equipmentTransferModal').remove()" style="background:linear-gradient(180deg,#a84b4b,#7a2e2e);color:#fff;">بستن</button>
    </div>`;
  document.body.appendChild(overlay);
  playSFX('click');
}

function installEquipment(type, qty) {
  if (!acquireLock()) return;
  try {
    if (type !== 'wall' && type !== 'catapult') return;
    ensurePeaceState();
    const def = _getEqDef();
    qty = Math.max(1, _pInt(qty, 1));
    const eq = state.watchtowerEquipment;
    const cap = getWatchtowerDefenseCapacity();
    const used = getUsedDefenseCapacity();
    const unitCost = (type === 'wall') ? def.wall : def.catapult;
    if (used + qty * unitCost > cap) { showToast('ظرفیت برج کافی نیست! ❌', 'error'); playSFX('error'); return; }
    if (!_pObj(state.inventory)) state.inventory = {};
    const have = _pInt(state.inventory[type], 0);
    if (have < qty) { showToast(`${type === 'wall' ? 'دیوار' : 'منجنیق'} کافی نداری! ❌`, 'error'); playSFX('error'); return; }
    try {
      _pTx(() => { state.inventory[type] = have - qty; eq[type] = _pInt(eq[type], 0) + qty; });
    } catch (e) { showToast('خطا در نصب ❌', 'error'); playSFX('error'); return; }
    updateUI(); saveGame();
    if (currentBuilding === 'watchtower') updatePeaceTreatyUI();
    showToast(`✅ ${toFa(qty)} ${type === 'wall' ? 'دیوار' : 'منجنیق'} نصب شد.`);
    playSFX('success');
  } finally { releaseLock(); }
}

function uninstallEquipment(type, qty) {
  if (!acquireLock()) return;
  try {
    if (type !== 'wall' && type !== 'catapult') return;
    ensurePeaceState();
    qty = Math.max(1, _pInt(qty, 1));
    const eq = state.watchtowerEquipment;
    const stored = _pInt(eq[type], 0);
    if (stored <= 0) { showToast('چیزی نصب نشده ❌', 'error'); playSFX('error'); return; }
    if (qty > stored) qty = stored;
    if (!_pObj(state.inventory)) state.inventory = {};
    try {
      _pTx(() => {
        eq[type] = stored - qty;
        state.inventory[type] = _pInt(state.inventory[type], 0) + qty;
      });
    } catch (e) { showToast('خطا در برداشت ❌', 'error'); playSFX('error'); return; }
    updateUI(); saveGame();
    if (currentBuilding === 'watchtower') updatePeaceTreatyUI();
    showToast(`✅ ${toFa(qty)} ${type === 'wall' ? 'دیوار' : 'منجنیق'} به انبار برگشت.`);
    playSFX('success');
  } finally { releaseLock(); }
}

// ============================================================
// 🔄 Override های قدیمی — بدون این‌ها buildings.js کرش می‌کند
// ============================================================
function updateWatchtowerUI() { return updatePeaceTreatyUI(); }
function addWatchtowerAlert() { return false; }
function isNightPatrolActive() { return false; }
function getPatrolDefenseBonus() { return 0; }
function getPatrolXPBonus() { return 0; }

// ⏱️ تیکر پیمان صلح
let _peaceWasActive = false;
let _peaceGlobalTimer = null;
function _runPeaceGlobalTick() {
  try {
    if (typeof state === 'undefined' || !state) return;
    const active = isPeaceTreatyActive();
    if (_peaceWasActive && !active) {
      resetPeaceTreaty();
      if (typeof saveGame === 'function') saveGame();
      showToast('🕊️ پیمان صلح به پایان رسید.', 'error');
    }
    _peaceWasActive = active;
  } catch (e) {}
}
function _startPeaceGlobalTimer() {
  if (_peaceGlobalTimer || document.hidden) return;
  _peaceGlobalTimer = setInterval(_runPeaceGlobalTick, 2000);
}
function _stopPeaceGlobalTimer() {
  if (_peaceGlobalTimer) { clearInterval(_peaceGlobalTimer); _peaceGlobalTimer = null; }
}
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    _runPeaceGlobalTick(); _stopPeaceGlobalTimer();
    if (window._peaceTimerInterval) { clearInterval(window._peaceTimerInterval); window._peaceTimerInterval = null; }
  } else {
    _startPeaceGlobalTimer();
    if (currentBuilding === 'watchtower') updatePeaceTreatyUI();
  }
});
_startPeaceGlobalTimer();