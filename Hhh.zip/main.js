// ============================================================
// ⚔️ BATTLE OF KINGS - js/main.js (v9 - MASTER FINAL)
// ============================================================

const _mNum = (v, fb) => { if (typeof v !== 'number') v = Number(v); return isFinite(v) && v >= 0 ? v : (fb || 0); };
const _mInt = (v, fb) => Math.floor(_mNum(v, fb));
const _mIsPlainObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);

let _lastTickTime = Date.now();
let _lastSaveTime = 0;
let _booted = false;
const MAX_TICK_DELTA_SEC = 7 * 24 * 60 * 60;
const SAVE_INTERVAL_MS = 5000;

function gameTick() {
  const now = Date.now();
  let dt = (now - _lastTickTime) / 1000;
  if (!isFinite(dt)) { _lastTickTime = now; return; }
  if (dt < 0) dt = 0;
  if (dt > MAX_TICK_DELTA_SEC) dt = MAX_TICK_DELTA_SEC;
  _lastTickTime = now;
  let needSave = false;
  let _barracksUIRenderedThisTick = false;

  // 🌾 Farm
  try {
    if (_mIsPlainObj(state.farm) && state.farm.isProducing) {
      const lvl = Math.max(1, _mInt(state.buildings && state.buildings.farm, 1));
      const cap = typeof getProdCapacity === 'function' ? getProdCapacity('farm') : 200 + ((lvl - 1) * 400);
      const curA = _mNum(state.farm.accumulatedAzooghe, 0);
      const curW = _mNum(state.farm.accumulatedWood, 0);
      const cur = curA + curW;
      if (cur < cap) {
        const startTime = _mNum(state.farm.startTime, now);
        if (startTime > 0) {
          const elMin = Math.floor((now - startTime) / 60000);
          if (elMin > _mInt(state.farm.lastAnimatedMinute, 0)) {
            if (typeof spawnIcon === 'function') spawnIcon('🌾', '10%', '32%');
            state.farm.lastAnimatedMinute = elMin;
          }
        }
        const rates = typeof getProdRatePerMin === 'function' ? getProdRatePerMin('farm') : { azooghe: 4 * lvl, wood: 2 * lvl };
        let a = (dt * rates.azooghe) / 60;
        let w = (dt * rates.wood) / 60;
        const tot = a + w;
        if (isFinite(tot) && tot > 0) {
          if (cur + tot > cap) { const r = (cap - cur) / tot; a *= r; w *= r; }
          if (isFinite(a) && a > 0) state.farm.accumulatedAzooghe = curA + a;
          if (isFinite(w) && w > 0) state.farm.accumulatedWood = curW + w;
        }
        needSave = true;
      }
      if (currentBuilding === 'farm' && typeof updateFarmModalUI === 'function') {
        try { updateFarmModalUI(); } catch (e) {}
      }
      state.farm.lastTickTime = now;
    }
  } catch (e) { console.warn('Farm tick failed:', e); }

  // ⛏️ Mine
  try {
    if (_mIsPlainObj(state.mine) && state.mine.isProducing) {
      const lvl = Math.max(1, _mInt(state.buildings && state.buildings.mine, 1));
      const cap = typeof getProdCapacity === 'function' ? getProdCapacity('mine') : 300 + ((lvl - 1) * 500);
      const curS = _mNum(state.mine.accumulatedStone, 0);
      const curC = _mNum(state.mine.accumulatedCoal, 0);
      const curD = _mNum(state.mine.accumulatedDiamond, 0);
      const cur = curS + curC + curD;
      if (cur < cap) {
        const startTime = _mNum(state.mine.startTime, now);
        if (startTime > 0) {
          const elMin = Math.floor((now - startTime) / 60000);
          if (elMin > _mInt(state.mine.lastAnimatedMinute, 0)) {
            if (typeof spawnIcon === 'function') spawnIcon('🪨', '10%', '15%');
            state.mine.lastAnimatedMinute = elMin;
          }
        }
        const rates = typeof getProdRatePerMin === 'function' ? getProdRatePerMin('mine') : { stone: 12 * lvl, coal: 3 * lvl, diamond: 0.1 * lvl };
        let s = (dt * rates.stone) / 60;
        let c = (dt * rates.coal) / 60;
        let d = (dt * rates.diamond) / 60;
        const tot = s + c + d;
        if (isFinite(tot) && tot > 0) {
          if (cur + tot > cap) { const r = (cap - cur) / tot; s *= r; c *= r; d *= r; }
          if (isFinite(s) && s > 0) state.mine.accumulatedStone = curS + s;
          if (isFinite(c) && c > 0) state.mine.accumulatedCoal = curC + c;
          if (isFinite(d) && d > 0) state.mine.accumulatedDiamond = curD + d;
        }
        needSave = true;
      }
      if (currentBuilding === 'mine' && typeof updateMineModalUI === 'function') {
        try { updateMineModalUI(); } catch (e) {}
      }
      state.mine.lastTickTime = now;
    }
  } catch (e) { console.warn('Mine tick failed:', e); }

  // 🪵 Lumber
  try {
    if (_mIsPlainObj(state.lumberProd) && state.lumberProd.isProducing) {
      const lvl = Math.max(1, _mInt(state.buildings && state.buildings.lumber, 1));
      const cap = typeof getProdCapacity === 'function' ? getProdCapacity('lumberProd') : 200 + ((lvl - 1) * 400);
      const cur = _mNum(state.lumberProd.accumulatedWood, 0);
      if (cur < cap) {
        const startTime = _mNum(state.lumberProd.startTime, now);
        if (startTime > 0) {
          const elMin = Math.floor((now - startTime) / 60000);
          if (elMin > _mInt(state.lumberProd.lastAnimatedMinute, 0)) {
            if (typeof spawnIcon === 'function') spawnIcon('🪵', '70%', '20%');
            state.lumberProd.lastAnimatedMinute = elMin;
          }
        }
        const rates = typeof getProdRatePerMin === 'function' ? getProdRatePerMin('lumberProd') : { wood: 8 * lvl };
        let w = (dt * rates.wood) / 60;
        if (isFinite(w) && w > 0) {
          if (cur + w > cap) w = cap - cur;
          state.lumberProd.accumulatedWood = cur + w;
        }
        needSave = true;
      }
      if (currentBuilding === 'lumber' && typeof updateLumberModalUI === 'function') {
        try { updateLumberModalUI(); } catch (e) {}
      }
      state.lumberProd.lastTickTime = now;
    }
  } catch (e) { console.warn('Lumber tick failed:', e); }

  // ⚒️ Smith
  try {
    if (_mIsPlainObj(state.smith) && state.smith.isCrafting && state.smith.endTime > 0) {
      if (now >= state.smith.endTime) {
        state.smith.isCrafting = false;
        state.smith.isReady = true;
        if (currentBuilding === 'smith' && typeof updateSmithModalUI === 'function') {
          try { updateSmithModalUI(); } catch (e) {}
        }
        if (typeof showToast === 'function') showToast('ساخت محصولات آهنگری به پایان رسید!');
      } else if (currentBuilding === 'smith' && typeof updateSmithModalUI === 'function') {
        try { updateSmithModalUI(); } catch (e) {}
      }
      needSave = true;
    }
  } catch (e) { console.warn('Smith tick failed:', e); }

  // 🪚 Lumber Craft
  try {
    if (_mIsPlainObj(state.lumber) && state.lumber.isCrafting && state.lumber.endTime > 0) {
      if (now >= state.lumber.endTime) {
        state.lumber.isCrafting = false;
        state.lumber.isReady = true;
        if (currentBuilding === 'lumber' && typeof updateLumberModalUI === 'function') {
          try { updateLumberModalUI(); } catch (e) {}
        }
        if (typeof showToast === 'function') showToast('ساخت محصولات چوب‌بری به پایان رسید!');
      } else if (currentBuilding === 'lumber' && typeof updateLumberModalUI === 'function') {
        try { updateLumberModalUI(); } catch (e) {}
      }
      needSave = true;
    }
  } catch (e) { console.warn('Lumber craft tick failed:', e); }

  // 💰 Castle Tax
  try {
    if (typeof tickCastleTax === 'function') {
      const oldAcc = _mIsPlainObj(state.castle) ? _mNum(state.castle.accumulatedGold, 0) : 0;
      tickCastleTax(now);
      if (_mIsPlainObj(state.castle) && state.castle.accumulatedGold !== oldAcc) needSave = true;
    }
  } catch (e) { console.warn('Castle tax failed:', e); }

  // 🏛️ Academy Research
  try {
    if (_mIsPlainObj(state.academyResearch) && _mIsPlainObj(state.academyResearch.activeResearch)) {
      const ar = state.academyResearch.activeResearch;
      const arEnd = _mNum(ar.endTime, 0);
      const arBranch = ar.branch;
      if (arBranch && arEnd > 0 && now >= arEnd) {
        if (typeof finishResearch === 'function') { finishResearch(); needSave = true; }
      } else if (arBranch && arEnd > 0 && currentBuilding === 'academy') {
        const arStart = _mNum(ar.startTime, 0);
        const dur = arEnd - arStart;
        const pct = dur > 0 ? Math.min(100, Math.max(0, ((now - arStart) / dur) * 100)) : 0;
        const barEl = document.getElementById('academy-research-bar');
        const textEl = document.getElementById('academy-research-text');
        if (barEl) barEl.style.width = pct + '%';
        if (textEl && typeof fmtDur === 'function') textEl.textContent = fmtDur(Math.max(0, arEnd - now));
      }
    }
  } catch (e) { console.warn('Research tick failed:', e); }

  try { if (typeof tickFomoOffer === 'function') tickFomoOffer(now); } catch (e) {}
  try {
    if (state.flashEvent && state.flashEvent.active && now >= _mNum(state.flashEvent.expiresAt, 0)) {
      state.flashEvent.active = false; needSave = true;
    }
    if (typeof generateSpecialOffer === 'function' && state.specialOffer && !state.specialOffer.active && now >= _mNum(state.specialOffer.nextOfferTime, 0)) {
      generateSpecialOffer();
    }
  } catch (e) {}

  // 📜 Missions
  try {
    if (typeof checkMissionDay === 'function') checkMissionDay();
  } catch (e) { console.warn('Mission check failed:', e); }

  // ⬆️ Upgrade
  try {
    if (state.upgrade
        && typeof state.upgrade.endTime === 'number' && state.upgrade.endTime > 0
        && typeof state.upgrade.startTime === 'number' && state.upgrade.startTime > 0
        && now >= state.upgrade.endTime
        && typeof finishUpgrade === 'function') {
      finishUpgrade();
      needSave = true;
    }
  } catch (e) { console.warn('Upgrade tick failed:', e); }

  // ⚔️ Training
  try {
    const _btEnd = _mNum(state.barracksTraining && state.barracksTraining.endTime, 0);
    if (_mIsPlainObj(state.barracksTraining) && state.barracksTraining.unit && _btEnd > 0 && now >= _btEnd) {
      if (typeof finishTraining === 'function') {
        finishTraining();
        _barracksUIRenderedThisTick = true;
        needSave = true;
      } else {
        state.barracksTraining = { unit: null, qty: 1, startTime: 0, endTime: 0 };
        needSave = true;
      }
    }
  } catch (e) {
    // آموزش را در خطا حفظ می‌کنیم؛ پاک‌کردن صف باعث از دست رفتن منابع بازیکن می‌شود.
    console.warn('Training tick failed; training state preserved:', e);
  }

  // 📜 سیستم ماموریت‌های زنده (Live Task)
  try {
    if (!state.liveTask) state.liveTask = { active: false, cooldownUntil: 0 };
    const _nowLt = Date.now();
    if (state.liveTask.active && _nowLt >= _mNum(state.liveTask.expiresAt, 0)) {
      state.liveTask.active = false; needSave = true;
    } else if (!state.liveTask.active && _nowLt > _mNum(state.liveTask.cooldownUntil, 0)) {
      if (Math.random() < 0.05 && typeof triggerLiveTask === 'function') triggerLiveTask();
    }
  } catch (e) { console.warn('Live task tick failed:', e); }

  // 🎨 UI Refresh
  try {
    if (currentBuilding && currentBuilding !== 'battle' && typeof renderUpgradeSection === 'function') renderUpgradeSection(currentBuilding);
  } catch (e) {}
  try { if (currentBuilding === 'castle' && typeof updateCastleUI === 'function') updateCastleUI(); } catch (e) {}
  try { if (currentBuilding === 'hospital' && typeof renderHospitalUI === 'function') renderHospitalUI(); } catch (e) {}
  try {
    if (currentBuilding === 'academy' && typeof renderSpeedupButtons === 'function') {
      if (_mIsPlainObj(state.academyResearch) && _mIsPlainObj(state.academyResearch.activeResearch) && state.academyResearch.activeResearch.branch) {
        const el = document.getElementById('academy-speedups');
        if (el) renderSpeedupButtons('academy-speedups', 'academy');
      }
    }
  } catch (e) {}

  // ⚔️ Battle
  try {
    if (state.battle && state.battle.inProgress && typeof tickBattleInProgress === 'function') tickBattleInProgress();
  } catch (e) { console.warn('Battle tick failed:', e); }

  try {
    if (!_barracksUIRenderedThisTick && currentBuilding === 'barracks' && typeof updateBarracksUI === 'function') updateBarracksUI();
  } catch (e) { console.warn('Barracks UI failed:', e); }

  // 🔔 Notifications
  try { if (typeof updateNotifications === 'function') updateNotifications(); } catch (e) {}

  // 💾 Save
  if (needSave && (now - _lastSaveTime) >= SAVE_INTERVAL_MS) {
    try { if (typeof saveGame === 'function') saveGame(); _lastSaveTime = now; }
    catch (e) { console.warn('Auto-save failed:', e); }
  }
}

// ============================================================
// 🎬 Splash & Init
// ============================================================
window.addEventListener('load', () => {
  const splash = document.getElementById('splashScreen');
  const audio = document.getElementById('bg-music');
  const btn = document.getElementById('music-btn');
  let splashClicked = false;

  if (splash) {
    splash.addEventListener('click', () => {
      if (splashClicked) return;
      splashClicked = true;
      try {
        if (audio && audio.paused && typeof lsGet === 'function' && lsGet('bok_music') !== 'off') {
          audio.volume = 1.0;
          audio.play().catch(() => {});
          if (btn) btn.textContent = '🔊';
        }
      } catch (e) {}
      splash.classList.add('hide');
      setTimeout(() => { if (splash.parentNode) splash.remove(); }, 1000);
    });

    setTimeout(() => {
      if (!splashClicked && splash.isConnected) {
        splashClicked = true;
        splash.classList.add('hide');
        setTimeout(() => { if (splash.parentNode) splash.remove(); }, 1000);
      }
    }, 10000);
    setTimeout(() => {
      const loadContainer = splash.querySelector('.splash-loading-container');
      if (loadContainer) loadContainer.style.display = 'none';
      const crown = document.createElement('img');
      crown.src = 'ghost/taj_for_splash.png';
      crown.alt = '👑';
      crown.style.cssText = "position:absolute;top:30%;left:50%;transform:translate(-50%,-50%);width:140px;height:auto;filter:drop-shadow(0 0 30px rgba(245,198,107,0.9)) drop-shadow(0 8px 16px rgba(0,0,0,0.8));animation:crownFloat 2s ease-in-out infinite alternate;pointer-events:none;";
      crown.onerror = function () {
        this.onerror = null;
        const span = document.createElement('div');
        span.textContent = '👑';
        span.style.cssText = "position:absolute;top:30%;left:50%;transform:translate(-50%,-50%);font-size:120px;line-height:1;filter:drop-shadow(0 0 30px rgba(245,198,107,0.9));animation:crownFloat 2s ease-in-out infinite alternate;pointer-events:none;";
        this.replaceWith(span);
      };
      splash.appendChild(crown);
      const hint = document.createElement('div');
      hint.textContent = "برای شروع کلیک کنید";
      hint.style.cssText = "position:absolute;bottom:15%;width:100%;text-align:center;color:var(--gold);font-family:var(--font-persian);font-size:28px;text-shadow:0 2px 5px #000,0 0 15px var(--gold);animation:pulseText 1.5s infinite alternate;pointer-events:none;cursor:pointer;";
      splash.appendChild(hint);
    }, 5000);
  }

  try { if (typeof lsGet === 'function' && lsGet('bok_music') === 'off' && btn) btn.textContent = '🔇'; } catch (e) {}
  try {
    if (typeof DEBUG !== 'undefined' && DEBUG) {
      const cheatBtn = typeof $ === 'function' ? $('cheat-btn') : document.getElementById('cheat-btn');
      if (cheatBtn) cheatBtn.style.display = 'flex';
    }
  } catch (e) {}

  try {
    if (typeof updateNotifications === 'function') updateNotifications();
    setTimeout(() => { if (typeof repositionNotifIcons === 'function') repositionNotifIcons(); }, 100);
    setTimeout(() => { if (typeof repositionNotifIcons === 'function') repositionNotifIcons(); }, 500);
  } catch (e) {}
});

let _resizeTimer = null;
window.addEventListener('resize', () => {
  clearTimeout(_resizeTimer);
  _resizeTimer = setTimeout(() => {
    try {
      if (typeof lastNotifKey !== 'undefined') lastNotifKey = '';
      if (typeof updateNotifications === 'function') updateNotifications();
      setTimeout(() => { if (typeof repositionNotifIcons === 'function') repositionNotifIcons(); }, 50);
    } catch (e) {}
  }, 150);
});

try {
  document.querySelectorAll('.building').forEach(img => {
    if (!img.complete) {
      img.addEventListener('load', () => {
        try { if (typeof lastNotifKey !== 'undefined') lastNotifKey = ''; if (typeof updateNotifications === 'function') updateNotifications(); } catch (e) {}
      }, { once: true });
      img.addEventListener('error', () => {
        try { if (typeof lastNotifKey !== 'undefined') lastNotifKey = ''; if (typeof updateNotifications === 'function') updateNotifications(); } catch (e) {}
      }, { once: true });
    }
  });
} catch (e) {}

let _lastVisibilitySave = 0;
const _safeSave = () => {
  const now = Date.now();
  if (now - _lastVisibilitySave < 1000) return;
  _lastVisibilitySave = now;
  try { if (typeof saveGame === 'function') saveGame(); } catch (e) {}
};
window.addEventListener('pagehide', _safeSave);
document.addEventListener('visibilitychange', () => {
  try { if (document.hidden) _safeSave(); } catch (e) {}
  try {
    const a = typeof $ === 'function' ? $('bg-music') : document.getElementById('bg-music');
    if (!a) return;
    if (document.hidden) {
      if (!a.paused) { a.dataset.resume = '1'; a.pause(); }
    } else if (a.dataset.resume === '1') {
      a.dataset.resume = '';
      if (typeof lsGet !== 'function' || lsGet('bok_music') !== 'off') a.play().catch(() => {});
    }
  } catch (e) {}
});

function boot() {
  if (_booted) return;
  _booted = true;
  try { if (typeof loadGame === 'function') loadGame(); } catch (e) { console.error('Boot: loadGame failed:', e); }
  try { if (typeof updateUI === 'function') updateUI(); } catch (e) { console.error('Boot: updateUI failed:', e); }
  try {
    _lastTickTime = Date.now();
    _lastSaveTime = Date.now();
    setInterval(gameTick, 1000);
  } catch (e) { console.error('Boot: setInterval failed:', e); }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}