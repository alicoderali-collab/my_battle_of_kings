// ============================================================
// ⚔️ BATTLE OF KINGS - js/state.js (v8 - FINAL)
// ============================================================

const _PP_SKIP = { '__proto__': 1, 'constructor': 1, 'prototype': 1 };

function _isPlain(v) { return v !== null && typeof v === 'object' && !Array.isArray(v); }
function _safeInt(v, fb) {
  if (typeof v !== 'number') v = Number(v);
  if (!isFinite(v) || isNaN(v) || v < 0) return fb || 0;
  return Math.floor(v);
}
function _safeNum(v, fb) {
  if (typeof v !== 'number') v = Number(v);
  if (!isFinite(v) || isNaN(v) || v < 0) return fb || 0;
  return v;
}

function lsSet(key, value) {
  try {
    if (typeof key !== 'string' || !key) return false;
    localStorage.setItem(key, value);
    return true;
  } catch (e) { console.warn('lsSet failed:', e); return false; }
}
function lsGet(key) {
  try {
    if (typeof key !== 'string' || !key) return null;
    return localStorage.getItem(key);
  } catch (e) { console.warn('lsGet failed:', e); return null; }
}

let gameLocked = false;

const DEFAULT_STATE = {
  gold: 500, wood: 200, azooghe: 300, stone: 500, iron: 100, coal: 100, diamond: 5, crystal: 0,
  player_level: 1, xp: 0,
  unopenedLevelChests: 0,
  
  // سیستم پیشنهاد ویژه
  specialOffer: {
    active: false,
    attackTarget: 0, attackReq: 0, attackCur: 0,
    farmReq: 0, farmCur: 0,
    mineReq: 0, mineCur: 0,
    lumberReq: 0, lumberCur: 0,
    upgradeReq: 0, upgradeCur: 0,
    rewardGold: 0, rewardXP: 1000,
    isHalved: false,
    nextOfferTime: 0
  },

  academyResearch: {
    power: 0, gold: 0, defense: 0,
    activeResearch: { branch: null, startTime: 0, endTime: 0, targetLevel: 0 }
  },
  castle: { accumulatedGold: 0, lastTickTime: 0, lastCollectTime: 0 },
  missions: { day: '', progress: {}, claimed: {} },
  flashEvent: { active: false, target: '', expiresAt: 0 },
  harvestCounter: 0,
  liveTask: { active: false, type: '', progress: 0, target: 0, expiresAt: 0, cooldownUntil: 0 },
  army: { spearman: 0, archer: 0, cavalry: 0, wizard: 0 },
  buildings: { castle: 1, farm: 1, mine: 1, barracks: 1, academy: 1, hospital: 1, watchtower: 1, lumber: 1, smith: 1, wall: 1 },
  owned_profiles: ['castle'],
  active_profile: 'castle',
  farm: { isProducing: false, accumulatedAzooghe: 0, accumulatedWood: 0, startTime: 0, lastTickTime: 0, lastAnimatedMinute: 0 },
  mine: { isProducing: false, accumulatedStone: 0, accumulatedCoal: 0, accumulatedDiamond: 0, startTime: 0, lastTickTime: 0, lastAnimatedMinute: 0 },
  lumberProd: { isProducing: false, accumulatedWood: 0, startTime: 0, lastTickTime: 0, lastAnimatedMinute: 0 },
  inventory: {
    steel: 0, spear: 0, helmet: 0, shield: 0, armor: 0, horseArmor: 0,
    bow: 0, arrow: 0, staff: 0, wall: 0, catapult: 0,
    speedup_1m: 0, speedup_10m: 0, speedup_1h: 0, speedup_1d: 0,
    magicBook: 0, ironKey: 0, goldKey: 0, purpleKey: 0
  },
  smith: { isCrafting: false, isReady: false, item: null, amount: 0, startTime: 0, endTime: 0 },
  lumber: { isCrafting: false, isReady: false, item: null, amount: 0, startTime: 0, endTime: 0 },
  barracksTraining: { unit: null, qty: 1, startTime: 0, endTime: 0 },
  hospital: { wounded: {} },
  upgrade: null,
  messages: [],
  msgUnread: 0,
  battle: { cd: {}, inProgress: null, lastResult: null, log: [] },
  crateLimits: { day: '', bronze: 0, silver: 0, gold: 0 },
  watchtower: {
    scouting: { activeUntil: 0, enemyIndex: -1, startTime: 0 },
    patrol: { activeUntil: 0, startTime: 0 },
    lastReportDate: '',
    lastScoutTime: 0,
    alerts: []
  },
  peaceTreaty: { activeUntil: 0, startTime: 0, hours: 0, totalCost: { gold: 0, wall: 0 } },
  watchtowerEquipment: { wall: 0, catapult: 0 },
  migration_done_v2: false,
  commanderName: 'آرش'
};

let state = JSON.parse(JSON.stringify(DEFAULT_STATE));

const OFFLINE_MAX_SECONDS = 7 * 24 * 60 * 60;
const MAX_UPGRADE_MS = 4 * 24 * 60 * 60 * 1000;
const MAX_CRAFT_MS   = 8 * 24 * 60 * 60 * 1000;

function sanitizeState() {
  if (!_isPlain(state)) state = JSON.parse(JSON.stringify(DEFAULT_STATE));

  ['gold','wood','azooghe','stone','iron','coal','diamond','crystal','xp'].forEach(k => {
    state[k] = _safeNum(state[k], 0);
  });
  ['gold','wood','azooghe','stone','iron','coal','xp'].forEach(k => {
    if (state[k] > 99999999) state[k] = 99999999;
  });
  if (state.diamond > 999999) state.diamond = 999999;
  if (state.crystal > 999999) state.crystal = 999999;

  state.player_level = Math.max(1, _safeInt(state.player_level, 1));
  if (typeof getLevelFromXP === 'function') {
    const expected = getLevelFromXP(state.xp);
    if (state.player_level !== expected) state.player_level = expected;
  }

  state.unopenedLevelChests = Math.min(9999, _safeInt(state.unopenedLevelChests, 0));

  if (typeof state.migration_done_v2 !== 'boolean') state.migration_done_v2 = false;
  if (typeof state.commanderName !== 'string') state.commanderName = 'آرش';

  // Sanitize Special Offer
  if (!_isPlain(state.specialOffer)) state.specialOffer = JSON.parse(JSON.stringify(DEFAULT_STATE.specialOffer));
  const so = state.specialOffer;
  ['attackReq','attackCur','farmReq','farmCur','mineReq','mineCur','lumberReq','lumberCur','upgradeReq','upgradeCur','rewardGold','rewardXP','nextOfferTime'].forEach(k => {
    so[k] = _safeInt(so[k], 0);
  });
  if (typeof so.active !== 'boolean') so.active = false;
  if (typeof so.isHalved !== 'boolean') so.isHalved = false;

  if (!_isPlain(state.academyResearch)) {
    state.academyResearch = { power: 0, gold: 0, defense: 0, activeResearch: { branch: null, startTime: 0, endTime: 0, targetLevel: 0 } };
  }
  ['power','gold','defense'].forEach(k => {
    state.academyResearch[k] = Math.min(10, _safeInt(state.academyResearch[k], 0));
  });
  if (!_isPlain(state.academyResearch.activeResearch)) {
    state.academyResearch.activeResearch = { branch: null, startTime: 0, endTime: 0, targetLevel: 0 };
  }
  const ar = state.academyResearch.activeResearch;
  if (ar.branch !== null && !['power','gold','defense'].includes(ar.branch)) ar.branch = null;
  ['startTime','endTime','targetLevel'].forEach(k => {
    if (typeof ar[k] !== 'number' || !isFinite(ar[k]) || ar[k] < 0) ar[k] = 0;
  });
  if (ar.targetLevel > 10) ar.targetLevel = 10;
  const nowAr = Date.now();
  if (ar.startTime > nowAr) ar.startTime = nowAr;
  if (ar.endTime > nowAr + 200 * 3600000) ar.endTime = nowAr + 200 * 3600000;
  if (ar.branch === null) { ar.startTime = 0; ar.endTime = 0; ar.targetLevel = 0; }
  if (ar.branch !== null && (ar.targetLevel <= 0 || ar.endTime <= 0)) {
    ar.branch = null; ar.startTime = 0; ar.endTime = 0; ar.targetLevel = 0;
  }

  if (!_isPlain(state.hospital)) state.hospital = { wounded: {} };
  if (!_isPlain(state.hospital.wounded)) state.hospital.wounded = {};
  for (const k of Object.keys(state.hospital.wounded)) {
    if (_PP_SKIP[k]) { delete state.hospital.wounded[k]; continue; }
    if (typeof UNITS_INFO !== 'undefined' && !UNITS_INFO[k]) { delete state.hospital.wounded[k]; continue; }
    if (typeof HEAL_COSTS !== 'undefined' && !HEAL_COSTS[k]) { delete state.hospital.wounded[k]; continue; }
    const v = state.hospital.wounded[k];
    if (typeof v !== 'number' || !isFinite(v) || v <= 0) { delete state.hospital.wounded[k]; continue; }
    if (v > 99999) state.hospital.wounded[k] = 99999;
  }

  if (!_isPlain(state.inventory)) state.inventory = {};
  for (const k in DEFAULT_STATE.inventory) {
    if (!Object.prototype.hasOwnProperty.call(state.inventory, k)) state.inventory[k] = 0;
    const v = state.inventory[k];
    if (typeof v !== 'number' || !isFinite(v) || v < 0) state.inventory[k] = 0;
    else if (v > 999999) state.inventory[k] = 999999;
  }
  for (const k of Object.keys(state.inventory)) {
    if (_PP_SKIP[k]) { delete state.inventory[k]; continue; }
    const v = state.inventory[k];
    if (typeof v !== 'number' || !isFinite(v) || v < 0) state.inventory[k] = 0;
  }

  if (!_isPlain(state.army)) state.army = JSON.parse(JSON.stringify(DEFAULT_STATE.army));
  for (const k in DEFAULT_STATE.army) {
    if (!Object.prototype.hasOwnProperty.call(state.army, k)) state.army[k] = 0;
    state.army[k] = Math.min(99999, _safeInt(state.army[k], 0));
  }
  for (const k of Object.keys(state.army)) {
    if (_PP_SKIP[k] || !Object.prototype.hasOwnProperty.call(DEFAULT_STATE.army, k)) delete state.army[k];
  }

  if (!_isPlain(state.buildings)) state.buildings = JSON.parse(JSON.stringify(DEFAULT_STATE.buildings));
  for (const k of Object.keys(state.buildings)) {
    if (_PP_SKIP[k] || (typeof BUILDINGS_INFO !== 'undefined' && !BUILDINGS_INFO[k])) delete state.buildings[k];
  }
  for (const k in DEFAULT_STATE.buildings) {
    if (!Object.prototype.hasOwnProperty.call(state.buildings, k)) state.buildings[k] = 1;
    state.buildings[k] = Math.min(30, Math.max(1, _safeInt(state.buildings[k], 1)));
  }

  if (!_isPlain(state.missions)) state.missions = { day: '', progress: {}, claimed: {} };
  if (typeof state.missions.day !== 'string') state.missions.day = '';
  if (!_isPlain(state.missions.progress)) state.missions.progress = {};
  if (!_isPlain(state.missions.claimed)) state.missions.claimed = {};
  for (const id of Object.keys(state.missions.progress)) {
    if (_PP_SKIP[id]) { delete state.missions.progress[id]; continue; }
    const v = state.missions.progress[id];
    if (typeof v !== 'number' || !isFinite(v) || v < 0) state.missions.progress[id] = 0;
    else if (v > 99999) state.missions.progress[id] = 99999;
  }
  for (const id of Object.keys(state.missions.claimed)) {
    if (_PP_SKIP[id] || state.missions.claimed[id] !== true) delete state.missions.claimed[id];
  }

  if (!_isPlain(state.flashEvent)) state.flashEvent = { active: false, target: '', expiresAt: 0 };
  if (typeof state.flashEvent.active !== 'boolean') state.flashEvent.active = false;
  if (!['farm','mine','lumber'].includes(state.flashEvent.target)) state.flashEvent.target = '';
  state.flashEvent.expiresAt = _safeNum(state.flashEvent.expiresAt, 0);
  if (state.flashEvent.expiresAt && state.flashEvent.expiresAt < Date.now()) state.flashEvent.active = false;
  state.harvestCounter = Math.min(2, _safeInt(state.harvestCounter, 0));
  if (!_isPlain(state.liveTask)) state.liveTask = { active: false, type: '', progress: 0, target: 0, expiresAt: 0, cooldownUntil: 0 };
  state.liveTask.active = !!state.liveTask.active;
  state.liveTask.type = typeof state.liveTask.type === 'string' ? state.liveTask.type.slice(0, 30) : '';
  state.liveTask.progress = _safeInt(state.liveTask.progress, 0);
  state.liveTask.target = Math.min(1000, _safeInt(state.liveTask.target, 0));
  state.liveTask.expiresAt = _safeNum(state.liveTask.expiresAt, 0);
  state.liveTask.cooldownUntil = _safeNum(state.liveTask.cooldownUntil, 0);

  if (!Array.isArray(state.messages)) state.messages = [];
  const _maxDurSec = (typeof BATTLE_DURATION_MS === 'number' ? BATTLE_DURATION_MS : 180000) / 1000;
  state.messages = state.messages
    .filter(m => _isPlain(m) && typeof m.id === 'string' && typeof m.title === 'string')
    .slice(-50)
    .map(m => {
      let safeData = null;
      if (m.type === 'battle' && _isPlain(m.data)) {
        safeData = {};
        const allowedKeys = ['victory','enemyName','enemyIndex','playerPower','enemyPower','totalLost','wounded','survivors','duration','xpGain','levelUp','reward','lost','log'];
        for (const k of allowedKeys) {
          if (m.data[k] === undefined) continue;
          if (k === 'reward' && _isPlain(m.data[k])) {
            safeData[k] = {};
            for (const rk in m.data[k]) {
              if (!_PP_SKIP[rk] && typeof m.data[k][rk] === 'number' && isFinite(m.data[k][rk])) safeData[k][rk] = Math.min(99999999, m.data[k][rk]);
            }
          } else if (k === 'lost' && Array.isArray(m.data[k])) {
            safeData[k] = m.data[k].filter(x => _isPlain(x) && typeof x.name === 'string' && typeof x.n === 'number' && isFinite(x.n) && x.n > 0).slice(0, 20).map(x => ({ name: String(x.name).slice(0, 100), n: Math.min(99999, x.n) }));
          } else if (k === 'log' && Array.isArray(m.data[k])) {
            safeData[k] = m.data[k].filter(x => typeof x === 'string').slice(-20).map(s => String(s).slice(0, 200));
          } else if (typeof m.data[k] === 'boolean' || typeof m.data[k] === 'string') {
            safeData[k] = m.data[k];
          } else if (typeof m.data[k] === 'number' && isFinite(m.data[k]) && m.data[k] >= 0) {
            safeData[k] = m.data[k];
          }
        }
        if (safeData && typeof safeData.duration === 'number' && safeData.duration > _maxDurSec) safeData.duration = _maxDurSec;
        if (safeData && typeof safeData.xpGain === 'number' && safeData.xpGain > 99999999) safeData.xpGain = 99999999;
      }
      return {
        id: String(m.id).slice(0, 64),
        type: ['battle','system','reward','upgrade','training'].includes(m.type) ? m.type : 'system',
        icon: typeof m.icon === 'string' ? m.icon.slice(0, 8) : '📜',
        title: String(m.title).slice(0, 120),
        body: typeof m.body === 'string' ? m.body.slice(0, 500) : '',
        ts: (typeof m.ts === 'number' && isFinite(m.ts) && m.ts > 0) ? m.ts : Date.now(),
        read: !!m.read,
        data: safeData
      };
    });
  state.msgUnread = state.messages.filter(x => !x.read).length;

  if (!_isPlain(state.barracksTraining)) {
    state.barracksTraining = { unit: null, qty: 1, startTime: 0, endTime: 0 };
  } else {
    const bt = state.barracksTraining;
    const unitKeyOk = typeof bt.unit === 'string' && bt.unit && !_PP_SKIP[bt.unit] && (typeof UNITS_INFO === 'undefined' || !!UNITS_INFO[bt.unit]);
    if (!unitKeyOk) {
      state.barracksTraining = { unit: null, qty: 1, startTime: 0, endTime: 0 };
    } else {
      const _reqLvl = (typeof UNITS_INFO !== 'undefined' && UNITS_INFO[bt.unit]) ? _safeInt(UNITS_INFO[bt.unit].reqBarracksLevel, 1) : 1;
      const _bLvl = _safeInt(state.buildings && state.buildings.barracks, 1);
      if (_bLvl < _reqLvl) {
        state.barracksTraining = { unit: null, qty: 1, startTime: 0, endTime: 0 };
      } else {
        ['startTime','endTime'].forEach(f => {
          if (typeof bt[f] !== 'number' || !isFinite(bt[f]) || bt[f] < 0) bt[f] = 0;
        });
        bt.qty = Math.min(1000, Math.max(1, _safeInt(bt.qty, 1)));
        const _nowBt = Date.now();
        if (bt.startTime > _nowBt) bt.startTime = _nowBt;
        if (bt.endTime > _nowBt + MAX_UPGRADE_MS) bt.endTime = _nowBt + MAX_UPGRADE_MS;
        if (bt.endTime < bt.startTime) bt.endTime = bt.startTime;
      }
    }
  }

  if (!_isPlain(state.peaceTreaty)) {
    state.peaceTreaty = { activeUntil: 0, startTime: 0, hours: 0, totalCost: { gold: 0, wall: 0 } };
  }
  const _pt = state.peaceTreaty;
  const _nowWt = Date.now();
  const _maxPtFuture = _nowWt + 73 * 3600000;
  if (typeof _pt.activeUntil !== 'number' || !isFinite(_pt.activeUntil) || _pt.activeUntil < 0) _pt.activeUntil = 0;
  if (_pt.activeUntil > _maxPtFuture) _pt.activeUntil = 0;
  if (typeof _pt.startTime !== 'number' || !isFinite(_pt.startTime) || _pt.startTime < 0) _pt.startTime = 0;
  if (_pt.startTime > _pt.activeUntil && _pt.activeUntil > 0) _pt.startTime = 0;
  _pt.hours = Math.min(72, Math.max(0, _safeInt(_pt.hours, 0)));
  if (!_isPlain(_pt.totalCost)) _pt.totalCost = { gold: 0, wall: 0 };
  _pt.totalCost.gold = Math.min(9999999, _safeInt(_pt.totalCost.gold, 0));
  _pt.totalCost.wall = Math.min(999, _safeInt(_pt.totalCost.wall, 0));
  if (_pt.activeUntil > 0 && _pt.activeUntil <= _nowWt) {
    state.peaceTreaty = { activeUntil: 0, startTime: 0, hours: 0, totalCost: { gold: 0, wall: 0 } };
  }

  if (!_isPlain(state.watchtowerEquipment)) state.watchtowerEquipment = { wall: 0, catapult: 0 };
  state.watchtowerEquipment.wall = Math.min(99999, _safeInt(state.watchtowerEquipment.wall, 0));
  state.watchtowerEquipment.catapult = Math.min(99999, _safeInt(state.watchtowerEquipment.catapult, 0));

  if (!_isPlain(state.watchtower)) {
    state.watchtower = {
      scouting: { activeUntil: 0, enemyIndex: -1, startTime: 0 },
      patrol: { activeUntil: 0, startTime: 0 },
      lastReportDate: '',
      lastScoutTime: 0,
      alerts: []
    };
  }
  const _wt = state.watchtower;
  const _wtMaxScout = (typeof WATCHTOWER_CONFIG !== 'undefined' && typeof WATCHTOWER_CONFIG.maxScoutDuration === 'number') ? WATCHTOWER_CONFIG.maxScoutDuration : 60 * 60 * 1000;
  const _wtMaxPatrol = (typeof WATCHTOWER_CONFIG !== 'undefined' && typeof WATCHTOWER_CONFIG.patrolDuration === 'number') ? WATCHTOWER_CONFIG.patrolDuration : 2 * 60 * 60 * 1000;
  const _wtMaxFuture = _nowWt + Math.max(_wtMaxScout, _wtMaxPatrol) + 5 * 60 * 1000;
  if (!_isPlain(_wt.scouting)) _wt.scouting = { activeUntil: 0, enemyIndex: -1, startTime: 0 };
  ['activeUntil','startTime'].forEach(f => {
    if (typeof _wt.scouting[f] !== 'number' || !isFinite(_wt.scouting[f]) || _wt.scouting[f] < 0) _wt.scouting[f] = 0;
  });
  if (_wt.scouting.activeUntil > _wtMaxFuture) _wt.scouting.activeUntil = _wtMaxFuture;
  if (typeof _wt.scouting.enemyIndex !== 'number' || !isFinite(_wt.scouting.enemyIndex) || _wt.scouting.enemyIndex < -1) _wt.scouting.enemyIndex = -1;
  if (typeof ENEMIES !== 'undefined' && Array.isArray(ENEMIES) && _wt.scouting.enemyIndex >= ENEMIES.length) _wt.scouting.enemyIndex = -1;
  if (_wt.scouting.activeUntil > 0 && _wt.scouting.startTime === 0) _wt.scouting.startTime = Math.max(0, _wt.scouting.activeUntil - _wtMaxScout);

  if (!_isPlain(_wt.patrol)) _wt.patrol = { activeUntil: 0, startTime: 0 };
  ['activeUntil','startTime'].forEach(f => {
    if (typeof _wt.patrol[f] !== 'number' || !isFinite(_wt.patrol[f]) || _wt.patrol[f] < 0) _wt.patrol[f] = 0;
  });
  if (_wt.patrol.activeUntil > _wtMaxFuture) _wt.patrol.activeUntil = _wtMaxFuture;
  if (_wt.patrol.activeUntil > 0 && _wt.patrol.startTime === 0) _wt.patrol.startTime = Math.max(0, _wt.patrol.activeUntil - _wtMaxPatrol);

  if (typeof _wt.lastReportDate !== 'string') _wt.lastReportDate = '';
  if (typeof _wt.lastScoutTime !== 'number' || !isFinite(_wt.lastScoutTime) || _wt.lastScoutTime < 0) _wt.lastScoutTime = 0;
  if (_wt.lastScoutTime > _nowWt) _wt.lastScoutTime = 0;
  if (!Array.isArray(_wt.alerts)) _wt.alerts = [];
  const _alertCutoff = _nowWt - ((typeof WATCHTOWER_CONFIG !== 'undefined' && typeof WATCHTOWER_CONFIG.alertMaxAge === 'number') ? WATCHTOWER_CONFIG.alertMaxAge : 7 * 24 * 60 * 60 * 1000);
  const _alertMax = (typeof WATCHTOWER_CONFIG !== 'undefined' && typeof WATCHTOWER_CONFIG.maxAlerts === 'number') ? WATCHTOWER_CONFIG.maxAlerts : 20;
  _wt.alerts = _wt.alerts
    .filter(a => _isPlain(a) && typeof a.id === 'string' && typeof a.title === 'string')
    .filter(a => { const ts = typeof a.ts === 'number' && isFinite(a.ts) ? a.ts : 0; return ts === 0 || ts > _alertCutoff; })
    .slice(-_alertMax)
    .map(a => ({
      id: String(a.id).slice(0, 64),
      dedupeKey: typeof a.dedupeKey === 'string' ? a.dedupeKey.slice(0, 64) : null,
      type: ['resource','battle','upgrade','training','system'].includes(a.type) ? a.type : 'system',
      icon: typeof a.icon === 'string' ? a.icon.slice(0, 8) : '📜',
      title: String(a.title).slice(0, 120),
      body: typeof a.body === 'string' ? a.body.slice(0, 500) : '',
      ts: (typeof a.ts === 'number' && isFinite(a.ts) && a.ts > 0) ? a.ts : Date.now(),
      read: !!a.read
    }));

  const _prod = (sys, fields) => {
    if (!_isPlain(sys)) return false;
    if (typeof sys.isProducing !== 'boolean') sys.isProducing = false;
    fields.forEach(f => {
      if (typeof sys[f] !== 'number' || !isFinite(sys[f]) || sys[f] < 0) sys[f] = 0;
    });
    const now = Date.now();
    if (sys.lastTickTime > now) sys.lastTickTime = now;
    if (!sys.isProducing) sys.startTime = 0;
    else {
      if (sys.startTime > now) sys.startTime = now;
      if (sys.startTime > sys.lastTickTime) sys.startTime = sys.lastTickTime;
    }
    return true;
  };
  if (!_prod(state.farm, ['accumulatedAzooghe','accumulatedWood','startTime','lastTickTime','lastAnimatedMinute'])) {
    state.farm = JSON.parse(JSON.stringify(DEFAULT_STATE.farm));
    _prod(state.farm, ['accumulatedAzooghe','accumulatedWood','startTime','lastTickTime','lastAnimatedMinute']);
  }
  if (!_prod(state.mine, ['accumulatedStone','accumulatedCoal','accumulatedDiamond','startTime','lastTickTime','lastAnimatedMinute'])) {
    state.mine = JSON.parse(JSON.stringify(DEFAULT_STATE.mine));
    _prod(state.mine, ['accumulatedStone','accumulatedCoal','accumulatedDiamond','startTime','lastTickTime','lastAnimatedMinute']);
  }
  if (!_prod(state.lumberProd, ['accumulatedWood','startTime','lastTickTime','lastAnimatedMinute'])) {
    state.lumberProd = JSON.parse(JSON.stringify(DEFAULT_STATE.lumberProd));
    _prod(state.lumberProd, ['accumulatedWood','startTime','lastTickTime','lastAnimatedMinute']);
  }

  [['smith', (typeof SMITH_RECIPES !== 'undefined' ? SMITH_RECIPES : {})],
   ['lumber', (typeof LUMBER_RECIPES !== 'undefined' ? LUMBER_RECIPES : {})]].forEach(([key, recipes]) => {
    let sys = state[key];
    if (!_isPlain(sys)) { state[key] = JSON.parse(JSON.stringify(DEFAULT_STATE[key])); sys = state[key]; }
    ['amount', 'startTime', 'endTime'].forEach(f => {
      if (typeof sys[f] !== 'number' || !isFinite(sys[f]) || sys[f] < 0) sys[f] = 0;
    });
    if (typeof sys.isCrafting !== 'boolean') sys.isCrafting = false;
    if (typeof sys.isReady !== 'boolean') sys.isReady = false;
    if (sys.item !== null && (typeof sys.item !== 'string' || !recipes[sys.item])) sys.item = null;
    if (!sys.item) { sys.amount = 0; sys.isReady = false; sys.isCrafting = false; }
    else {
      const now = Date.now();
      if (sys.startTime > now) sys.startTime = now;
      if (sys.endTime > now + MAX_CRAFT_MS) sys.endTime = now + MAX_CRAFT_MS;
      if (sys.endTime < sys.startTime) sys.endTime = sys.startTime;
      if (sys.isCrafting && sys.endTime <= now) { sys.isCrafting = false; sys.isReady = true; }
      if (sys.amount > 999999) sys.amount = 999999;
    }
  });

  if (state.upgrade) {
    const u = state.upgrade;
    if (!_isPlain(u) || !u.type || (typeof BUILDINGS_INFO !== 'undefined' && !BUILDINGS_INFO[u.type]) || typeof u.startTime !== 'number' || !isFinite(u.startTime) || typeof u.endTime !== 'number' || !isFinite(u.endTime)) {
      state.upgrade = null;
    } else {
      const now = Date.now();
      if (u.startTime > now) u.startTime = now;
      if (u.endTime > now + MAX_UPGRADE_MS) u.endTime = now + MAX_UPGRADE_MS;
      if (u.endTime < u.startTime) u.endTime = u.startTime;
    }
  }

  if (!_isPlain(state.castle)) state.castle = { accumulatedGold: 0, lastTickTime: 0, lastCollectTime: 0 };
  ['accumulatedGold','lastTickTime','lastCollectTime'].forEach(k => {
    if (typeof state.castle[k] !== 'number' || !isFinite(state.castle[k]) || state.castle[k] < 0) state.castle[k] = 0;
  });
  const _nowC = Date.now();
  if (state.castle.lastTickTime > _nowC) state.castle.lastTickTime = _nowC;
  if (state.castle.lastCollectTime > _nowC) state.castle.lastCollectTime = _nowC;
  const _castleRate = typeof getCastleRatePerMin === 'function' ? getCastleRatePerMin() : (0.3 * Math.max(1, _safeInt(state.buildings && state.buildings.castle, 1)));
  const _castleCap = _castleRate * (typeof TAX_CAP_MINUTES === 'number' ? TAX_CAP_MINUTES : 60);
  if (state.castle.accumulatedGold > _castleCap) state.castle.accumulatedGold = _castleCap;

  if (!_isPlain(state.battle)) state.battle = { cd: {}, inProgress: null, lastResult: null, log: [] };
  for (const k of Object.keys(state.battle)) {
    if (!['cd','inProgress','lastResult','log'].includes(k)) delete state.battle[k];
  }
  ['cd','inProgress','lastResult','log'].forEach(k => {
    if (!(k in state.battle)) state.battle[k] = DEFAULT_STATE.battle[k];
  });
  if (!_isPlain(state.battle.cd)) state.battle.cd = {};
  const _cdCap = (typeof BOSS_COOLDOWNS_MS !== 'undefined' && Array.isArray(BOSS_COOLDOWNS_MS)) ? Math.max(...BOSS_COOLDOWNS_MS, 0) + 3600000 : ((typeof BATTLE_COOLDOWN_MS === 'number') ? BATTLE_COOLDOWN_MS * 2 : 1200000);
  const _nowB = Date.now();
  for (const k of Object.keys(state.battle.cd)) {
    if (_PP_SKIP[k]) { delete state.battle.cd[k]; continue; }
    const v = state.battle.cd[k];
    if (typeof v !== 'number' || !isFinite(v) || v < 0) state.battle.cd[k] = 0;
    else if (v > _nowB + _cdCap) state.battle.cd[k] = _nowB + _cdCap;
  }
  if (!Array.isArray(state.battle.log)) state.battle.log = [];
  state.battle.log = state.battle.log.filter(l => typeof l === 'string').slice(-20);
  if (state.battle.inProgress) {
    if (state.battle.inProgress.resolved) state.battle.inProgress = null;
    else {
      const b = state.battle.inProgress;
      const _enemiesArr = (typeof ENEMIES !== 'undefined' && Array.isArray(ENEMIES)) ? ENEMIES : [];
      const _battleDur = (typeof BATTLE_DURATION_MS === 'number') ? BATTLE_DURATION_MS : 180000;
      const bad = !_isPlain(b) || typeof b.enemyIndex !== 'number' || b.enemyIndex < 0 || b.enemyIndex >= _enemiesArr.length || typeof b.startTime !== 'number' || !isFinite(b.startTime) || typeof b.endTime !== 'number' || !isFinite(b.endTime) || typeof b.playerPowerAtStart !== 'number' || !isFinite(b.playerPowerAtStart) || typeof b.enemyPowerAtStart !== 'number' || !isFinite(b.enemyPowerAtStart);
      if (bad) state.battle.inProgress = null;
      else {
        const _nowBi = Date.now();
        if (b.startTime > _nowBi) b.startTime = _nowBi;
        if (b.endTime > b.startTime + _battleDur * 2) b.endTime = b.startTime + _battleDur * 2;
        if (b.endTime < b.startTime) b.endTime = b.startTime;
        if (!_isPlain(b.units)) b.units = JSON.parse(JSON.stringify(state.army));
        for (const uk of Object.keys(b.units)) {
          if (_PP_SKIP[uk]) { delete b.units[uk]; continue; }
          if (typeof UNITS_INFO !== 'undefined' && !UNITS_INFO[uk]) { delete b.units[uk]; continue; }
          const uv = b.units[uk];
          if (typeof uv !== 'number' || !isFinite(uv) || uv < 0) b.units[uk] = 0;
          else if (uv > 99999) b.units[uk] = 99999;
        }
        if (typeof b.resolved !== 'boolean') b.resolved = false;
        if (typeof b.win !== 'boolean') b.win = b.playerPowerAtStart >= b.enemyPowerAtStart;
        if (typeof b.lastLogTime !== 'number' || !isFinite(b.lastLogTime)) b.lastLogTime = 0;
      }
    }
  }
  if (state.battle.lastResult) {
    const r = state.battle.lastResult;
    const _enemiesArr2 = (typeof ENEMIES !== 'undefined' && Array.isArray(ENEMIES)) ? ENEMIES : [];
    const bad = !_isPlain(r) || typeof r.enemyIndex !== 'number' || r.enemyIndex < 0 || r.enemyIndex >= _enemiesArr2.length;
    if (bad) state.battle.lastResult = null;
    else {
      if (typeof r.victory !== 'boolean') r.victory = false;
      if (typeof r.enemyName !== 'string') r.enemyName = '';
      ['playerPower','enemyPower','totalLost','wounded','survivors','xpGain'].forEach(f => {
        if (typeof r[f] !== 'number' || !isFinite(r[f]) || r[f] < 0) r[f] = 0;
        else if (r[f] > 99999999) r[f] = 99999999;
      });
      if (typeof r.duration !== 'number' || !isFinite(r.duration) || r.duration < 0) r.duration = 0;
      else if (r.duration > _maxDurSec) r.duration = _maxDurSec;
      if (!_isPlain(r.reward)) r.reward = {};
      for (const rk of Object.keys(r.reward)) {
        if (_PP_SKIP[rk]) { delete r.reward[rk]; continue; }
        const rv = r.reward[rk];
        if (typeof rv !== 'number' || !isFinite(rv) || rv <= 0) { delete r.reward[rk]; continue; }
        if (rv > 99999999) r.reward[rk] = 99999999;
      }
      if (!Array.isArray(r.lost)) r.lost = [];
      r.lost = r.lost.filter(x => _isPlain(x) && typeof x.name === 'string' && typeof x.n === 'number' && isFinite(x.n) && x.n > 0).slice(0, 20).map(x => ({ name: String(x.name).slice(0, 100), n: Math.min(99999, x.n) }));
      if (!Array.isArray(r.log)) r.log = [];
      r.log = r.log.filter(l => typeof l === 'string').slice(-20).map(s => String(s).slice(0, 200));
      if (r.levelUp !== undefined && (typeof r.levelUp !== 'number' || !isFinite(r.levelUp) || r.levelUp <= 0)) r.levelUp = 0;
    }
  }

  if (typeof profilesData !== 'undefined' && Array.isArray(profilesData)) {
    const validIds = profilesData.map(p => p.id);
    if (!Array.isArray(state.owned_profiles)) state.owned_profiles = ['castle'];
    state.owned_profiles = state.owned_profiles.filter(id => typeof id === 'string' && validIds.includes(id));
    if (!state.owned_profiles.includes('castle')) state.owned_profiles.unshift('castle');
    if (typeof state.active_profile !== 'string' || !validIds.includes(state.active_profile)) state.active_profile = 'castle';
  } else {
    if (!Array.isArray(state.owned_profiles) || state.owned_profiles.length === 0) state.owned_profiles = ['castle'];
    if (typeof state.active_profile !== 'string') state.active_profile = 'castle';
  }

  if (!_isPlain(state.crateLimits)) state.crateLimits = { day: '', bronze: 0, silver: 0, gold: 0 };
  if (typeof state.crateLimits.day !== 'string') state.crateLimits.day = '';
  ['bronze','silver','gold'].forEach(k => { state.crateLimits[k] = _safeInt(state.crateLimits[k], 0); });
}

function resetCrateLimitsIfNewDay() {
  const d = todayKey();
  if (!_isPlain(state.crateLimits)) { state.crateLimits = { day: d, bronze: 0, silver: 0, gold: 0 }; return; }
  if (state.crateLimits.day !== d) state.crateLimits = { day: d, bronze: 0, silver: 0, gold: 0 };
}

function sanitizeCrateLimits() {
  resetCrateLimitsIfNewDay();
  if (typeof CRATE_DEFS === 'undefined' || !CRATE_DEFS) return;
  ['bronze','silver','gold'].forEach(k => {
    const def = CRATE_DEFS[k];
    if (!def || !Number.isFinite(def.dailyLimit)) state.crateLimits[k] = 0;
    else state.crateLimits[k] = Math.min(def.dailyLimit, _safeInt(state.crateLimits[k], 0));
  });
}

function saveGame() {
  if (gameLocked) return;
  if (typeof _txDepth !== 'undefined' && _txDepth > 0) return;
  if (!_isPlain(state)) return;
  try { lsSet('bok_local_save', JSON.stringify(state)); } catch (e) { console.warn('save failed', e); }
}

function loadGame() {
  const _wasLocked = gameLocked;
  gameLocked = true;
  let _loadOk = false;

  try {
    let saved = null;
    try { saved = lsGet('bok_local_save'); } catch (e) { console.warn('storage blocked', e); }

    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        try { lsSet('bok_backup', saved); } catch (e) {}
        if (!_isPlain(parsed)) throw new Error('Save is not a plain object');

        state = JSON.parse(JSON.stringify(DEFAULT_STATE));

        ['gold','wood','azooghe','stone','iron','coal','diamond','crystal'].forEach(k => {
          state[k] = _safeNum(parsed[k], DEFAULT_STATE[k]);
        });

        state.buildings = { ...DEFAULT_STATE.buildings, ...(_isPlain(parsed.buildings) ? parsed.buildings : {}) };
        state.army = { ...DEFAULT_STATE.army, ...(_isPlain(parsed.army) ? parsed.army : {}) };
        state.farm = { ...DEFAULT_STATE.farm, ...(_isPlain(parsed.farm) ? parsed.farm : {}) };
        state.mine = { ...DEFAULT_STATE.mine, ...(_isPlain(parsed.mine) ? parsed.mine : {}) };
        state.lumberProd = { ...DEFAULT_STATE.lumberProd, ...(_isPlain(parsed.lumberProd) ? parsed.lumberProd : {}) };
        state.inventory = { ...DEFAULT_STATE.inventory, ...(_isPlain(parsed.inventory) ? parsed.inventory : {}) };
        state.smith = { ...DEFAULT_STATE.smith, ...(_isPlain(parsed.smith) ? parsed.smith : {}) };
        state.lumber = { ...DEFAULT_STATE.lumber, ...(_isPlain(parsed.lumber) ? parsed.lumber : {}) };
        state.barracksTraining = { ...DEFAULT_STATE.barracksTraining, ...(_isPlain(parsed.barracksTraining) ? parsed.barracksTraining : {}) };
        state.hospital = { ...DEFAULT_STATE.hospital, ...(_isPlain(parsed.hospital) ? parsed.hospital : {}) };
        state.crateLimits = { ...DEFAULT_STATE.crateLimits, ...(_isPlain(parsed.crateLimits) ? parsed.crateLimits : {}) };
        state.castle = { ...DEFAULT_STATE.castle, ...(_isPlain(parsed.castle) ? parsed.castle : {}) };
        state.watchtower = { ...DEFAULT_STATE.watchtower, ...(_isPlain(parsed.watchtower) ? parsed.watchtower : {}) };
        state.peaceTreaty = { ...DEFAULT_STATE.peaceTreaty, ...(_isPlain(parsed.peaceTreaty) ? parsed.peaceTreaty : {}) };
        state.watchtowerEquipment = { ...DEFAULT_STATE.watchtowerEquipment, ...(_isPlain(parsed.watchtowerEquipment) ? parsed.watchtowerEquipment : {}) };
        state.academyResearch = { ...DEFAULT_STATE.academyResearch, ...(_isPlain(parsed.academyResearch) ? parsed.academyResearch : {}) };
        state.academyResearch.activeResearch = { ...DEFAULT_STATE.academyResearch.activeResearch, ...(_isPlain(parsed.academyResearch && parsed.academyResearch.activeResearch) ? parsed.academyResearch.activeResearch : {}) };
        state.migration_done_v2 = (typeof parsed.migration_done_v2 === 'boolean') ? parsed.migration_done_v2 : false;
        state.commanderName = (typeof parsed.commanderName === 'string') ? parsed.commanderName : 'آرش';
        
        state.specialOffer = { ...DEFAULT_STATE.specialOffer, ...(_isPlain(parsed.specialOffer) ? parsed.specialOffer : {}) };

        state.upgrade = _isPlain(parsed.upgrade) ? parsed.upgrade : null;
        state.messages = Array.isArray(parsed.messages) ? parsed.messages : [];
        state.msgUnread = _safeInt(parsed.msgUnread, 0);
        state.battle = { cd: {}, inProgress: null, lastResult: null, log: [], ...(_isPlain(parsed.battle) ? parsed.battle : {}) };

        const _rawXp = _safeNum(parsed.xp, 0);
        const _rawLvl = Math.max(1, _safeInt(parsed.player_level, 1));
        state.xp = _rawXp > 0 ? _rawXp : ((typeof xpForLevel === 'function') ? xpForLevel(_rawLvl) : Math.pow(_rawLvl - 1, 2) * 100);
        state.player_level = (typeof getLevelFromXP === 'function') ? getLevelFromXP(state.xp) : (Math.floor(Math.sqrt(state.xp / 100)) + 1);

        if (!state.migration_done_v2 && typeof xpForLevel === 'function') {
          const _minXpForOldLevel = xpForLevel(_rawLvl);
          if (state.xp < _minXpForOldLevel) {
            state.xp = _minXpForOldLevel;
            if (typeof getLevelFromXP === 'function') state.player_level = getLevelFromXP(state.xp);
          }
          state.migration_done_v2 = true;
        }

        state.missions = { day: '', progress: {}, claimed: {}, ...(_isPlain(parsed.missions) ? parsed.missions : {}) };
        state.flashEvent = { ...DEFAULT_STATE.flashEvent, ...(_isPlain(parsed.flashEvent) ? parsed.flashEvent : {}) };
        state.harvestCounter = _safeInt(parsed.harvestCounter, 0);
        state.liveTask = { ...DEFAULT_STATE.liveTask, ...(_isPlain(parsed.liveTask) ? parsed.liveTask : {}) };
        state.unopenedLevelChests = _safeInt(parsed.unopenedLevelChests, 0);

        if (typeof profilesData !== 'undefined' && Array.isArray(profilesData)) {
          const validProfiles = profilesData.map(p => p.id);
          state.owned_profiles = Array.isArray(parsed.owned_profiles) ? parsed.owned_profiles.filter(id => typeof id === 'string' && validProfiles.includes(id)) : ['castle'];
          if (!state.owned_profiles.includes('castle')) state.owned_profiles.unshift('castle');
          state.active_profile = validProfiles.includes(parsed.active_profile) ? parsed.active_profile : 'castle';
        }

        const now = Date.now();
        if (state.farm.isProducing) { try { calculateOfflineFarm(); } catch (e) {} state.farm.lastTickTime = now; }
        if (state.mine.isProducing) { try { calculateOfflineMine(); } catch (e) {} state.mine.lastTickTime = now; }
        if (state.lumberProd.isProducing) { try { calculateOfflineLumber(); } catch (e) {} state.lumberProd.lastTickTime = now; }
        try { if (typeof tickCastleTax === 'function') tickCastleTax(now); } catch (e) {}
        if (state.smith.isCrafting && now >= state.smith.endTime) { state.smith.isCrafting = false; state.smith.isReady = true; }
        if (state.lumber.isCrafting && now >= state.lumber.endTime) { state.lumber.isCrafting = false; state.lumber.isReady = true; }

        _loadOk = true;
      } catch (e) {
        console.warn('Save corrupted.', e);
        try { lsSet('bok_corrupt', saved); } catch (_) {}
        state = JSON.parse(JSON.stringify(DEFAULT_STATE));
        _loadOk = true;
      }
    } else {
      _loadOk = true;
    }

    try { sanitizeState(); } catch (e) { console.error('sanitizeState failed', e); }
    try { sanitizeCrateLimits(); } catch (e) { console.error('sanitizeCrateLimits failed', e); }

    try {
      if (typeof checkMissionDay === 'function') checkMissionDay();
      if (typeof missionAdd === 'function' && !state.missions.claimed['daily']) missionAdd('daily');
    } catch (e) { console.warn('missionAdd failed', e); }

    try { if (typeof updateUI === 'function') updateUI(); } catch (e) { console.warn('updateUI failed', e); }
  } catch (e) {
    console.error('loadGame failed completely:', e);
    try { state = JSON.parse(JSON.stringify(DEFAULT_STATE)); sanitizeState(); _loadOk = true; }
    catch (e2) { console.error('recovery failed', e2); }
  } finally {
    gameLocked = _wasLocked;
  }

  if (_loadOk && !gameLocked) {
    try { saveGame(); } catch (e) { console.warn('post-load save failed', e); }
  }
}

function calculateOfflineFarm() {
  if (!_isPlain(state.farm)) return;
  let off = (Date.now() - state.farm.lastTickTime) / 1000;
  if (!isFinite(off) || off <= 0) return;
  if (off > OFFLINE_MAX_SECONDS) off = OFFLINE_MAX_SECONDS;
  const lvl = Math.max(1, _safeInt(state.buildings.farm, 1));
  const cap = typeof getProdCapacity === 'function' ? getProdCapacity('farm') : 200 + ((lvl - 1) * 400);
  const curA = _safeNum(state.farm.accumulatedAzooghe, 0);
  const curW = _safeNum(state.farm.accumulatedWood, 0);
  const cur = curA + curW;
  if (cur < cap) {
    const rates = typeof getProdRatePerMin === 'function' ? getProdRatePerMin('farm') : { azooghe: 4 * lvl, wood: 2 * lvl };
    let a = (off * rates.azooghe) / 60, w = (off * rates.wood) / 60;
    const tot = a + w;
    if (!isFinite(tot) || tot <= 0) return;
    if (cur + tot > cap) { const r = (cap - cur) / tot; a *= r; w *= r; }
    if (isFinite(a) && a > 0) state.farm.accumulatedAzooghe = curA + a;
    if (isFinite(w) && w > 0) state.farm.accumulatedWood = curW + w;
  }
}
function calculateOfflineMine() {
  if (!_isPlain(state.mine)) return;
  let off = (Date.now() - state.mine.lastTickTime) / 1000;
  if (!isFinite(off) || off <= 0) return;
  if (off > OFFLINE_MAX_SECONDS) off = OFFLINE_MAX_SECONDS;
  const lvl = Math.max(1, _safeInt(state.buildings.mine, 1));
  const cap = typeof getProdCapacity === 'function' ? getProdCapacity('mine') : 300 + ((lvl - 1) * 500);
  const curS = _safeNum(state.mine.accumulatedStone, 0);
  const curC = _safeNum(state.mine.accumulatedCoal, 0);
  const curD = _safeNum(state.mine.accumulatedDiamond, 0);
  const cur = curS + curC + curD;
  if (cur < cap) {
    const rates = typeof getProdRatePerMin === 'function' ? getProdRatePerMin('mine') : { stone: 12 * lvl, coal: 3 * lvl, diamond: 0.1 * lvl };
    let s = (off * rates.stone) / 60, c = (off * rates.coal) / 60;
    let d = (off * rates.diamond) / 60;
    const tot = s + c + d;
    if (!isFinite(tot) || tot <= 0) return;
    if (cur + tot > cap) { const r = (cap - cur) / tot; s *= r; c *= r; d *= r; }
    if (isFinite(s) && s > 0) state.mine.accumulatedStone = curS + s;
    if (isFinite(c) && c > 0) state.mine.accumulatedCoal = curC + c;
    if (isFinite(d) && d > 0) state.mine.accumulatedDiamond = curD + d;
  }
}
function calculateOfflineLumber() {
  if (!_isPlain(state.lumberProd)) return;
  let off = (Date.now() - state.lumberProd.lastTickTime) / 1000;
  if (!isFinite(off) || off <= 0) return;
  if (off > OFFLINE_MAX_SECONDS) off = OFFLINE_MAX_SECONDS;
  const lvl = Math.max(1, _safeInt(state.buildings.lumber, 1));
  const cap = typeof getProdCapacity === 'function' ? getProdCapacity('lumberProd') : 200 + ((lvl - 1) * 400);
  const cur = _safeNum(state.lumberProd.accumulatedWood, 0);
  if (cur < cap) {
    const rates = typeof getProdRatePerMin === 'function' ? getProdRatePerMin('lumberProd') : { wood: 8 * lvl };
    let w = (off * rates.wood) / 60;
    if (!isFinite(w) || w <= 0) return;
    if (cur + w > cap) w = cap - cur;
    state.lumberProd.accumulatedWood = cur + w;
  }
}