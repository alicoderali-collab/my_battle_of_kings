// ============================================================
// ⚔️ BATTLE OF KINGS - js/buildings.js (v11 - FIXED)
// 3 fixes: ratePerMin display, reward tab, font-family
// ============================================================

const _bNum = (v, fb) => { if (typeof v !== 'number') v = Number(v); return isFinite(v) && v >= 0 ? v : (fb || 0); };
const _bInt = (v, fb) => Math.floor(_bNum(v, fb));

let currentHealQty = 1;
let _trainCancelArm = 0;
let _msgActiveTab = 'all';
const PROD = {
  farm: { baseCap: 200, capPerLevel: 400, rates: lvl => ({ azooghe: 4 * lvl, wood: 2 * lvl }) },
  mine: { baseCap: 300, capPerLevel: 500, rates: lvl => ({ stone: 12 * lvl, coal: 3 * lvl, diamond: 0.1 * lvl }) },
  lumberProd: { baseCap: 200, capPerLevel: 400, rates: lvl => ({ wood: 8 * lvl }) }
};
function getProdCapacity(kind) {
  const cfg = PROD[kind]; if (!cfg) return 0;
  const building = kind === 'lumberProd' ? 'lumber' : kind;
  const lvl = Math.max(1, _bInt(state.buildings && state.buildings[building], 1));
  return cfg.baseCap + (lvl - 1) * cfg.capPerLevel;
}
function getProdRatePerMin(kind) {
  const cfg = PROD[kind]; if (!cfg) return {};
  const building = kind === 'lumberProd' ? 'lumber' : kind;
  const lvl = Math.max(1, _bInt(state.buildings && state.buildings[building], 1));
  return cfg.rates(lvl);
}
function getCastleRatePerMin() {
  const lvl = Math.max(1, _bInt(state.buildings && state.buildings.castle, 1));
  const buffs = typeof getAcademyBuffs === 'function' ? getAcademyBuffs() : { goldProd: 1 };
  return 0.3 * lvl * _bNum(buffs.goldProd, 1);
}
function _splitHarvest(value) {
  const safe = _bNum(value, 0), whole = Math.floor(safe);
  return { amount: whole, remainder: Math.max(0, safe - whole) };
}

// 🆕 helper برای نمایش اعشاری اعداد (برای ratePerMin)
function _fmtRate(v) {
  v = _bNum(v, 0);
  if (v <= 0) return '۰';
  if (v < 1) {
    const s = v.toFixed(1);
    return s.replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]).replace('.', '٫');
  }
  return toFa(Math.floor(v));
}

// ============================================================
// 🌾 Floating Icons
// ============================================================
function spawnIcon(emoji, left, top) {
  const map = $('gameMap'); if (!map) return;
  if (typeof emoji !== 'string' || !emoji) return;
  const icon = document.createElement('div');
  icon.className = 'floating-icon';
  icon.textContent = emoji;
  icon.style.left = String(left || '0%');
  icon.style.top = String(top || '0%');
  map.appendChild(icon);
  setTimeout(() => { if (icon.parentNode) icon.parentNode.removeChild(icon); }, 2000);
}

// ============================================================
// 🔘 Production Buttons
// ============================================================
function renderProdButtons(kind, isFull) {
  const box = $(kind + '-buttons'); if (!box) return;
  const o = state[kind];
  if (!_isPlainObj(o)) return;
  const fn = {
    farm:       ['startFarmProduction','harvestFarm'],
    mine:       ['startMineProduction','harvestMine'],
    lumberProd: ['startLumberProd','harvestLumberProd']
  }[kind];
  if (!fn) return;
  const mode = !o.isProducing ? 'start' : (isFull ? 'full' : 'harvest');
  if (box.dataset.mode !== mode) {
    box.dataset.mode = mode;
    box.innerHTML = mode === 'start'
      ? `<button class="btn-action" onclick="${fn[0]}()">شروع تولید</button>`
      : mode === 'full'
        ? `<button class="btn-action" onclick="${fn[1]}(true)">برداشت و شروع دوباره 🔄</button><button class="btn-action" style="background:#333;color:#fff;margin-top:5px;" onclick="${fn[1]}(false)">فقط برداشت</button>`
        : `<button class="btn-action" onclick="${fn[1]}(false)">برداشت محصول</button>`;
  }
  if (mode === 'harvest') {
    const btn = box.querySelector('button');
    if (!btn) return;
    const t = Date.now() - _bNum(o.startTime, 0);
    let cur = 0;
    if (kind === 'farm') cur = _bNum(state.farm && state.farm.accumulatedAzooghe, 0) + _bNum(state.farm && state.farm.accumulatedWood, 0);
    else if (kind === 'mine') cur = _bNum(state.mine && state.mine.accumulatedStone, 0) + _bNum(state.mine && state.mine.accumulatedCoal, 0) + _bNum(state.mine && state.mine.accumulatedDiamond, 0);
    else if (kind === 'lumberProd') cur = _bNum(state.lumberProd && state.lumberProd.accumulatedWood, 0);
    if (cur < 1) {
      btn.disabled = true;
      btn.innerHTML = `در حال جمع‌آوری... ${timerIconHTML(16)}`;
    } else {
      const locked = !isFinite(t) || t < 60000;
      btn.disabled = locked;
      btn.innerHTML = locked
        ? `قفل (${toFa(Math.ceil((60000 - _bNum(t, 0)) / 1000))} ثانیه) ${timerIconHTML(16)}`
        : 'برداشت محصول ✅';
    }
  }
}

// ============================================================
// 🌾 Farm
// ============================================================
function startFarmProduction() {
  if (!acquireLock()) return;
  try {
    if (!_isPlainObj(state.farm)) state.farm = JSON.parse(JSON.stringify(DEFAULT_STATE.farm));
    if (!state.farm.isProducing) {
      try {
        transaction(() => {
          state.farm = { isProducing: true, accumulatedAzooghe: 0, accumulatedWood: 0, startTime: Date.now(), lastTickTime: Date.now(), lastAnimatedMinute: 0 };
        });
        saveGame(); showToast('تولید مزرعه شروع شد! 🌾'); updateFarmModalUI();
      } catch(e) { console.error(e); }
    }
  } finally { releaseLock(); }
}

function harvestFarm(restart = false) {
  if (!acquireLock()) return;
  try {
    if (!_isPlainObj(state.farm) || !state.farm.isProducing) return;
    const t = Date.now() - _bNum(state.farm.startTime, 0);
    if (!isFinite(t) || t < 60000) {
      showToast('برای برداشت باید حداقل ۱ دقیقه صبر کنی! ⏱️', 'error'); playSFX('error'); return;
    }
    const farmWasFull = (
      _bNum(state.farm.accumulatedAzooghe, 0) +
      _bNum(state.farm.accumulatedWood, 0)
    ) >= getProdCapacity('farm') - 0.5;
    
    // بررسی فرصت طلایی
    let multiplier = 1;
    if (state.flashEvent && state.flashEvent.active && state.flashEvent.target === 'farm' && _bNum(state.flashEvent.expiresAt, 0) > Date.now()) {
      multiplier = 2;
      if (typeof showToast === 'function') showToast('⚡ فرصت طلایی! جایزه ۲ برابر شد!', 'success');
      if (typeof playSoundFile === 'function') playSoundFile('ghost/chest_bouns.mp3', 0.8);
    }

    const azoStored = _bNum(state.farm.accumulatedAzooghe, 0);
    const azoAmt = Math.floor(azoStored) * multiplier;
    const woodStored = _bNum(state.farm.accumulatedWood, 0);
    const woodAmt = Math.floor(woodStored) * multiplier;
    
    try {
      transaction(() => {
        state.azooghe = _bNum(state.azooghe, 0) + azoAmt;
        state.wood = _bNum(state.wood, 0) + woodAmt;
        if (restart) {
          state.farm.accumulatedAzooghe = azoStored - Math.floor(azoStored); state.farm.accumulatedWood = woodStored - Math.floor(woodStored);
          state.farm.startTime = Date.now(); state.farm.lastTickTime = Date.now(); state.farm.lastAnimatedMinute = 0;
        } else {
          state.farm.isProducing = false; state.farm.accumulatedAzooghe = azoStored - Math.floor(azoStored); state.farm.accumulatedWood = woodStored - Math.floor(woodStored); state.farm.startTime = 0;
        }
        if (multiplier > 1 && state.flashEvent) state.flashEvent.active = false;
      });
    } catch(e) { showToast('خطا در برداشت!', 'error'); return; }
    
    updateUI(); saveGame();
    for (let i = 0; i < 3; i++) setTimeout(() => spawnIcon('🌾','10%','32%'), i * 200);
    if (typeof missionAdd === 'function') missionAdd('harvest');
    if (typeof updateLiveTaskProgress === 'function') updateLiveTaskProgress('harvest');
    if (farmWasFull && typeof updateSpecialOfferProgress === 'function') updateSpecialOfferProgress('farm');
    
    // سیستم شمارشگر برداشت
    state.harvestCounter = _bNum(state.harvestCounter, 0) + 1;
    if (state.harvestCounter >= 3) {
      state.harvestCounter = 0;
      if (typeof triggerFlashEvent === 'function') triggerFlashEvent();
    }
    saveGame();

    showToast('برداشت موفق! ✅');
    playSFX('success'); playSoundFile('ghost/Collect.mp3', 0.6);
    if (currentBuilding === 'farm') updateFarmModalUI();
  } finally { releaseLock(); }
}

// ============================================================
// ⛏️ Mine
// ============================================================
function startMineProduction() {
  if (!acquireLock()) return;
  try {
    if (!_isPlainObj(state.mine)) state.mine = JSON.parse(JSON.stringify(DEFAULT_STATE.mine));
    if (!state.mine.isProducing) {
      try {
        transaction(() => {
          state.mine = { isProducing: true, accumulatedStone: 0, accumulatedCoal: 0, accumulatedDiamond: 0, startTime: Date.now(), lastTickTime: Date.now(), lastAnimatedMinute: 0 };
        });
        saveGame(); showToast('تولید معدن شروع شد! ⛏️'); updateMineModalUI();
      } catch(e) { console.error(e); }
    }
  } finally { releaseLock(); }
}

function harvestMine(restart = false) {
  if (!acquireLock()) return;
  try {
    if (!_isPlainObj(state.mine) || !state.mine.isProducing) return;
    const t = Date.now() - _bNum(state.mine.startTime, 0);
    if (!isFinite(t) || t < 60000) {
      showToast('برای برداشت باید حداقل ۱ دقیقه صبر کنی! ⏱️', 'error'); playSFX('error'); return;
    }
    
    let multiplier = 1;
    if (state.flashEvent && state.flashEvent.active && state.flashEvent.target === 'mine' && _bNum(state.flashEvent.expiresAt, 0) > Date.now()) {
      multiplier = 2;
      if (typeof showToast === 'function') showToast('⚡ فرصت طلایی! جایزه ۲ برابر شد!', 'success');
      if (typeof playSoundFile === 'function') playSoundFile('ghost/chest_bouns.mp3', 0.8);
    }

    const mineWasFull = (_bNum(state.mine.accumulatedStone, 0) + _bNum(state.mine.accumulatedCoal, 0) + _bNum(state.mine.accumulatedDiamond, 0)) >= getProdCapacity('mine') - 0.5;
    const stStored = _bNum(state.mine.accumulatedStone, 0);
    const stAmt = Math.floor(stStored) * multiplier;
    const coStored = _bNum(state.mine.accumulatedCoal, 0);
    const coAmt = Math.floor(coStored) * multiplier;
    const diStored = _bNum(state.mine.accumulatedDiamond, 0);
    const diAmt = Math.floor(diStored) * multiplier;
    try {
      transaction(() => {
        state.stone = _bNum(state.stone, 0) + stAmt;
        state.coal = _bNum(state.coal, 0) + coAmt;
        state.diamond = _bNum(state.diamond, 0) + diAmt;
        if (restart) {
          state.mine.accumulatedStone = stStored - Math.floor(stStored); state.mine.accumulatedCoal = coStored - Math.floor(coStored); state.mine.accumulatedDiamond = diStored - Math.floor(diStored);
          state.mine.startTime = Date.now(); state.mine.lastTickTime = Date.now(); state.mine.lastAnimatedMinute = 0;
        } else {
          state.mine.isProducing = false; state.mine.accumulatedStone = stStored - Math.floor(stStored); state.mine.accumulatedCoal = coStored - Math.floor(coStored); state.mine.accumulatedDiamond = diStored - Math.floor(diStored); state.mine.startTime = 0;
        }
        if (multiplier > 1 && state.flashEvent) state.flashEvent.active = false;
      });
    } catch(e) { showToast('خطا در برداشت!', 'error'); return; }
    
    updateUI(); saveGame();
    for (let i = 0; i < 3; i++) setTimeout(() => spawnIcon('🪨','10%','15%'), i * 200);
    if (typeof missionAdd === 'function') { missionAdd('harvest'); if (mineWasFull) missionAdd('mine5'); }
    if (typeof updateLiveTaskProgress === 'function') updateLiveTaskProgress('harvest');
    if (mineWasFull && typeof updateSpecialOfferProgress === 'function') updateSpecialOfferProgress('mine');
    
    state.harvestCounter = _bNum(state.harvestCounter, 0) + 1;
    if (state.harvestCounter >= 3) {
      state.harvestCounter = 0;
      if (typeof triggerFlashEvent === 'function') triggerFlashEvent();
    }
    saveGame();

    showToast('برداشت موفق! ✅');
    playSFX('success'); playSoundFile('ghost/Collect.mp3', 0.6);
    if (currentBuilding === 'mine') updateMineModalUI();
  } finally { releaseLock(); }
}

// ============================================================
// 🪵 Lumber Production
// ============================================================
function startLumberProd() {
  if (!acquireLock()) return;
  try {
    if (!_isPlainObj(state.lumberProd)) state.lumberProd = JSON.parse(JSON.stringify(DEFAULT_STATE.lumberProd));
    if (!state.lumberProd.isProducing) {
      try {
        transaction(() => {
          state.lumberProd = { isProducing: true, accumulatedWood: 0, startTime: Date.now(), lastTickTime: Date.now(), lastAnimatedMinute: 0 };
        });
        saveGame(); showToast('تولید چوب شروع شد! 🪵'); updateLumberModalUI();
      } catch(e) { console.error(e); }
    }
  } finally { releaseLock(); }
}

function harvestLumberProd(restart = false) {
  if (!acquireLock()) return;
  try {
    if (!_isPlainObj(state.lumberProd) || !state.lumberProd.isProducing) return;
    const t = Date.now() - _bNum(state.lumberProd.startTime, 0);
    if (!isFinite(t) || t < 60000) {
      showToast('برای برداشت باید حداقل ۱ دقیقه صبر کنی! ⏱️', 'error'); playSFX('error'); return;
    }
    const lumberWasFull = _bNum(state.lumberProd.accumulatedWood, 0) >= getProdCapacity('lumberProd') - 0.5;
    
    let multiplier = 1;
    if (state.flashEvent && state.flashEvent.active && state.flashEvent.target === 'lumber' && _bNum(state.flashEvent.expiresAt, 0) > Date.now()) {
      multiplier = 2;
      if (typeof showToast === 'function') showToast('⚡ فرصت طلایی! جایزه ۲ برابر شد!', 'success');
      if (typeof playSoundFile === 'function') playSoundFile('ghost/chest_bouns.mp3', 0.8);
    }

    const woodStored = _bNum(state.lumberProd.accumulatedWood, 0);
    const woodAmt = Math.floor(woodStored) * multiplier;
    try {
      transaction(() => {
        state.wood = _bNum(state.wood, 0) + woodAmt;
        if (restart) {
          state.lumberProd.accumulatedWood = woodStored - Math.floor(woodStored);
          state.lumberProd.startTime = Date.now(); state.lumberProd.lastTickTime = Date.now(); state.lumberProd.lastAnimatedMinute = 0;
        } else {
          state.lumberProd.isProducing = false; state.lumberProd.accumulatedWood = woodStored - Math.floor(woodStored); state.lumberProd.startTime = 0;
        }
        if (multiplier > 1 && state.flashEvent) state.flashEvent.active = false;
      });
    } catch(e) { showToast('خطا در برداشت!', 'error'); return; }
    
    updateUI(); saveGame();
    for (let i = 0; i < 3; i++) setTimeout(() => spawnIcon('🪵','70%','20%'), i * 200);
    if (typeof missionAdd === 'function') missionAdd('harvest');
    if (typeof updateLiveTaskProgress === 'function') updateLiveTaskProgress('harvest');
    if (lumberWasFull && typeof updateSpecialOfferProgress === 'function') updateSpecialOfferProgress('lumber');
    
    state.harvestCounter = _bNum(state.harvestCounter, 0) + 1;
    if (state.harvestCounter >= 3) {
      state.harvestCounter = 0;
      if (typeof triggerFlashEvent === 'function') triggerFlashEvent();
    }
    saveGame();

    showToast('برداشت موفق! ✅');
    playSFX('success'); playSoundFile('ghost/Collect.mp3', 0.6);
    if (currentBuilding === 'lumber') updateLumberModalUI();
  } finally { releaseLock(); }
}

// ============================================================
// ⚒️ Crafting Shared
// ============================================================
function craftTime(recipe, qty, type) {
  if (!recipe || typeof recipe.time !== 'number' || !isFinite(recipe.time) || recipe.time <= 0) return 0;
  const lvl = Math.max(1, _bInt(state.buildings && state.buildings[type], 1));
  const mul = Math.max(0.4, 1 - 0.1 * (lvl - 1));
  return Math.floor(recipe.time * Math.max(0, _bInt(qty, 1)) * mul);
}

function quickMaxCraft(itemKey, type) {
  const recipes = type === 'smith' ? SMITH_RECIPES : LUMBER_RECIPES;
  const recipe = recipes && recipes[itemKey];
  if (!recipe) return;
  let maxAffordable = 1000;
  for (const res in recipe.cost) {
    const have = state[res] !== undefined ? _bNum(state[res], 0) : _bNum(state.inventory && state.inventory[res], 0);
    const cost = recipe.cost[res];
    if (cost > 0) maxAffordable = Math.min(maxAffordable, Math.floor(have / cost));
  }
  if (maxAffordable <= 0) {
    showToast("منابع کافی برای ساخت این آیتم را ندارید! ❌", 'error'); playSFX('error'); return;
  }
  openQuantityModal(itemKey, type);
  setTimeout(() => {
    const modal = $('quantityModal');
    if (!modal || !modal.classList.contains('show')) return;
    const btns = modal.querySelectorAll('.qty-btn');
    for (let b of btns) if (b.textContent === 'حداکثر' && !b.disabled) { b.click(); break; }
  }, 60);
}

function closeQuantityModal() {
  const modal = $('quantityModal');
  if (modal) modal.classList.remove('show');
  currentCraftItem = null; currentCraftType = null; currentCraftQty = 1; currentHealQty = 1;
  window._trainUnitKey = null;
  window._trainQty = 1;
  window._trainMaxAffordable = 0;
  const cb = $('qty-confirm-btn'); if (cb) cb.onclick = null;
}

function openQuantityModal(itemKey, type) {
  if (isProcessing) { showToast('⏳ لطفاً صبر کنید...', 'error'); return; }
  const sys = type === 'smith' ? state.smith : state.lumber;
  if (!_isPlainObj(sys)) { showToast('سیستم ساخت در دسترس نیست! ❌', 'error'); return; }
  if (sys.isCrafting || sys.isReady) { showToast("این بخش مشغول است!", 'error'); playSFX('error'); return; }
  const recipe = type === 'smith' ? (SMITH_RECIPES && SMITH_RECIPES[itemKey]) : (LUMBER_RECIPES && LUMBER_RECIPES[itemKey]);
  if (!recipe || !recipe.cost) { showToast('دستور ساخت نامعتبر! ❌', 'error'); playSFX('error'); return; }
  currentCraftItem = itemKey; currentCraftType = type; currentCraftQty = 1;
  const titleEl = $('qty-title');
  if (titleEl) { titleEl.textContent = `ساخت ${recipe.name || itemKey}`; titleEl.style.color = 'var(--gold)'; }
  const detailsEl = $('qty-details');
  if (detailsEl) { detailsEl.style.display = 'none'; detailsEl.innerHTML = ''; }
  const qtyGrid = $('qty-grid'); if (!qtyGrid) return;
  qtyGrid.innerHTML = '';
  const qtys = [1, 5, 10, 50, 100, 500, 1000];
  let anyAffordable = false;
  let maxAffordable = 1000;
  for (const res in recipe.cost) {
    const have = state[res] !== undefined ? _bNum(state[res], 0) : _bNum(state.inventory && state.inventory[res], 0);
    const cost = recipe.cost[res];
    if (cost > 0) maxAffordable = Math.min(maxAffordable, Math.floor(have / cost));
  }
  qtys.forEach(q => {
    let canAfford = true;
    for (const res in recipe.cost) {
      const req = recipe.cost[res] * q;
      const av = state[res] !== undefined ? _bNum(state[res], 0) : _bNum(state.inventory && state.inventory[res], 0);
      if (av < req) { canAfford = false; break; }
    }
    const btn = document.createElement('button');
    btn.className = 'qty-btn'; btn.textContent = q.toLocaleString('fa-IR');
    if (!canAfford) btn.disabled = true; else anyAffordable = true;
    btn.onclick = () => {
      if (btn.disabled) return;
      qtyGrid.querySelectorAll('.qty-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected'); currentCraftQty = q; updateQuantityDetails(itemKey, q, type); playSFX('click');
    };
    qtyGrid.appendChild(btn);
  });
  if (maxAffordable > 0) {
    const btnMax = document.createElement('button');
    btnMax.className = 'qty-btn'; btnMax.textContent = 'حداکثر';
    btnMax.onclick = () => {
      qtyGrid.querySelectorAll('.qty-btn').forEach(b => b.classList.remove('selected'));
      btnMax.classList.add('selected'); currentCraftQty = maxAffordable; updateQuantityDetails(itemKey, maxAffordable, type); playSFX('click');
    };
    qtyGrid.appendChild(btnMax);
  }
  if (!anyAffordable) { showToast("منابع کافی برای ساخت این آیتم را ندارید! ❌", 'error'); playSFX('error'); return; }
  const firstBtn = qtyGrid.querySelector('button:not(:disabled)');
  if (firstBtn) firstBtn.click();
  $('qty-confirm-btn').onclick = confirmCraft;
  $('quantityModal').classList.add('show');
}

function updateQuantityDetails(itemKey, qty, type) {
  const recipe = type === 'smith' ? (SMITH_RECIPES && SMITH_RECIPES[itemKey]) : (LUMBER_RECIPES && LUMBER_RECIPES[itemKey]);
  if (!recipe || !recipe.cost) return;
  let costHtml = '';
  for (const res in recipe.cost) {
    const qtySafe = Math.max(0, _bInt(qty, 1));
    const iconRaw = (typeof RES_ICON !== 'undefined' && RES_ICON[res]) || '';
    const iconHtml = (typeof iconHTML === 'function') ? iconHTML(iconRaw, 18, '🎁') : iconRaw;
    costHtml += `${iconHtml} ${toFa(_bNum(recipe.cost[res], 0) * qtySafe)} ${(typeof resNames !== 'undefined' && resNames[res]) || res} | `;
  }
  const totalSec = Math.ceil(craftTime(recipe, qty, type) / 1000);
  const m = Math.floor(totalSec / 60), s = totalSec % 60;
  const timeStr = m > 0 ? `${toFa(m)} دقیقه و ${toFa(s)} ثانیه` : `${toFa(s)} ثانیه`;
  const details = $('qty-details'); if (!details) return;
  details.style.display = 'block';
  details.innerHTML = `<div>شما ${toFa(qty)} عدد ${recipe.name || itemKey} می‌خواهید بسازید.</div><div style="margin-top:5px;color:var(--gold);">هزینه: ${costHtml}</div><div style="margin-top:5px;color:#8bc34a;">${timerIconHTML(12)} زمان: ${timeStr}</div>`;
  const confirmBtn = $('qty-confirm-btn'); if (confirmBtn) confirmBtn.disabled = false;
}

function confirmCraft() {
  const confirmBtn = $('qty-confirm-btn');
  if (confirmBtn) confirmBtn.onclick = null;
  if (!acquireLock()) return;
  try {
    if (!currentCraftItem || !currentCraftType) return;
    if (!isFinite(currentCraftQty) || currentCraftQty <= 0) { showToast('تعداد نامعتبر است! ❌', 'error'); playSFX('error'); return; }
    const type = currentCraftType;
    if (type !== 'smith' && type !== 'lumber') return;
    const sys = type === 'smith' ? state.smith : state.lumber;
    const recipes = type === 'smith' ? SMITH_RECIPES : LUMBER_RECIPES;
    if (!_isPlainObj(sys) || !recipes) { showToast('سیستم ساخت در دسترس نیست! ❌', 'error'); return; }
    if (sys.isCrafting || sys.isReady) { showToast("خطا: این بخش مشغول است!", 'error'); playSFX('error'); return; }
    const recipe = recipes[currentCraftItem];
    if (!recipe || !recipe.cost) { showToast('دستور ساخت نامعتبر! ❌', 'error'); return; }
    const qty = Math.floor(currentCraftQty);
    const totalCost = {};
    for (const res in recipe.cost) {
      if (_isBadKey(res)) continue;
      totalCost[res] = _bNum(recipe.cost[res], 0) * qty;
    }
    try {
      transaction(() => {
        if (!deductResources(totalCost)) throw new Error('insufficient');
        const t = craftTime(recipe, qty, type);
        if (t <= 0) throw new Error('invalid time');
        sys.isCrafting = true; sys.isReady = false; sys.item = currentCraftItem;
        sys.amount = qty; sys.startTime = Date.now(); sys.endTime = Date.now() + t;
      });
    } catch (e) {
      showToast("منابع کافی نیست یا خطایی رخ داد! ❌", 'error'); playSFX('error'); return;
    }
    updateUI(); saveGame(); closeQuantityModal();
    if (type === 'smith') updateSmithModalUI(); else updateLumberModalUI();
    showToast(`ساخت ${toFa(qty)} عدد ${recipe.name} آغاز شد! ⚒️`);
    playSFX('success'); playSoundFile('ghost/dropping-single-coin.mp3', 0.6);
  } finally { releaseLock(); }
}

function harvestCraft(type) {
  if (!acquireLock()) return;
  try {
    const sys = type === 'smith' ? state.smith : state.lumber;
    const recipes = type === 'smith' ? SMITH_RECIPES : LUMBER_RECIPES;
    if (!_isPlainObj(sys) || !recipes) return;
    if (!sys.isReady) return;
    const it = sys.item;
    if (typeof it !== 'string' || !recipes[it] || _isBadKey(it)) {
      showToast('محصول نامعتبر! ❌', 'error'); playSFX('error');
      sys.isCrafting = false; sys.isReady = false; sys.item = null; sys.amount = 0; saveGame(); return;
    }
    const amt = Math.floor(_bNum(sys.amount, 0));
    if (amt <= 0) { showToast('مقدار نامعتبر! ❌', 'error'); return; }
    try {
      transaction(() => {
        if (it === 'iron') {
          state.iron = _bNum(state.iron, 0) + amt;
        } else {
          if (!_isPlainObj(state.inventory)) state.inventory = {};
          state.inventory[it] = _bNum(state.inventory[it], 0) + amt;
        }
        sys.isCrafting = false; sys.isReady = false; sys.item = null; sys.amount = 0;
      });
    } catch(e) { return; }
    showToast(`برداشت موفق: ${toFa(amt)} عدد ${recipes[it].name} اضافه شد! ✅`);
    setTimeout(() => {
      if (typeof missionAdd === 'function') missionAdd('craft10', amt);
      if (typeof missionAdd === 'function' && type === 'lumber') {
        const siege = it === 'catapult' ? amt : (it === 'wall' ? amt * 0.4 : 0);
        if (siege > 0) missionAdd('siegeBuild', siege);
      }
    }, 0);
    updateUI(); saveGame();
    if (type === 'smith') updateSmithModalUI(); else updateLumberModalUI();
    playSFX('success'); playSoundFile('ghost/Collect.mp3', 0.6);
  } finally { releaseLock(); }
}

function cancelCraft(type) {
  if (Date.now() > (cancelArm[type] || 0)) {
    cancelArm[type] = Date.now() + 3000;
    showToast('برای تأیید لغو، دوباره بزن ⚠️', 'error'); playSFX('error'); return;
  }
  cancelArm[type] = 0;
  if (!acquireLock()) return;
  try {
    const sys = type === 'smith' ? state.smith : state.lumber;
    const recipes = type === 'smith' ? SMITH_RECIPES : LUMBER_RECIPES;
    if (!_isPlainObj(sys) || !recipes) return;
    if (sys.isReady) { showToast('محصول آماده است؛ نمی‌توان لغو کرد. ابتدا برداشت کنید.', 'error'); playSFX('error'); return; }
    if (sys.isCrafting && sys.item) {
      const recipe = recipes[sys.item];
      if (!recipe || !recipe.cost) {
        sys.isCrafting = false; sys.isReady = false; sys.item = null; sys.amount = 0; saveGame(); return;
      }
      const amount = Math.floor(_bNum(sys.amount, 0));
      try {
        transaction(() => {
          for (const res in recipe.cost) {
            if (_isBadKey(res)) continue;
            const refund = Math.floor(_bNum(recipe.cost[res], 0) * amount * 0.8);
            if (refund <= 0) continue;
            if (state[res] !== undefined) {
              state[res] = _bNum(state[res], 0) + refund;
            } else {
              if (!_isPlainObj(state.inventory)) state.inventory = {};
              state.inventory[res] = _bNum(state.inventory[res], 0) + refund;
            }
          }
          sys.isCrafting = false; sys.isReady = false; sys.item = null; sys.amount = 0;
        });
      } catch(e) { showToast('خطا در لغو!', 'error'); return; }
      updateUI(); saveGame();
      if (type === 'smith') updateSmithModalUI(); else updateLumberModalUI();
      showToast("ساخت لغو شد و ۸۰٪ منابع بازگشت."); playSFX('success');
    }
  } finally { releaseLock(); }
}

function speedUpCraft(type) {
  if (!acquireLock()) return;
  try {
    const sys = type === 'smith' ? state.smith : state.lumber;
    if (!_isPlainObj(sys) || !sys.isCrafting) return;
    if (typeof sys.endTime !== 'number' || !isFinite(sys.endTime) || sys.endTime <= 0) return;
    const cost = getSpeedupCost(sys.endTime);
    try {
      transaction(() => {
        if (cost > 0 && !spendGold(cost)) throw new Error('no gold');
        if (sys.endTime - Date.now() < 60000) { sys.endTime = Date.now(); }
        else { sys.endTime -= 60000; }
        if (sys.endTime <= Date.now()) { sys.isCrafting = false; sys.isReady = true; }
      });
    } catch(e) { showToast("طلا کافی نیست!", 'error'); playSFX('error'); return; }
    const doneNow = sys.isReady;
    updateUI(); saveGame();
    if (type === 'smith') updateSmithModalUI(); else updateLumberModalUI();
    showToast(doneNow ? `ساخت آماده شد (${toFa(cost)} طلا)! ⏩` : `۱ دقیقه از زمان ساخت کم شد (${toFa(cost)} طلا)! ⏩`);
    playSFX('success');
  } finally { releaseLock(); }
}

// ============================================================
// 🏛️ Smith Modal UI (✅ FIX 3: font-family:var(--font-persian))
// ============================================================
function updateSmithModalUI() {
  if (currentBuilding !== 'smith') return;
  const c = $('smith-dynamic-content'); if (!c) return;
  if (!_isPlainObj(state.smith)) return;
  if (state.smith.isCrafting) {
    const recipe = SMITH_RECIPES && SMITH_RECIPES[state.smith.item];
    if (!recipe) { state.smith.isCrafting = false; state.smith.isReady = false; state.smith.item = null; state.smith.amount = 0; saveGame(); return; }
    const now = Date.now();
    const dur = state.smith.endTime - state.smith.startTime;
    const pct = dur > 0 ? Math.min(100, Math.max(0, ((now - state.smith.startTime) / dur) * 100)) : 0;
    const left = Math.max(0, state.smith.endTime - now);
    const t = `${toFa(Math.floor(left/60000))}:${toFa(Math.floor((left%60000)/1000)).padStart(2,'۰')}`;
    if (c.dataset.mode !== 'crafting') {
      c.dataset.mode = 'crafting';
      // ✅ FIX: font-family عوض شد
      c.innerHTML = `<div class="smith-ui"><div id="sm-title" style="font-size:18px;color:var(--gold);font-family:var(--font-persian);"></div><div class="progress-container"><div class="progress-bar" id="sm-bar"></div><div class="progress-text" id="sm-text"></div></div><button class="btn-speedup" onclick="speedUpCraft('smith')">${timerIconHTML(16)} تسریع (طلا)</button><div class="speedup-row" id="sm-speedups"></div><button class="btn-cancel-craft" onclick="cancelCraft('smith')">لغو ساخت (بازگشت ۸۰٪)</button><button class="btn-action" disabled>لطفا صبر کنید...</button></div>`;
    }
    const suBtn = c.querySelector('.btn-speedup');
    if (suBtn) suBtn.innerHTML = `${timerIconHTML(16)} تسریع (${toFa(getSpeedupCost(state.smith.endTime))} طلا)`;
    const titleEl = $('sm-title'), barEl = $('sm-bar'), textEl = $('sm-text');
    if (titleEl) titleEl.textContent = `در حال ساخت: ${toFa(state.smith.amount)} عدد ${recipe.name}`;
    if (barEl) barEl.style.width = pct + '%';
    if (textEl) textEl.textContent = t + ' باقی مانده';
    renderSpeedupButtons('sm-speedups', 'smith');
  } else if (state.smith.isReady) {
    const recipe = SMITH_RECIPES && SMITH_RECIPES[state.smith.item];
    if (!recipe) { state.smith.isReady = false; state.smith.item = null; state.smith.amount = 0; saveGame(); return; }
    if (c.dataset.mode !== 'ready') {
      c.dataset.mode = 'ready';
      // ✅ FIX: font-family عوض شد
      c.innerHTML = `<div class="smith-ui"><div style="font-size:18px;color:#4caf50;font-family:var(--font-persian);">محصولات آماده برداشت هستند!</div><div style="font-size:14px;margin:10px 0;">${toFa(state.smith.amount)} عدد ${recipe.name}</div><button class="btn-action" style="background:linear-gradient(180deg,#4caf50,#2e7d32);color:white;" onclick="harvestCraft('smith')">برداشت محصولات ✅</button></div>`;
    }
  } else {
    if (c.dataset.mode !== 'other') {
      c.dataset.mode = 'other';
      // ✅ FIX: font-family عوض شد
      let html = `<div class="smith-ui"><div style="font-size:16px;color:var(--gold);font-family:var(--font-persian);margin-bottom:10px;">لیست ساخت آهنگری (سطح ${toFa(_bInt(state.buildings && state.buildings.smith, 1))}):</div><hr style="border-color:rgba(255,255,255,0.1);width:100%;">`;
      for (let key in SMITH_RECIPES) {
        const r = SMITH_RECIPES[key]; if (!r || !r.cost) continue;
        let costHtml = '';
        for (let res in r.cost) {
          const need = r.cost[res];
          const have = state[res] !== undefined ? _bNum(state[res], 0) : _bNum(state.inventory && state.inventory[res], 0);
          const iconRaw = (typeof RES_ICON !== 'undefined' && RES_ICON[res]) || '';
          const iconHtml = (typeof iconHTML === 'function') ? iconHTML(iconRaw, 18, '🎁') : iconRaw;
          costHtml += `<span style="color:${have >= need ? '#e5d5b2' : '#ff5252'};">${iconHtml} ${toFa(need)} ${(typeof resNames !== 'undefined' && resNames[res]) || res}</span> | `;
        }
        const cardIcon = (typeof iconHTML === 'function') ? iconHTML(r.icon, 24, '⚒️') : '⚒️';
        html += `<div class="craft-item"><div class="craft-info"><div class="craft-name" style="display:flex;align-items:center;gap:6px;">${cardIcon} ${r.name || key}</div><div class="craft-costs">هزینه: ${costHtml}</div><div class="craft-time">${timerIconHTML(12)} زمان: ${fmtDur(craftTime(r, 1, 'smith'))}</div></div><div style="display:flex; flex-direction:column; gap:5px;"><button class="btn-craft" onclick="openQuantityModal('${key}','smith')">ساخت</button><button class="btn-craft" style="background:#26363a; color:var(--gold); font-size:11px;" onclick="quickMaxCraft('${key}', 'smith')">⚡ حداکثر</button></div></div>`;
      }
      c.innerHTML = html + '</div>';
    }
  }
}

// ============================================================
// 🪚 Lumber Modal UI (✅ FIX 3: font-family:var(--font-persian))
// ============================================================
function updateLumberModalUI() {
  if (currentBuilding !== 'lumber') return;
  const prod = $('lumber-prod-ui');
  if (prod && _isPlainObj(state.lumberProd)) {
    const lvl = Math.max(1, _bInt(state.buildings && state.buildings.lumber, 1));
    const cap = 200 + (lvl - 1) * 400;
    const cur = _bNum(state.lumberProd.accumulatedWood, 0);
    if (!prod.dataset.built) {
      prod.dataset.built = '1';
      prod.innerHTML = `<div class="farm-ui"><div class="farm-stats"><div style="display:flex; align-items:center; gap:8px;"><img src="${_ICON.lumberIcon || 'ghost/kaman_ic.png'}" style="width:50px; height:50px; object-fit:cover; pointer-events:none; border-radius: 5px;" onerror="this.style.display='none';"> چوب تولیدی: <span id="lp-wood">0</span></div></div><div style="font-size:13px;text-align:center;margin-bottom:5px;">ظرفیت: <span id="lp-cap"></span></div><div class="progress-container"><div class="progress-bar" id="lp-bar"></div><div class="progress-text" id="lp-timer"></div></div><div id="lumberProd-buttons"></div></div>`;
    }
    renderProdButtons('lumberProd', cur >= cap - 0.5);
    const lpwEl = $('lp-wood'), lpcEl = $('lp-cap'), lpbEl = $('lp-bar'), lptEl = $('lp-timer');
    if (lpwEl) lpwEl.textContent = toFa(cur);
    if (lpcEl) lpcEl.textContent = `${toFa(cur)} از ${toFa(cap)}`;
    if (lpbEl) lpbEl.style.width = Math.min(100, (cur / cap) * 100) + '%';
    if (lptEl) {
      if (cur >= cap - 0.5) {
        lptEl.innerHTML = 'انبار پر شد!';
      } else if (state.lumberProd.isProducing) {
        const m = (cap - cur) / (8 * lvl);
        lptEl.innerHTML = `${timerIconHTML(14)} ${toFa(Math.floor(m))}:${toFa(Math.floor((m % 1) * 60)).padStart(2, '۰')} تا پر شدن`;
      } else {
        lptEl.innerHTML = 'متوقف';
      }
    }
  }
  const c = $('lumber-dynamic-content'); if (!c) return;
  if (!_isPlainObj(state.lumber)) return;
  if (state.lumber.isCrafting) {
    const recipe = LUMBER_RECIPES && LUMBER_RECIPES[state.lumber.item];
    if (!recipe) { state.lumber.isCrafting = false; state.lumber.isReady = false; state.lumber.item = null; state.lumber.amount = 0; saveGame(); return; }
    const now = Date.now();
    const dur = state.lumber.endTime - state.lumber.startTime;
    const pct = dur > 0 ? Math.min(100, Math.max(0, ((now - state.lumber.startTime) / dur) * 100)) : 0;
    const left = Math.max(0, state.lumber.endTime - now);
    const t = `${toFa(Math.floor(left/60000))}:${toFa(Math.floor((left%60000)/1000)).padStart(2,'۰')}`;
    if (c.dataset.mode !== 'crafting') {
      c.dataset.mode = 'crafting';
      // ✅ FIX: font-family عوض شد
      c.innerHTML = `<div class="lumber-ui"><div id="lm-title" style="font-size:18px;color:var(--gold);font-family:var(--font-persian);"></div><div class="progress-container"><div class="progress-bar" id="lm-bar"></div><div class="progress-text" id="lm-text"></div></div><button class="btn-speedup" onclick="speedUpCraft('lumber')">${timerIconHTML(16)} تسریع (طلا)</button><div class="speedup-row" id="lm-speedups"></div><button class="btn-cancel-craft" onclick="cancelCraft('lumber')">لغو ساخت (بازگشت ۸۰٪)</button><button class="btn-action" disabled>لطفا صبر کنید...</button></div>`;
    }
    const suBtn = c.querySelector('.btn-speedup');
    if (suBtn) suBtn.innerHTML = `${timerIconHTML(16)} تسریع (${toFa(getSpeedupCost(state.lumber.endTime))} طلا)`;
    const titleEl = $('lm-title'), barEl = $('lm-bar'), textEl = $('lm-text');
    if (titleEl) titleEl.textContent = `در حال ساخت: ${toFa(state.lumber.amount)} عدد ${recipe.name}`;
    if (barEl) barEl.style.width = pct + '%';
    if (textEl) textEl.textContent = t + ' باقی مانده';
    renderSpeedupButtons('lm-speedups', 'lumber');
  } else if (state.lumber.isReady) {
    const recipe = LUMBER_RECIPES && LUMBER_RECIPES[state.lumber.item];
    if (!recipe) { state.lumber.isReady = false; state.lumber.item = null; state.lumber.amount = 0; saveGame(); return; }
    if (c.dataset.mode !== 'ready') {
      c.dataset.mode = 'ready';
      // ✅ FIX: font-family عوض شد
      c.innerHTML = `<div class="lumber-ui"><div style="font-size:18px;color:#4caf50;font-family:var(--font-persian);">محصولات آماده برداشت هستند!</div><div style="font-size:14px;margin:10px 0;">${toFa(state.lumber.amount)} عدد ${recipe.name}</div><button class="btn-action" style="background:linear-gradient(180deg,#4caf50,#2e7d32);color:white;" onclick="harvestCraft('lumber')">برداشت محصولات ✅</button></div>`;
    }
  } else {
    if (c.dataset.mode !== 'other') {
      c.dataset.mode = 'other';
      // ✅ FIX: font-family عوض شد
      let html = `<div class="lumber-ui"><div style="font-size:16px;color:var(--gold);font-family:var(--font-persian);margin-bottom:10px;">لیست ساخت چوب‌بری (سطح ${toFa(_bInt(state.buildings && state.buildings.lumber, 1))}):</div><hr style="border-color:rgba(255,255,255,0.1);width:100%;">`;
      for (let key in LUMBER_RECIPES) {
        const r = LUMBER_RECIPES[key]; if (!r || !r.cost) continue;
        let costHtml = '';
        for (let res in r.cost) {
          const need = r.cost[res];
          const have = state[res] !== undefined ? _bNum(state[res], 0) : _bNum(state.inventory && state.inventory[res], 0);
          const iconRaw = (typeof RES_ICON !== 'undefined' && RES_ICON[res]) || '';
          const iconHtml = (typeof iconHTML === 'function') ? iconHTML(iconRaw, 18, '🎁') : iconRaw;
          costHtml += `<span style="color:${have >= need ? '#e5d5b2' : '#ff5252'};">${iconHtml} ${toFa(need)} ${(typeof resNames !== 'undefined' && resNames[res]) || res}</span> | `;
        }
        const cardIcon = (typeof iconHTML === 'function') ? iconHTML(r.icon, 24, '🪵') : '🪵';
        html += `<div class="craft-item"><div class="craft-info"><div class="craft-name" style="display:flex;align-items:center;gap:6px;">${cardIcon} ${r.name || key}</div><div class="craft-costs">هزینه: ${costHtml}</div><div class="craft-time">${timerIconHTML(12)} زمان: ${fmtDur(craftTime(r, 1, 'lumber'))}</div></div><div style="display:flex; flex-direction:column; gap:5px;"><button class="btn-craft" onclick="openQuantityModal('${key}','lumber')">ساخت</button><button class="btn-craft" style="background:#26363a; color:var(--gold); font-size:11px;" onclick="quickMaxCraft('${key}', 'lumber')">⚡ حداکثر</button></div></div>`;
      }
      c.innerHTML = html + '</div>';
    }
  }
}

// ============================================================
// ⬆️ Upgrade System
// ============================================================
function renderUpgradeSection(type) {
  const box = $('upgrade-dynamic'); if (!box) return;
  if (typeof BUILDINGS_INFO === 'undefined' || !BUILDINGS_INFO[type]) return;
  const up = state.upgrade, lvl = Math.max(1, _bInt(state.buildings && state.buildings[type], 1));
  if (up && up.type === type) {
    const left = Math.max(0, _bNum(up.endTime, 0) - Date.now());
    if (box.dataset.key !== 'prog') {
      box.dataset.key = 'prog';
      box.innerHTML = `<div class="upgrade-section"><div class="level-text">در حال ارتقا به سطح ${toFa(lvl + 1)}</div><div class="progress-container"><div class="progress-bar" id="up-bar"></div><div class="progress-text" id="up-text"></div></div><button class="btn-speedup" onclick="speedUpUpgrade()">${timerIconHTML(16)} تسریع (طلا)</button><div class="speedup-row" id="up-speedups"></div></div>`;
    }
    const cost = getSpeedupCost(up.endTime);
    const suBtn = box.querySelector('.btn-speedup');
    if (suBtn) suBtn.innerHTML = `${timerIconHTML(16)} تسریع (${toFa(cost)} طلا)`;
    const barEl = $('up-bar'), textEl = $('up-text');
    const dur = up.endTime - up.startTime;
    if (barEl) barEl.style.width = Math.min(100, dur > 0 ? (1 - left / dur) * 100 : 0) + '%';
    if (textEl) textEl.textContent = fmtDur(left);
    renderSpeedupButtons('up-speedups', 'upgrade');
    return;
  }
  const cost = getUpgradeCost(type, lvl);
  const ok = _bNum(state.gold, 0) >= cost.gold && _bNum(state.wood, 0) >= cost.wood && _bNum(state.stone, 0) >= cost.stone && _bNum(state.iron, 0) >= cost.iron;
  let reason = '';
  if (lvl >= 30) reason = 'سطح حداکثر است (۳۰)';
  else if (up) reason = 'صف ارتقا مشغول است';
  else if (type !== 'castle' && lvl >= _bInt(state.buildings && state.buildings.castle, 1)) reason = 'ابتدا قلعه را ارتقا بده 🏰';
  else if (!ok) reason = 'منابع کافی نیست';
  const key = lvl + '|' + reason;
  if (box.dataset.key === key) return;
  box.dataset.key = key;
  box.innerHTML = `<div class="upgrade-section"><div class="level-text">سطح فعلی: ${toFa(lvl)}</div><div class="cost-box"><div class="cost-item">${iconHTML(_ICON.gold, 14, '🪙')} ${toFa(cost.gold)}</div>${cost.wood > 0 ? `<div class="cost-item">${iconHTML(_ICON.wood, 14, '🪵')} ${toFa(cost.wood)}</div>` : ''}${cost.stone > 0 ? `<div class="cost-item">${iconHTML(_ICON.stone, 14, '🪨')} ${toFa(cost.stone)}</div>` : ''}${cost.iron > 0 ? `<div class="cost-item">${iconHTML(_ICON.iron, 14, '⛓️')} ${toFa(cost.iron)}</div>` : ''}<div class="cost-item">${timerIconHTML(14)} ${fmtDur(getUpgradeTime(lvl))}</div></div><button class="btn-upgrade" onclick="upgradeBuilding('${type}')" ${reason ? 'disabled' : ''}>${reason || 'ارتقای ساختمان ⬆️'}</button></div>`;
}

function upgradeBuilding(type) {
  if (!acquireLock()) return;
  try {
    if (typeof BUILDINGS_INFO === 'undefined' || !BUILDINGS_INFO[type]) {
      showToast('ساختمان نامعتبر! ❌', 'error'); playSFX('error'); return;
    }
    if (state.upgrade) { showToast('صف ارتقا مشغول است!', 'error'); playSFX('error'); return; }
    const lvl = Math.max(1, _bInt(state.buildings && state.buildings[type], 1));
    if (lvl >= 30) { showToast('این ساختمان به حداکثر سطح رسیده است!', 'error'); playSFX('error'); return; }
    if (type !== 'castle' && lvl >= _bInt(state.buildings && state.buildings.castle, 1)) {
      showToast('ابتدا قلعه را ارتقا بده! 🏰', 'error'); playSFX('error'); return;
    }
    const c = getUpgradeCost(type, lvl);
    try {
      transaction(() => {
        if (!deductResources(c)) throw new Error('insufficient');
        const now = Date.now();
        state.upgrade = { type, startTime: now, endTime: now + getUpgradeTime(lvl) };
      });
    } catch(e) { showToast('منابع کافی نیست! ❌', 'error'); playSFX('error'); return; }
    updateUI(); saveGame(); renderUpgradeSection(type);
    showToast('ارتقا شروع شد! 🔨');
    playSFX('success'); playSoundFile('ghost/dropping-single-coin.mp3', 0.6);
  } finally { releaseLock(); }
}

function finishUpgrade() {
  const up = state.upgrade; if (!up) return;
  if (typeof BUILDINGS_INFO === 'undefined' || !BUILDINGS_INFO[up.type]) {
    state.upgrade = null; saveGame(); return;
  }
  const newLevel = Math.max(1, _bInt(state.buildings && state.buildings[up.type], 1)) + 1;
  try {
    transaction(() => {
      state.buildings[up.type] = newLevel;
      state.upgrade = null;
      if (up.type === 'academy') {
        if (!_isPlainObj(state.inventory)) state.inventory = {};
        state.inventory.magicBook = _bNum(state.inventory.magicBook, 0) + 1;
      }
    });
  } catch(e) {
    console.error('finishUpgrade transaction failed:', e);
    state.upgrade = null; saveGame(); return;
  }
  if (up.type === 'academy') showToast('📖 یک کتاب جادویی از معبد دریافت کردی!');
  const upgradeXp = 15 + newLevel;
  try { addXP(upgradeXp); } catch (e) {}
  try { if (typeof missionAdd === 'function') { missionAdd('upgrade1'); missionAdd('upgrade10'); } if (typeof updateSpecialOfferProgress === 'function') updateSpecialOfferProgress('upgrade'); } catch (e) {}
  
  // ✅ آپدیت ماموریت‌های زنده
  try { if (typeof updateLiveTaskProgress === 'function') updateLiveTaskProgress('upgrade'); } catch (e) {}

  updateUI(); saveGame();
  showToast(`${BUILDINGS_INFO[up.type].name} به سطح ${toFa(newLevel)} رسید! ✨ (+${toFa(upgradeXp)} XP)`);
  if (typeof playSFX === 'function') playSFX('success');
  if (typeof addMessage === 'function') {
    addMessage('upgrade', '🔨', `ارتقای ${BUILDINGS_INFO[up.type].name}`,
      `${BUILDINGS_INFO[up.type].name} به سطح ${toFa(newLevel)} رسید. (+${toFa(upgradeXp)} XP)`);
  }
  if (typeof addWatchtowerAlert === 'function') {
    addWatchtowerAlert('upgrade', '🔨', `ارتقای ${BUILDINGS_INFO[up.type].name}`,
      `${BUILDINGS_INFO[up.type].name} به سطح ${toFa(newLevel)} رسید.`,
      `upgrade_${up.type}_${newLevel}`);
  }
  if (currentBuilding === up.type) {
    try {
      const img = document.querySelector(`.building[data-type="${up.type}"]`);
      const mb = document.querySelector('.modal-body'), keepTop = mb ? mb.scrollTop : 0;
      showModalContent(up.type, img ? img.getAttribute('src') : null);
      if (mb) mb.scrollTop = keepTop;
    } catch (e) {}
  }
}

function speedUpUpgrade() {
  if (!acquireLock()) return;
  try {
    const up = state.upgrade; if (!up) return;
    if (typeof up.endTime !== 'number' || !isFinite(up.endTime) || up.endTime <= 0) return;
    const cost = getSpeedupCost(up.endTime);
    try {
      transaction(() => {
        if (cost > 0 && !spendGold(cost)) throw new Error('no gold');
        if (up.endTime - Date.now() < 60000) { up.endTime = Date.now(); }
        else { up.endTime -= 60000; }
      });
    } catch(e) { showToast('طلا کافی نیست!', 'error'); playSFX('error'); return; }
    if (up.endTime <= Date.now()) finishUpgrade();
    else { updateUI(); saveGame(); renderUpgradeSection(up.type); }
    playSFX('success');
  } finally { releaseLock(); }
}

// ============================================================
// 💰 Castle Tax
// ============================================================
function tickCastleTax(now) {
  if (!_isPlainObj(state.castle)) state.castle = { accumulatedGold: 0, lastTickTime: 0, lastCollectTime: 0 };
  if (!isFinite(now)) now = Date.now();
  if (!state.castle.lastTickTime) state.castle.lastTickTime = now;
  if (state.castle.lastTickTime > now) { state.castle.lastTickTime = now; return; }
  const lvl = Math.max(1, _bInt(state.buildings && state.buildings.castle, 1));
  const buffs = (typeof getAcademyBuffs === 'function') ? getAcademyBuffs() : { goldProd: 1 };
  const ratePerMin = getCastleRatePerMin();
  if (!isFinite(ratePerMin) || ratePerMin <= 0) return;
  const cap = ratePerMin * TAX_CAP_MINUTES;
  const mins = (now - state.castle.lastTickTime) / 60000;
  if (!isFinite(mins) || mins <= 0) { state.castle.lastTickTime = now; return; }
  state.castle.lastTickTime = now;
  if (_bNum(state.castle.accumulatedGold, 0) < cap) {
    state.castle.accumulatedGold = Math.min(cap, _bNum(state.castle.accumulatedGold, 0) + ratePerMin * mins);
  }
}

function collectTaxNow() {
  if (!acquireLock()) return;
  try {
    const now = Date.now();
    if (!_isPlainObj(state.castle)) state.castle = { accumulatedGold: 0, lastTickTime: 0, lastCollectTime: 0 };
    if (now - _bNum(state.castle.lastCollectTime, 0) < TAX_COOLDOWN_MS) {
      showToast('برای جمع‌آوری دوباره کمی صبر کن! ⏳', 'error'); playSFX('error'); return;
    }
    tickCastleTax(now);
    const amt = Math.floor(_bNum(state.castle.accumulatedGold, 0));
    if (!isFinite(amt) || amt <= 0) {
      showToast('هنوز مالیاتی جمع نشده است! ⏳', 'error'); playSFX('error'); return;
    }
    try {
      transaction(() => {
        state.gold = _bNum(state.gold, 0) + amt;
        state.castle.accumulatedGold = Math.max(0, _bNum(state.castle.accumulatedGold, 0) - amt);
        state.castle.lastCollectTime = now;
        state.castle.lastTickTime = now;
      });
    } catch(e) { return; }
    if (typeof missionAdd === 'function') {
      missionAdd('collectTax2', 1);
      missionAdd('tax50', 1);
      missionAdd('collect10000', amt);
    }
    if (typeof updateLiveTaskProgress === 'function') updateLiveTaskProgress('tax');
    
    updateUI(); saveGame();
    if (currentBuilding === 'castle') updateCastleUI();
    showToast(`💰 ${toFa(amt)} طلا جمع‌آوری شد!`);
    playSFX('success'); playSoundFile('ghost/Collect.mp3', 0.6);
  } finally { releaseLock(); }
}

// ============================================================
// ⏱️ Speedup System
// ============================================================
function renderSpeedupButtons(boxId, target) {
  const box = $(boxId); if (!box) return;
  if (typeof SPEEDUP_ITEMS === 'undefined' || !SPEEDUP_ITEMS) return;
  const inv = _isPlainObj(state.inventory) ? state.inventory : {};
  let totalItems = 0;
  for (const k in SPEEDUP_ITEMS) totalItems += _bInt(inv[k], 0);
  const safeTarget = String(target).replace(/'/g, '');
  const newHTML = `${timerIconHTML(16)} استفاده از آیتم تسریع (موجودی: ${toFa(totalItems)})`;
  const existingBtn = box.querySelector('.btn-speedup-trigger');
  if (existingBtn && box.dataset.target === safeTarget) {
    if (existingBtn.innerHTML !== newHTML) existingBtn.innerHTML = newHTML;
    return;
  }
  box.dataset.target = safeTarget;
  box.innerHTML = `<button class="btn-speedup-trigger" onclick="openSpeedupModal('${safeTarget}')">${newHTML}</button>`;
}

function openSpeedupModal(target) {
  currentSpeedupTarget = target;
  const list = $('speedup-modal-list'); const modal = $('speedupModal');
  if (!list || !modal) { showToast('سیستم تسریع در دسترس نیست ❌', 'error'); return; }
  if (typeof SPEEDUP_ITEMS === 'undefined' || !SPEEDUP_ITEMS) return;
  const inv = _isPlainObj(state.inventory) ? state.inventory : {};
  let html = ''; let hasAny = false;
  for (const k in SPEEDUP_ITEMS) {
    if (_isBadKey(k)) continue;
    const count = _bInt(inv[k], 0);
    const info = SPEEDUP_ITEMS[k];
    if (!info) continue;
    const isDis = count <= 0;
    if (!isDis) hasAny = true;
    const safeTarget = String(target).replace(/'/g, '');
    const safeKey = String(k).replace(/'/g, '');
    const iconHtml = (typeof iconHTML === 'function') ? iconHTML(info.icon, 18, '⏱️') : (info.icon || '⏱️');
    html += `<div class="speedup-card ${isDis ? 'disabled' : ''}" ${isDis ? '' : `onclick="useSpeedup('${safeTarget}','${safeKey}')"`}><div class="s-name">${iconHtml} ${info.name || k}</div><div class="s-count">${toFa(count)} عدد</div></div>`;
  }
  if (!hasAny) html = `<div style="text-align:center; color:#aaa; font-size:13px; padding:10px;">شما هیچ آیتم تسریعی ندارید. از فروشگاه بخرید! 🛒</div>`;
  list.innerHTML = html; modal.style.display = 'flex'; playSFX('click');
}

function closeSpeedupModal() {
  const m = $('speedupModal'); if (m) m.style.display = 'none';
  currentSpeedupTarget = null;
}

function useSpeedup(target, itemKey) {
  if (!acquireLock()) return;
  try {
    if (target !== 'upgrade' && target !== 'smith' && target !== 'lumber' && target !== 'barracks' && target !== 'academy') {
      showToast('هدف تسریع نامعتبر! ❌', 'error'); playSFX('error'); return;
    }
    if (_isBadKey(itemKey)) { showToast('آیتم نامعتبر! ❌', 'error'); playSFX('error'); return; }
    if (typeof SPEEDUP_ITEMS === 'undefined' || !SPEEDUP_ITEMS) return;
    const info = SPEEDUP_ITEMS[itemKey];
    if (!info || typeof info.ms !== 'number' || !isFinite(info.ms) || info.ms <= 0) { showToast('آیتم نامعتبر! ❌', 'error'); playSFX('error'); return; }
    if (!_isPlainObj(state.inventory) || _bInt(state.inventory[itemKey], 0) <= 0) { showToast('این آیتم رو نداری! ❌', 'error'); playSFX('error'); return; }
    const active = target === 'upgrade' ? !!state.upgrade :
      (target === 'smith' ? (state.smith && state.smith.isCrafting) :
      (target === 'lumber' ? (state.lumber && state.lumber.isCrafting) :
      (target === 'barracks' ? (state.barracksTraining && state.barracksTraining.unit) :
      (target === 'academy' ? (state.academyResearch && state.academyResearch.activeResearch && state.academyResearch.activeResearch.branch) : false))));
    if (!active) { showToast('چیزی در حال ساخت/ارتقا نیست! ❌', 'error'); playSFX('error'); return; }
    let _doFinishTraining = false, _doFinishUpgrade = false, _doFinishResearch = false;
    try {
      transaction(() => {
        state.inventory[itemKey] = Math.max(0, _bInt(state.inventory[itemKey], 0) - 1);
        if (target === 'upgrade') {
          state.upgrade.endTime = Math.max(Date.now(), state.upgrade.endTime - info.ms);
          if (state.upgrade.endTime <= Date.now()) _doFinishUpgrade = true;
        } else if (target === 'smith') {
          state.smith.endTime = Math.max(Date.now(), state.smith.endTime - info.ms);
          if (state.smith.endTime <= Date.now()) { state.smith.isCrafting = false; state.smith.isReady = true; }
        } else if (target === 'lumber') {
          state.lumber.endTime = Math.max(Date.now(), state.lumber.endTime - info.ms);
          if (state.lumber.endTime <= Date.now()) { state.lumber.isCrafting = false; state.lumber.isReady = true; }
        } else if (target === 'barracks') {
          if (!_isPlainObj(state.barracksTraining) || !state.barracksTraining.unit) throw new Error('no_training');
          const _btEnd = _bNum(state.barracksTraining.endTime, 0);
          if (_btEnd <= 0) throw new Error('no_training');
          if (_btEnd - info.ms <= Date.now()) { state.barracksTraining.endTime = Date.now(); _doFinishTraining = true; }
          else { state.barracksTraining.endTime = _btEnd - info.ms; }
        } else if (target === 'academy') {
          const ar = state.academyResearch.activeResearch;
          if (!ar || !ar.branch || _bNum(ar.endTime, 0) <= 0) throw new Error('no_research');
          if (ar.endTime - info.ms <= Date.now()) { ar.endTime = Date.now(); _doFinishResearch = true; }
          else { ar.endTime -= info.ms; }
        }
      });
    } catch (e) {
      _doFinishTraining = false; _doFinishUpgrade = false; _doFinishResearch = false;
      return;
    }
    if (_doFinishUpgrade && typeof finishUpgrade === 'function') finishUpgrade();
    if (_doFinishTraining && typeof finishTraining === 'function') finishTraining();
    if (_doFinishResearch && typeof finishResearch === 'function') finishResearch();
    if (target === 'upgrade' && state.upgrade) renderUpgradeSection(state.upgrade.type);
    else if (target === 'smith') updateSmithModalUI();
    else if (target === 'lumber') updateLumberModalUI();
    else if (target === 'barracks') updateBarracksUI();
    else if (target === 'academy') updateAcademyUI();
    updateUI(); saveGame(); closeSpeedupModal();
    showToast(`${info.name} استفاده شد! ⏩`); playSFX('success');
  } finally { releaseLock(); }
}

// ============================================================
// 🏛️ Building Modal
// ============================================================
function openBuildingModal(type, src) {
  if (isProcessing || isLoadingScreenActive) return;
  document.querySelectorAll('.nav button').forEach(b => b.classList.remove('active'));
  if (typeof BUILDINGS_INFO === 'undefined' || !BUILDINGS_INFO[type]) { showToast('ساختمان نامعتبر! ❌', 'error'); return; }
  currentBuilding = type;
  const info = BUILDINGS_INFO[type];
  const ls = $('loadingScreen');
  if (ls) {
    if (info.bg) { ls.style.backgroundImage = `url('ghost/${info.bg}')`; }
    else { ls.style.backgroundColor = '#0a1014'; ls.style.backgroundImage = 'none'; }
  }
  const lb = $('loadingBar');
  if (lb) { lb.style.animation = 'none'; lb.offsetHeight; lb.style.animation = 'fillBar 0.8s ease-in-out forwards'; }
  isLoadingScreenActive = true;
  if (ls) ls.classList.add('show');
  setTimeout(() => {
    if (ls) ls.classList.remove('show');
    isLoadingScreenActive = false;
    showModalContent(type, src);
  }, 800);
}

function closeGameModal() {
  if (typeof clearBattleTimer === 'function') clearBattleTimer();
  if (typeof closeVsScreen === 'function') closeVsScreen();
  if (typeof closeResultScreen === 'function') closeResultScreen();
  const epic = document.getElementById('epicReportOverlay'); if (epic) epic.remove();
  const gm = $('gameModal');
  if (gm) { gm.classList.remove('show'); gm.style.backgroundImage = ''; }
  currentBuilding = null;
  if (typeof releaseLock === 'function') releaseLock();
  try { saveGame(); } catch (e) {}
}

// ============================================================
// 🏛️ Barracks Section Builder
// ============================================================
function _buildBarracksSection() {
  if (typeof UNITS_INFO === 'undefined' || !UNITS_INFO) {
    return '<div style="color:#ff5252;text-align:center;padding:10px;">⚠️ خطا در بارگذاری اطلاعات واحدها.</div>';
  }
  const bLvl = _bInt(state.buildings && state.buildings.barracks, 1);
  const maxArmy = (typeof getMaxArmy === 'function') ? getMaxArmy(bLvl) : 9999;
  const curArmy = (typeof getTotalArmyCount === 'function') ? getTotalArmyCount() : 0;
  const isTraining = _isPlainObj(state.barracksTraining) && !!state.barracksTraining.unit;
  let html = `<div id="barracks-training-content"></div>`;
  html += `<div class="recruit-section" style="text-align:center;">
    <div style="color:var(--gold); font-size:13px; margin-bottom:10px;">ظرفیت ارتش: ${toFa(curArmy)} / ${toFa(maxArmy)}</div>
    <hr style="border-color:rgba(255,255,255,0.1);width:100%;margin:10px 0;">
    <p style="color:var(--gold);font-family:var(--font-persian);font-size:18px;margin:0 0 10px 0;">آموزش نیرو</p>`;
  for (let key in UNITS_INFO) {
    if (_isBadKey(key)) continue;
    const u = UNITS_INFO[key];
    if (!u || !u.cost) continue;
    const count = _bInt(state.army && state.army[key], 0);
    const reqLvl = _bInt(u.reqBarracksLevel, 1);
    const locked = bLvl < reqLvl;
    const isCurrentTraining = isTraining && state.barracksTraining.unit === key;
    let cAfford = true;
    const _safeInv = _isPlainObj(state.inventory) ? state.inventory : {};
    for (let res in u.cost) {
      if (_isBadKey(res)) continue;
      const av = state[res] !== undefined ? _bNum(state[res], 0) : _bNum(_safeInv[res], 0);
      if (av < _bNum(u.cost[res], 0)) { cAfford = false; break; }
    }
    let costHtml = '';
    for (let res in u.cost) {
      if (_isBadKey(res)) continue;
      const iconRaw = (typeof RES_ICON !== 'undefined' && RES_ICON[res]) || '';
      const iconHtml = (typeof iconHTML === 'function') ? iconHTML(iconRaw, 18, '🎁') : iconRaw;
      costHtml += `${iconHtml} ${toFa(u.cost[res])} ${(typeof resNames !== 'undefined' && resNames[res]) || res} `;
    }
    const unitPower = (typeof getUnitPower === 'function') ? getUnitPower(key, bLvl) : _bNum(u.power, 0);
    const trainTime = (typeof getTrainTime === 'function') ? getTrainTime(key, bLvl) : _bInt(u.trainTime, 10000);
    const trainTimeStr = (typeof fmtDur === 'function') ? fmtDur(trainTime) : `${toFa(Math.floor(trainTime/1000))} ثانیه`;
    let btnLabel = 'آموزش';
    let extraCls = '';
    let isDisabled = false;
    if (locked) { btnLabel = `🔒 سطح ${toFa(reqLvl)}`; extraCls = 'level-locked'; isDisabled = true; }
    else if (isCurrentTraining) { btnLabel = '⏳ در حال آموزش'; extraCls = 'training-locked training-current'; isDisabled = true; }
    else if (isTraining) { btnLabel = '⏸️ صف پر'; extraCls = 'training-locked'; isDisabled = true; }
    else if (curArmy >= maxArmy) { btnLabel = 'ظرفیت پر'; extraCls = 'training-locked'; isDisabled = true; }
    else if (!cAfford) { btnLabel = 'منابع کم'; extraCls = 'training-locked'; isDisabled = true; }
    html += `<div class="unit-card ${extraCls}">
      <img src="${u.img || 'ghost/castle.png'}" class="unit-img" onerror="this.onerror=null;this.src='ghost/castle.png'" alt="${escapeHtml(u.name || key)}">
      <div class="unit-info">
        <div class="unit-name">${escapeHtml(u.name || key)} (${toFa(count)} عدد)</div>
        <div class="unit-stats">قدرت: <b style="color:#4caf50">${toFa(unitPower)}</b> | ${timerIconHTML(12)} ${trainTimeStr}</div>
        <div class="unit-cost">${costHtml}</div>
      </div>
      <button class="btn-recruit" data-unit-key="${escapeHtml(key)}" type="button" ${isDisabled ? 'disabled' : ''}>${btnLabel}</button>
    </div>`;
  }
  html += `</div>`;
  return html;
}

// ============================================================
// 🏛️ Show Modal Content
// ============================================================
function showModalContent(type, src) {
  if (type === 'battle') { openBattleModal(); return; }
  if (typeof BUILDINGS_INFO === 'undefined' || !BUILDINGS_INFO[type]) { showToast('ساختمان نامعتبر! ❌', 'error'); return; }
  const info = BUILDINGS_INFO[type];
  const lvl = Math.max(1, _bInt(state.buildings && state.buildings[type], 1));
  const gm = $('gameModal');
  if (gm) {
    if (info.bg) { gm.style.backgroundImage = `url('ghost/${info.bg}')`; gm.style.backgroundSize = 'cover'; gm.style.backgroundPosition = 'center'; }
    else { gm.style.backgroundImage = 'radial-gradient(circle at 50% 10%, #1a2930, #0a1014 90%)'; }
  }
  const mt = $('modal-title'); if (mt) mt.textContent = info.name;
  const mi = $('modal-img'), mIcon = $('modal-icon');
  if (src && mi) { mi.src = src; mi.style.display = 'block'; if (mIcon) mIcon.style.display = 'none'; }
  else { if (mi) mi.style.display = 'none'; if (mIcon) mIcon.style.display = 'block'; }
  let htmlContent = `<div id="upgrade-dynamic"></div>`;
  if (type === 'farm') {
    htmlContent += `<div class="farm-ui"><div class="farm-stats" style="background:rgba(0,0,0,0.4); padding:10px; border-radius:10px; border:1px solid rgba(255,255,255,0.1);"><div style="display:flex; align-items:center; gap:5px;">${iconHTML(_ICON.azooghe, 18, '🌾')} آذوغه: <span id="farm-az" style="color:#fff; font-weight:bold;">0</span></div><div style="display:flex; align-items:center; gap:5px;">${iconHTML(_ICON.wood, 18, '🪵')} چوب: <span id="farm-wd" style="color:#fff; font-weight:bold;">0</span></div></div><div style="font-size:12px; color:#8bc34a; text-align:center; margin-top:-5px;">تولید خودکار: +${toFa(4 * lvl)} آذوغه و +${toFa(2 * lvl)} چوب در دقیقه</div><div style="font-size:13px;text-align:center;margin-top:10px;">ظرفیت انبار: <span id="farm-cap-text" style="color:var(--gold); font-weight:bold;">0 از 0</span></div><div class="progress-container"><div class="progress-bar" id="farm-progress-bar" style="width:0%;"></div><div class="progress-text" id="farm-timer-text" style="font-weight:bold;">متوقف</div></div><div id="farm-buttons"></div></div>`;
  }
  if (type === 'mine') {
    htmlContent += `<div class="farm-ui"><div class="farm-stats"><div style="display:flex;align-items:center;gap:4px;">${iconHTML(_ICON.stone, 18, '🪨')} سنگ: <span id="mine-st">0</span></div><div style="display:flex;align-items:center;gap:4px;">${iconHTML(_ICON.coal, 18, '⚫')} زغال: <span id="mine-co">0</span></div><div style="display:flex;align-items:center;gap:4px;">${iconHTML(_ICON.diamond, 18, '💎')} الماس: <span id="mine-di">0</span></div></div><div style="font-size:11px;color:#8bc34a;text-align:center;margin:4px 0;">نرخ تولید الماس: ${_fmtRate(0.1 * lvl)} در دقیقه</div><div style="font-size:13px;text-align:center;margin-bottom:5px;">ظرفیت: <span id="mine-cap-text">0 از 0</span></div><div class="progress-container"><div class="progress-bar" id="mine-progress-bar" style="width:0%;"></div><div class="progress-text" id="mine-timer-text">متوقف</div></div><div id="mine-buttons"></div></div>`;
  }
  if (type === 'castle') htmlContent += `<div id="castle-dynamic-content"></div>`;
  if (type === 'academy') {
    if (_isPlainObj(state.academyResearch)) {
      const res = state.academyResearch;
      const ar = _isPlainObj(res.activeResearch) ? res.activeResearch : { branch: null, startTime: 0, endTime: 0, targetLevel: 0 };
      const books = _bInt(state.inventory && state.inventory.magicBook, 0);
      const isResearching = ar.branch !== null && _bNum(ar.endTime, 0) > Date.now();
      const renderBranch = (key, name, iconPath) => {
        const val = _bInt(res[key], 0);
        const iconHtml = (typeof iconHTML === 'function') ? iconHTML(iconPath, 22, '⚔️') : '';
        const bookIcon = (typeof iconHTML === 'function') ? iconHTML(_ICON.magicBook, 14, '📖') : '📖';
        const nextLvl = val + 1;
        const booksNeeded = (typeof ACADEMY_RESEARCH_COST !== 'undefined' && ACADEMY_RESEARCH_COST[nextLvl]) || 1;
        const researchTime = (typeof ACADEMY_RESEARCH_TIMES !== 'undefined' && ACADEMY_RESEARCH_TIMES[nextLvl]) || 0;
        let dots = '';
        for (let i = 0; i < 10; i++) {
          dots += `<div style="width:12px; height:12px; border-radius:50%; background:${i < val ? 'var(--gold)' : 'rgba(255,255,255,0.1)'}; border:1px solid rgba(255,255,255,0.2);"></div>`;
        }
        let btnHtml = '';
        if (val >= 10) {
          btnHtml = `<button class="btn-craft" style="width:100%; font-size:12px;" disabled>تکمیل شده ✅</button>`;
        } else if (isResearching && ar.branch === key) {
          btnHtml = `<button class="btn-craft" style="width:100%; font-size:12px;" disabled>⏳ در حال تحقیق...</button>`;
        } else if (isResearching) {
          btnHtml = `<button class="btn-craft" style="width:100%; font-size:12px;" disabled>🔒 صف تحقیق مشغول</button>`;
        } else if (books < booksNeeded) {
          btnHtml = `<button class="btn-craft" style="width:100%; font-size:12px;" disabled>نیاز به ${toFa(booksNeeded)} ${bookIcon}</button>`;
        } else {
          btnHtml = `<button class="btn-craft" style="width:100%; font-size:12px;" onclick="researchAcademy('${key}')">تحقیق (${toFa(booksNeeded)} ${bookIcon}) — ${fmtDur(researchTime)}</button>`;
        }
        return `<div style="background:rgba(0,0,0,0.4); padding:12px; border-radius:10px; margin-bottom:10px; border:1px solid rgba(255,255,255,0.1);">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
            <div style="font-family:var(--font-persian); color:var(--gold); font-size:16px; display:flex; align-items:center; gap:6px;">${iconHtml} ${name}</div>
            <div style="font-size:12px; color:#8bc34a;">+${toFa(val * 2)}٪</div>
          </div>
          <div style="display:flex; gap:4px; flex-wrap:wrap; margin-bottom:10px;">${dots}</div>
          ${btnHtml}
        </div>`;
      };
      let researchProgressHtml = '';
      if (isResearching) {
        const now = Date.now();
        const dur = _bNum(ar.endTime, 0) - _bNum(ar.startTime, 0);
        const pct = dur > 0 ? Math.min(100, Math.max(0, ((now - _bNum(ar.startTime, 0)) / dur) * 100)) : 0;
        const left = Math.max(0, _bNum(ar.endTime, 0) - now);
        const branchName = ar.branch === 'power' ? 'شمشیرزنی' : ar.branch === 'gold' ? 'مالیات‌گیری' : 'معماری دفاعی';
        const cost = getSpeedupCost(ar.endTime);
        researchProgressHtml = `<div class="farm-ui" style="border-color:#a855f7; margin-bottom:12px;">
          <div class="level-text" style="color:#a855f7;">🔬 تحقیق در حال انجام: ${branchName} → سطح ${toFa(ar.targetLevel)}</div>
          <div class="progress-container">
            <div class="progress-bar" id="academy-research-bar" style="width:${pct}%; background:linear-gradient(90deg,#a855f7,#ec4899);"></div>
            <div class="progress-text" id="academy-research-text">${fmtDur(left)}</div>
          </div>
          <button class="btn-speedup" onclick="speedUpResearch()">${timerIconHTML(16)} تسریع (${toFa(cost)} طلا)</button>
          <div class="speedup-row" id="academy-speedups"></div>
        </div>`;
      }
      htmlContent += `<div class="farm-ui">
        <div class="level-text">📚 معبد دانش (سطح ${toFa(lvl)})</div>
        <div style="font-size:13px; color:#ccc; margin-bottom:10px;">با هر ارتقای معبد، ۱ کتاب جادویی دریافت می‌کنی. تحقیقات زمان‌بر هستند.</div>
        <div style="font-size:13px; color:#f5c66b; margin-bottom:10px;">${iconHTML(_ICON.magicBook, 16, '📖')} کتاب‌های جادویی: <b>${toFa(books)}</b></div>
        ${researchProgressHtml}
        ${renderBranch('power', 'شمشیرزنی', _ICON.steel)}
        ${renderBranch('gold', 'مالیات‌گیری', _ICON.gold)}
        ${renderBranch('defense', 'معماری دفاعی', _ICON.wall)}
      </div>`;
    }
  }
  if (type === 'wall') {
    const dp = (typeof getDefensePower === 'function') ? getDefensePower() : 0;
    htmlContent += `<div class="farm-ui"><div class="level-text">🧱 دیوار دفاعی (سطح ${toFa(lvl)})</div><div style="font-size:13px;color:#eee;">🛡️ قدرت دفاعی فعلی قلعه: <b style="color:#4caf50;">${toFa(dp)}</b></div><div style="font-size:13px;color:#ccc;">دیوار از قلعه در برابر حملات آینده دفاع می‌کند و با هر ارتقا قدرت دفاعی را به‌شدت افزایش می‌دهد.</div></div>`;
  }
  if (type === 'hospital') {
    const healRate = Math.min(80, 10 + (lvl - 1) * 2);
    htmlContent += `<div class="farm-ui"><div class="level-text">🏥 بیمارستان سلطنتی</div><div style="font-size:15px; color:#4caf50; margin:10px 0; font-weight:bold;">نرخ نجات سربازان: ${toFa(healRate)}٪</div><div style="font-size:13px; color:#ccc; line-height:1.6;">پزشکان این بیمارستان، سربازان زخمی را درمان می‌کنند. هر سطح بیمارستان ۲٪ به نرخ نجات اضافه می‌کند.</div></div><div id="hospital-dynamic-content"></div>`;
  }
  if (type === 'smith') htmlContent += `<div id="smith-dynamic-content"></div>`;
  if (type === 'lumber') htmlContent += `<div id="lumber-prod-ui"></div><div id="lumber-dynamic-content"></div>`;
  if (type === 'barracks') htmlContent += _buildBarracksSection();
  if (type === 'watchtower') htmlContent += `<div id="watchtower-dynamic-content"></div>`;
  const mc = $('modal-content'); if (mc) mc.innerHTML = htmlContent;
  if (type === 'barracks' && mc) {
    mc.querySelectorAll('.btn-recruit[data-unit-key]').forEach(btn => {
      btn.addEventListener('click', () => {
        const key = btn.dataset.unitKey;
        if (!key) return;
        if (btn.disabled) { if (typeof playSFX === 'function') playSFX('error'); return; }
        recruitUnit(key);
      });
    });
  }
  if (gm) gm.classList.add('show');
  renderUpgradeSection(type);
  if (type === 'castle') updateCastleUI();
  if (type === 'farm') updateFarmModalUI();
  if (type === 'mine') updateMineModalUI();
  if (type === 'smith') updateSmithModalUI();
  if (type === 'lumber') updateLumberModalUI();
  if (type === 'hospital') renderHospitalUI();
  if (type === 'barracks') updateBarracksUI();
  if (type === 'watchtower') {
    if (typeof updatePeaceTreatyUI === 'function') updatePeaceTreatyUI();
    else if (typeof updateWatchtowerUI === 'function') updateWatchtowerUI();
  }
  if (type === 'academy' && _isPlainObj(state.academyResearch) && _isPlainObj(state.academyResearch.activeResearch) && state.academyResearch.activeResearch.branch) {
    renderSpeedupButtons('academy-speedups', 'academy');
  }
}

// ============================================================
// 🏰 Castle UI (✅ FIX 1: _fmtRate برای نمایش اعشاری)
// ============================================================
function updateCastleUI() {
  if (currentBuilding !== 'castle') return;
  const c = $('castle-dynamic-content'); if (!c) return;
  const lvl = Math.max(1, _bInt(state.buildings && state.buildings.castle, 1));
  const buffs = (typeof getAcademyBuffs === 'function') ? getAcademyBuffs() : { armyPower: 1, goldProd: 1, xp: 1 };
  const ratePerMin = 0.3 * lvl * _bNum(buffs.goldProd, 1);
  const cap = ratePerMin * TAX_CAP_MINUTES;
  const acc = _bNum(state.castle && state.castle.accumulatedGold, 0);
  const now = Date.now();
  const cdLeftMs = Math.max(0, TAX_COOLDOWN_MS - (now - _bNum(state.castle && state.castle.lastCollectTime, 0)));
  const dp = (typeof getDefensePower === 'function') ? getDefensePower() : 0;
  const btnLabel = cdLeftMs > 0 ? `صبر کن (${fmtDur(cdLeftMs)})` : (acc >= 1 ? 'جمع‌آوری مالیات 💰' : 'هنوز مالیاتی جمع نشده');
  const btnDisabled = cdLeftMs > 0 || acc < 1;
  const unread = _bInt(state.msgUnread, 0);
  
  // ✅ بهینه‌سازی: اگر HTML از قبل ساخته شده، فقط متن‌ها رو آپدیت کن تا بازی هنگ نکنه
  if (c.dataset.built !== '1') {
    c.dataset.built = '1';
    c.innerHTML = `
      <div class="farm-ui" style="margin-top:0; margin-bottom:15px; display:grid; grid-template-columns:repeat(3,1fr); gap:8px; border-color:var(--gold); background:rgba(0,0,0,0.6);">
        <button class="btn-action" style="background:linear-gradient(180deg,#64b5f6,#1976d2);color:#fff;position:relative;margin:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;font-size:13px;padding:10px;" onclick="openCastleMessages()">
          ${iconHTML(_ICON.message, 24, '📨')}
          <span>پیغام‌ها</span>
          <span id="castle-unread-badge" style="display:none; position:absolute; top:-5px; right:-5px; background:#e53935;color:#fff;border-radius:50%;min-width:20px;height:20px;align-items:center;justify-content:center;font-size:11px;font-weight:bold;padding:0 5px;"></span>
        </button>
        
        <button class="btn-action" style="background:linear-gradient(180deg,#ffd54f,#f9a825);color:#000;margin:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;font-size:13px;padding:10px;" onclick="openMissions()">
          <span style="font-size:24px;">📜</span> <span>ماموریت‌ها</span>
        </button>
        
        <button class="btn-action" style="background:linear-gradient(180deg,#a1887f,#6d4c41);color:#fff;margin:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;font-size:13px;padding:10px;" onclick="openInventory()">
          <span style="font-size:24px;">🎒</span> <span>انبار منابع</span>
        </button>
      </div>
      
      <div class="farm-ui">
        <div class="level-text">💰 مالیات قلعه</div>
        <div id="castle-rate" style="font-size:13px;color:#8bc34a;"></div>
        <div id="castle-acc" style="font-size:13px;"></div>
        <button id="castle-tax-btn" class="btn-action" style="background:linear-gradient(180deg,#f5c66b,#c8963a);color:#000;display:flex;align-items:center;justify-content:center;gap:8px;" onclick="collectTaxNow()"></button>
        <div id="castle-dp" style="font-size:13px;color:#eee;margin-top:5px;"></div>
        <div id="castle-buffs" style="font-size:12px;color:#ccc;"></div>
      </div>`;
  }

  // ✅ فقط مقادیر متنی رو آپدیت می‌کنیم (بدون ساخت مجدد دکمه‌ها)
  const badge = $('castle-unread-badge');
  if (badge) {
    if (unread > 0) { badge.style.display = 'inline-flex'; badge.textContent = toFa(unread); }
    else { badge.style.display = 'none'; }
  }
  if ($('castle-rate')) $('castle-rate').textContent = `تولید خودکار: +${_fmtRate(ratePerMin)} طلا در دقیقه (آفلاین تا ${toFa(TAX_CAP_MINUTES)} دقیقه)`;
  if ($('castle-acc')) $('castle-acc').innerHTML = `💰 طلای آماده برداشت: <b style="color:#f5c66b;">${toFa(Math.floor(acc))}</b> از ${toFa(Math.floor(cap))}`;
  
  const btn = $('castle-tax-btn');
  if (btn) {
    btn.disabled = btnDisabled;
    btn.innerHTML = `${cdLeftMs > 0 ? timerIconHTML(16) : iconHTML(_ICON.gold,16,'🪙')} ${btnLabel}`;
  }
  if ($('castle-dp')) $('castle-dp').innerHTML = `🛡️ قدرت دفاعی قلعه: <b style="color:#4caf50;">${toFa(dp)}</b>`;
  if ($('castle-buffs')) $('castle-buffs').textContent = `باف‌های فعال: ⚔️ قدرت ارتش +${toFa(Math.round((buffs.armyPower-1)*100))}٪ | 🪙 طلا +${toFa(Math.round((buffs.goldProd-1)*100))}٪ | ⭐ تجربه +${toFa(Math.round((buffs.xp-1)*100))}٪`;
}

function updateFarmModalUI() {
  if (currentBuilding !== 'farm') return;
  const elBar = $('farm-progress-bar'), elTimer = $('farm-timer-text'), elAz = $('farm-az'), elWd = $('farm-wd'), elCap = $('farm-cap-text');
  if (!elBar || !elTimer || !elAz || !elWd || !elCap) return;
  if (!_isPlainObj(state.farm)) return;
  const lvl = Math.max(1, _bInt(state.buildings && state.buildings.farm, 1));
  const cap = 200 + ((lvl - 1) * 400);
  const cur = _bNum(state.farm.accumulatedAzooghe, 0) + _bNum(state.farm.accumulatedWood, 0);
  renderProdButtons('farm', cur >= cap - 0.5);
  elBar.style.width = `${Math.min(100, (cur / cap) * 100)}%`;
  elAz.textContent = toFa(_bNum(state.farm.accumulatedAzooghe, 0));
  elWd.textContent = toFa(_bNum(state.farm.accumulatedWood, 0));
  elCap.textContent = `${toFa(cur)} از ${toFa(cap)}`;
  if (cur >= cap) { elTimer.innerHTML = 'انبار پر شد! آماده برداشت ✅'; elTimer.style.color = '#4caf50'; }
  else if (!state.farm.isProducing && cur === 0) { elTimer.innerHTML = 'متوقف - دکمه شروع را بزنید'; elTimer.style.color = '#aaa'; }
  else {
    const rates = (4 * lvl) + (2 * lvl);
    const remaining = cap - cur;
    const mins = remaining / rates;
    const m = Math.floor(mins), s = Math.floor((mins - m) * 60);
    elTimer.innerHTML = `${timerIconHTML(14)} ${toFa(m)}:${toFa(s).padStart(2, '۰')} تا پر شدن`;
    elTimer.style.color = '#fff';
  }
}

function updateMineModalUI() {
  if (currentBuilding !== 'mine') return;
  const elBar = $('mine-progress-bar'), elTimer = $('mine-timer-text'), elSt = $('mine-st'), elCo = $('mine-co'), elDi = $('mine-di'), elCap = $('mine-cap-text');
  if (!elBar || !elTimer || !elSt || !elCo || !elDi || !elCap) return;
  if (!_isPlainObj(state.mine)) return;
  const lvl = Math.max(1, _bInt(state.buildings && state.buildings.mine, 1));
  const cap = getProdCapacity('mine');
  const cur = _bNum(state.mine.accumulatedStone, 0) + _bNum(state.mine.accumulatedCoal, 0) + _bNum(state.mine.accumulatedDiamond, 0);
  renderProdButtons('mine', cur >= cap - 0.5);
  elBar.style.width = `${Math.min(100, (cur / cap) * 100)}%`;
  elSt.textContent = toFa(_bNum(state.mine.accumulatedStone, 0));
  elCo.textContent = toFa(_bNum(state.mine.accumulatedCoal, 0));
  elDi.textContent = toFa(_bNum(state.mine.accumulatedDiamond, 0));
  elCap.textContent = `${toFa(cur)} از ${toFa(cap)}`;
  if (cur >= cap) elTimer.innerHTML = 'انبار پر شد!';
  else if (!state.mine.isProducing && cur === 0) elTimer.innerHTML = 'متوقف';
  else {
    const rates = getProdRatePerMin('mine');
    const totalRate = rates.stone + rates.coal + rates.diamond;
    const remainingMs = totalRate > 0 ? (cap - cur) / totalRate * 60000 : 0;
    elTimer.textContent = `${fmtDur(remainingMs)} تا پر شدن | الماس: ${_fmtRate(rates.diamond)} در دقیقه`;
  }
}

// ============================================================
// ⚔️ Recruit + Training
// ============================================================
function recruitUnit(key) {
  if (typeof UNITS_INFO === 'undefined' || !UNITS_INFO[key]) {
    showToast('واحد نامعتبر! ❌', 'error'); playSFX('error'); return;
  }
  if (_isBadKey(key)) {
    showToast('واحد نامعتبر! ❌', 'error'); playSFX('error'); return;
  }
  if (_isPlainObj(state.barracksTraining) && state.barracksTraining.unit) {
    const validUnit = UNITS_INFO[state.barracksTraining.unit];
    if (validUnit) {
      showToast('⚔️ ارتش در حال آموزش است!', 'error');
      playSFX('error'); return;
    } else {
      state.barracksTraining = { unit: null, qty: 1, startTime: 0, endTime: 0 };
      saveGame();
    }
  }
  openTrainQuantityModal(key);
}

function openTrainQuantityModal(key) {
  if (isProcessing) return;
  if (typeof UNITS_INFO === 'undefined' || !UNITS_INFO[key]) return;
  if (_isBadKey(key)) return;
  const cb = $('qty-confirm-btn'); if (cb) cb.onclick = null;
  if (_isPlainObj(state.barracksTraining) && state.barracksTraining.unit) {
    const validUnit = UNITS_INFO[state.barracksTraining.unit];
    if (validUnit) {
      showToast('⚔️ ارتش در حال آموزش است!', 'error');
      playSFX('error');
      return;
    } else {
      state.barracksTraining = { unit: null, qty: 1, startTime: 0, endTime: 0 };
      saveGame();
    }
  }
  const u = UNITS_INFO[key];
  if (!u || !u.cost) return;
  const bLvl = _bInt(state.buildings && state.buildings.barracks, 1);
  const reqLvl = _bInt(u.reqBarracksLevel, 1);
  if (bLvl < reqLvl) {
    showToast(`🔒 ابتدا سربازخانه را به سطح ${toFa(reqLvl)} برسان!`, 'error');
    playSFX('error');
    return;
  }
  const maxArmy = (typeof getMaxArmy === 'function') ? getMaxArmy(bLvl) : 9999;
  const curArmy = (typeof getTotalArmyCount === 'function') ? getTotalArmyCount() : 0;
  const room = maxArmy - curArmy;
  if (room <= 0) {
    showToast(`⚠️ ظرفیت ارتش پر است! (${toFa(curArmy)} / ${toFa(maxArmy)})`, 'error');
    playSFX('error');
    return;
  }
  let maxAffordable = room;
  const _safeInv = _isPlainObj(state.inventory) ? state.inventory : {};
  for (const res in u.cost) {
    if (_isBadKey(res)) continue;
    const have = state[res] !== undefined ? _bNum(state[res], 0) : _bNum(_safeInv[res], 0);
    const need = _bNum(u.cost[res], 0);
    if (need > 0) {
      const canMake = Math.floor(have / need);
      if (canMake < maxAffordable) maxAffordable = canMake;
    }
  }
  if (maxAffordable <= 0) {
    showToast('منابع یا تجهیزات کافی برای آموزش نداری! ❌', 'error');
    playSFX('error');
    return;
  }
  window._trainUnitKey = key;
  window._trainQty = 1;
  window._trainMaxAffordable = maxAffordable;
  const titleEl = $('qty-title');
  if (titleEl) { titleEl.textContent = `⚔️ آموزش ${u.name || key}`; titleEl.style.color = 'var(--gold)'; }
  const detailsEl = $('qty-details');
  if (detailsEl) { detailsEl.style.display = 'none'; detailsEl.innerHTML = ''; }
  const qtyGrid = $('qty-grid'); if (!qtyGrid) return;
  qtyGrid.innerHTML = '';
  const qtys = [1, 5, 10, 50, 100, 500];
  let anyAffordable = false;
  qtys.forEach(q => {
    if (q > maxAffordable) return;
    let canAfford = true;
    for (const res in u.cost) {
      if (_isBadKey(res)) continue;
      const have = state[res] !== undefined ? _bNum(state[res], 0) : _bNum(_safeInv[res], 0);
      if (have < _bNum(u.cost[res], 0) * q) { canAfford = false; break; }
    }
    const btn = document.createElement('button');
    btn.className = 'qty-btn';
    btn.textContent = toFa(q);
    if (!canAfford) btn.disabled = true; else anyAffordable = true;
    btn.onclick = () => {
      if (btn.disabled) return;
      qtyGrid.querySelectorAll('.qty-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      window._trainQty = q;
      updateTrainDetails(key, q);
      playSFX('click');
    };
    qtyGrid.appendChild(btn);
  });
  const btnMax = document.createElement('button');
  btnMax.className = 'qty-btn'; btnMax.textContent = 'حداکثر';
  btnMax.onclick = () => {
    qtyGrid.querySelectorAll('.qty-btn').forEach(b => b.classList.remove('selected'));
    btnMax.classList.add('selected');
    window._trainQty = maxAffordable;
    updateTrainDetails(key, maxAffordable);
    playSFX('click');
  };
  qtyGrid.appendChild(btnMax);
  if (!anyAffordable) {
    showToast("منابع کافی نیست! ❌", 'error'); playSFX('error'); return;
  }
  const firstBtn = qtyGrid.querySelector('button:not(:disabled)');
  if (firstBtn) firstBtn.click();
  $('qty-confirm-btn').onclick = () => {
    const q = _bInt(window._trainQty, 1);
    if (q <= 0) return;
    closeQuantityModal();
    startTraining(key, q);
  };
  $('quantityModal').classList.add('show');
}

function updateTrainDetails(key, qty) {
  if (typeof UNITS_INFO === 'undefined' || !UNITS_INFO[key]) return;
  const u = UNITS_INFO[key];
  const bLvl = _bInt(state.buildings && state.buildings.barracks, 1);
  const trainTime = (typeof getTrainTime === 'function') ? getTrainTime(key, bLvl) : _bInt(u.trainTime, 10000);
  const totalTime = trainTime * qty;
  const timeStr = (typeof fmtDur === 'function') ? fmtDur(totalTime) : `${toFa(Math.ceil(totalTime/1000))} ثانیه`;
  const unitPower = (typeof getUnitPower === 'function') ? getUnitPower(key, bLvl) : _bNum(u.power, 0);
  const totalPower = unitPower * qty;
  let costHtml = '';
  for (const res in u.cost) {
    if (_isBadKey(res)) continue;
    const iconRaw = (typeof RES_ICON !== 'undefined' && RES_ICON[res]) || '🎁';
    const iconHtml = (typeof iconHTML === 'function') ? iconHTML(iconRaw, 18, '🎁') : iconRaw;
    costHtml += `${iconHtml} ${toFa(_bNum(u.cost[res], 0) * qty)} ${(typeof resNames !== 'undefined' && resNames[res]) || res} | `;
  }
  const details = $('qty-details');
  if (!details) return;
  details.style.display = 'block';
  details.innerHTML = `
    <div>شما ${toFa(qty)} عدد ${escapeHtml(u.name || key)} آموزش می‌دهید.</div>
    <div style="margin-top:5px;color:var(--gold);">هزینه: ${costHtml}</div>
    <div style="margin-top:5px;color:#8bc34a;">${timerIconHTML(12)} زمان: ${timeStr}</div>
    <div style="margin-top:5px;color:#4caf50;">قدرت کل: ⚔️ ${toFa(totalPower)}</div>
  `;
}

function startTraining(key, qty) {
  if (!acquireLock()) return;
  try {
    if (typeof UNITS_INFO === 'undefined' || !UNITS_INFO[key]) return;
    if (_isBadKey(key)) return;
    qty = Math.floor(Number(qty)) || 1;
    if (qty < 1) qty = 1;
    if (qty > 1000) qty = 1000;
    if (_isPlainObj(state.barracksTraining) && state.barracksTraining.unit) {
      const validUnit = UNITS_INFO[state.barracksTraining.unit];
      if (validUnit) {
        showToast('⚔️ ارتش در حال آموزش است! ⏳', 'error'); playSFX('error'); return;
      } else {
        state.barracksTraining = { unit: null, qty: 1, startTime: 0, endTime: 0 };
        saveGame();
      }
    }
    const u = UNITS_INFO[key];
    if (!u || !u.cost) return;
    const bLvl = _bInt(state.buildings && state.buildings.barracks, 1);
    const reqLvl = _bInt(u.reqBarracksLevel, 1);
    if (bLvl < reqLvl) {
      showToast(`🔒 ابتدا سربازخانه را به سطح ${toFa(reqLvl)} برسان!`, 'error'); playSFX('error'); return;
    }
    const maxArmy = (typeof getMaxArmy === 'function') ? getMaxArmy(bLvl) : 9999;
    const curArmy = (typeof getTotalArmyCount === 'function') ? getTotalArmyCount() : 0;
    const room = maxArmy - curArmy;
    if (room <= 0) {
      showToast('⚠️ ظرفیت ارتش پر است!', 'error'); playSFX('error'); return;
    }
    if (qty > room) qty = room;
    const totalCost = {};
    for (const res in u.cost) {
      if (_isBadKey(res)) continue;
      totalCost[res] = _bNum(u.cost[res], 0) * qty;
    }
    try {
      transaction(() => {
        if (!deductResources(totalCost)) throw new Error('insufficient');
        const now = Date.now();
        const t = (typeof getTrainTime === 'function') ? getTrainTime(key, bLvl) : _bInt(u.trainTime, 10000);
        state.barracksTraining = { unit: key, qty: qty, startTime: now, endTime: now + t * qty };
      });
    } catch (e) {
      showToast('منابع یا تجهیزات کافی نیست! ❌', 'error'); playSFX('error'); return;
    }
    updateUI(); saveGame();
    showToast(`⚒️ آموزش ${toFa(qty)} عدد ${u.name || key} آغاز شد! ⏳`);
    playSFX('success');
    if (currentBuilding === 'barracks') refreshBarracksContent();
  } finally { releaseLock(); }
}

function refreshBarracksContent() {
  if (currentBuilding !== 'barracks') return;
  const body = document.querySelector('.modal-body');
  const keepTop = body ? body.scrollTop : 0;
  const btnImg = document.querySelector('.building[data-type="barracks"]');
  if (typeof showModalContent === 'function') {
    showModalContent('barracks', btnImg ? btnImg.getAttribute('src') : null);
    setTimeout(() => {
      const nb = document.querySelector('.modal-body');
      if (nb) nb.scrollTop = keepTop;
    }, 0);
  }
}

function finishTraining() {
  const t = state.barracksTraining;
  if (!_isPlainObj(t) || !t.unit) return;
  const key = t.unit;
  const qty = _bInt(t.qty, 1);
  if (_isBadKey(key) || qty <= 0) {
    state.barracksTraining = { unit: null, qty: 1, startTime: 0, endTime: 0 };
    saveGame(); return;
  }
  const u = (typeof UNITS_INFO !== 'undefined') ? UNITS_INFO[key] : null;
  if (!u) {
    state.barracksTraining = { unit: null, qty: 1, startTime: 0, endTime: 0 };
    saveGame(); return;
  }
  const _endT = _bNum(t.endTime, 0);
  const _startT = _bNum(t.startTime, 0);
  if (_endT <= 0 || _startT <= 0) {
    state.barracksTraining = { unit: null, qty: 1, startTime: 0, endTime: 0 };
    saveGame(); return;
  }
  if (Date.now() < _endT) return;
  const bLvl = _bInt(state.buildings && state.buildings.barracks, 1);
  const maxArmy = (typeof getMaxArmy === 'function') ? getMaxArmy(bLvl) : 9999;
  const curArmy = (typeof getTotalArmyCount === 'function') ? getTotalArmyCount() : 0;
  const room = maxArmy - curArmy;
  const actualQty = Math.max(0, Math.min(qty, room));
  if (actualQty <= 0) {
    try {
      transaction(() => {
        if (u.cost) for (const res of Object.keys(u.cost)) {
          if (_isBadKey(res)) continue;
          const refund = Math.floor(_bNum(u.cost[res], 0) * qty);
          if (refund <= 0) continue;
          if (state[res] !== undefined) state[res] = _bNum(state[res], 0) + refund;
          else {
            if (!_isPlainObj(state.inventory)) state.inventory = {};
            state.inventory[res] = _bNum(state.inventory[res], 0) + refund;
          }
        }
        state.barracksTraining = { unit: null, qty: 1, startTime: 0, endTime: 0 };
      });
    } catch (e) { console.error('Full training refund failed:', e); return; }
    updateUI(); saveGame();
    showToast('ظرفیت ارتش پر بود؛ آموزش لغو شد و ۱۰۰٪ منابع بازگشت.', 'error');
    if (typeof playSFX === 'function') playSFX('error');
    if (currentBuilding === 'barracks') refreshBarracksContent();
    return;
  }
  try {
    transaction(() => {
      if (!_isPlainObj(state.army)) state.army = JSON.parse(JSON.stringify(DEFAULT_STATE.army));
      state.army[key] = _bInt(state.army[key], 0) + actualQty;
      state.barracksTraining = { unit: null, qty: 1, startTime: 0, endTime: 0 };
    });
  } catch (e) {
    // ✅ FIX: اگر تراکنش خطا داد، آموزش را پاک نکن تا در تیک بعدی دوباره تلاش کند (منابع از بین نمی‌رود)
    console.error('finishTraining transaction failed:', e);
    return;
  }
  
  const notTrained = qty - actualQty;
  if (notTrained > 0 && u.cost) {
    try {
      transaction(() => {
        for (const res in u.cost) {
          if (_isBadKey(res)) continue;
          const refund = Math.floor(_bNum(u.cost[res], 0) * notTrained);
          if (refund <= 0) continue;
          if (state[res] !== undefined) {
            state[res] = _bNum(state[res], 0) + refund;
          } else {
            if (!_isPlainObj(state.inventory)) state.inventory = {};
            state.inventory[res] = _bNum(state.inventory[res], 0) + refund;
          }
        }
      });
    } catch (e) {}
    showToast(`⚠️ فقط ${toFa(actualQty)} از ${toFa(qty)} سرباز جا شدن و بقیه منابع برگشت.`, 'error');
  }
  try { if (typeof addXP === 'function') addXP(Math.floor(_bNum(u.power, 30) / 10) * actualQty); } catch (e) {}
  try {
    if (typeof missionAdd === 'function') {
      missionAdd('recruit', actualQty);
    }
  } catch (e) {}
  try {
    if (typeof spawnIcon === 'function') {
      spawnIcon('⚔️', '55%', '55%');
      setTimeout(() => { try { if (typeof spawnIcon === 'function') spawnIcon('✨', '55%', '55%'); } catch (err) {} }, 200);
    }
  } catch (e) {}
  try { if (typeof buzz === 'function') buzz([80, 60, 80]); } catch (e) {}
  updateUI(); saveGame();
  setTimeout(() => { showToast(`⚔️ آموزش ${toFa(actualQty)} عدد ${u.name || key} کامل شد!`); }, 150);
  if (typeof playSFX === 'function') playSFX('success');
  if (typeof playSoundFile === 'function') playSoundFile('ghost/dropping-single-coin.mp3', 0.6);
  if (typeof addMessage === 'function') {
    addMessage('training', '⚔️', `آموزش ${toFa(actualQty)} ${u.name || key}`,
      `سربازان جدید به ارتش اضافه شدند. ظرفیت: ${toFa(curArmy + actualQty)} / ${toFa(maxArmy)}`);
  }
  if (typeof addWatchtowerAlert === 'function') {
    addWatchtowerAlert('training', '⚔️', 'آموزش کامل شد',
      `${toFa(actualQty)} ${u.name || key} به ارتش اضافه شد.`,
      null);
  }
  if (currentBuilding === 'barracks') refreshBarracksContent();
}

function cancelTrainingSilent() {
  const t = state.barracksTraining;
  if (!_isPlainObj(t) || !t.unit) return false;
  const key = t.unit;
  const qty = _bInt(t.qty, 1);
  const u = (typeof UNITS_INFO !== 'undefined') ? UNITS_INFO[key] : null;
  if (!u || !u.cost || _isBadKey(key) || _bNum(t.startTime, 0) <= 0 || _bNum(t.endTime, 0) <= 0 || qty <= 0) {
    state.barracksTraining = { unit: null, qty: 1, startTime: 0, endTime: 0 };
    if (typeof saveGame === 'function') saveGame();
    return false;
  }
  try {
    transaction(() => {
      for (const res in u.cost) {
        if (_isBadKey(res)) continue;
        const refund = Math.floor(_bNum(u.cost[res], 0) * qty * 0.8);
        if (refund <= 0) continue;
        if (state[res] !== undefined) {
          state[res] = _bNum(state[res], 0) + refund;
        } else {
          if (!_isPlainObj(state.inventory)) state.inventory = {};
          state.inventory[res] = _bNum(state.inventory[res], 0) + refund;
        }
      }
      state.barracksTraining = { unit: null, qty: 1, startTime: 0, endTime: 0 };
    });
    return true;
  } catch (e) { return false; }
}

function cancelTraining() {
  if (Date.now() > _trainCancelArm) {
    _trainCancelArm = Date.now() + 3000;
    showToast('برای تأیید لغو، دوباره بزن ⚠️', 'error');
    if (typeof playSFX === 'function') playSFX('error');
    const btn = document.querySelector('#train-cancel-btn');
    if (btn) {
      const original = btn.textContent;
      btn.textContent = '⚠️ برای تأیید دوباره بزن';
      btn.style.background = 'linear-gradient(180deg,#e53935,#b71c1c)';
      setTimeout(() => {
        if (btn && btn.isConnected) { btn.textContent = original; btn.style.background = ''; }
      }, 3000);
    }
    return;
  }
  _trainCancelArm = 0;
  if (!acquireLock()) {
    _trainCancelArm = Date.now() + 3000;
    showToast('⏳ لطفاً صبر کنید...', 'error'); return;
  }
  try {
    const t = state.barracksTraining;
    if (!_isPlainObj(t) || !t.unit) return;
    const ok = cancelTrainingSilent();
    if (!ok) {
      showToast('خطا در لغو آموزش!', 'error');
      if (typeof playSFX === 'function') playSFX('error');
      return;
    }
    updateUI(); saveGame();
    showToast('آموزش لغو شد و ۸۰٪ منابع بازگشت.');
    if (typeof playSFX === 'function') playSFX('success');
    if (currentBuilding === 'barracks') refreshBarracksContent();
  } finally { releaseLock(); }
}

function speedUpTraining() {
  if (!acquireLock()) return;
  try {
    const t = state.barracksTraining;
    if (!_isPlainObj(t) || !t.unit) return;
    if (typeof t.endTime !== 'number' || !isFinite(t.endTime) || t.endTime <= 0) return;
    const cost = (typeof getTrainSpeedupCost === 'function') ? getTrainSpeedupCost(t.endTime) : getSpeedupCost(t.endTime);
    let _finishNow = false;
    try {
      transaction(() => {
        if (cost > 0 && !spendGold(cost)) throw new Error('no gold');
        if (t.endTime - Date.now() < 60000) { t.endTime = Date.now(); _finishNow = true; }
        else { t.endTime -= 60000; }
      });
    } catch (e) {
      _finishNow = false;
      showToast('طلا کافی نیست!', 'error');
      if (typeof playSFX === 'function') playSFX('error');
      return;
    }
    if (_finishNow) {
      if (typeof finishTraining === 'function') finishTraining();
    } else {
      updateUI(); saveGame();
      showToast(`۱ دقیقه از زمان آموزش کم شد (${toFa(cost)} طلا)! ⏩`);
      if (typeof playSFX === 'function') playSFX('success');
      if (currentBuilding === 'barracks') updateBarracksUI();
    }
  } finally { releaseLock(); }
}

function updateBarracksUI() {
  if (currentBuilding !== 'barracks') return;
  const c = $('barracks-training-content'); if (!c) return;
  const t = state.barracksTraining;
  if (_isPlainObj(t) && t.unit && typeof UNITS_INFO !== 'undefined' && UNITS_INFO[t.unit]) {
    const u = UNITS_INFO[t.unit];
    const now = Date.now();
    const dur = t.endTime - t.startTime;
    const pct = dur > 0 ? Math.min(100, Math.max(0, ((now - t.startTime) / dur) * 100)) : 0;
    const left = Math.max(0, t.endTime - now);
    const cost = (typeof getTrainSpeedupCost === 'function') ? getTrainSpeedupCost(t.endTime) : getSpeedupCost(t.endTime);
    const qty = _bInt(t.qty, 1);
    if (c.dataset.mode !== 'training' || !c.querySelector('#train-bar')) {
      c.dataset.mode = 'training';
      c.innerHTML = `
        <div class="upgrade-section" style="border-color:#f5c66b;">
          <div class="train-progress-wrap">
            <img src="${escapeHtml(u.img || 'ghost/castle.png')}" class="train-unit-thumb" onerror="this.onerror=null;this.src='ghost/castle.png'" alt="${escapeHtml(u.name || t.unit)}">
            <div style="flex:1; min-width:0;">
              <div class="level-text" id="train-title">${timerIconHTML(16)} آموزش ${toFa(qty)} عدد ${escapeHtml(u.name || t.unit)}</div>
              <div class="progress-container">
                <div class="progress-bar" id="train-bar" style="width:${pct}%"></div>
                <div class="progress-text" id="train-text"></div>
              </div>
            </div>
          </div>
          <button class="btn-speedup" id="train-speedup-btn" type="button">${timerIconHTML(16)} تسریع (طلا)</button>
          <div class="speedup-row" id="train-speedups"></div>
          <button class="btn-cancel-craft" id="train-cancel-btn" type="button">لغو آموزش (بازگشت ۸۰٪)</button>
        </div>`;
      const suBtn0 = c.querySelector('#train-speedup-btn');
      if (suBtn0) suBtn0.addEventListener('click', speedUpTraining);
      const cancelBtn = c.querySelector('#train-cancel-btn');
      if (cancelBtn) cancelBtn.addEventListener('click', cancelTraining);
    }
    const bar = c.querySelector('#train-bar');
    const text = c.querySelector('#train-text');
    const suBtn = c.querySelector('#train-speedup-btn');
    if (bar) bar.style.width = pct + '%';
    if (text) text.textContent = formatTime(left) + ' باقی مانده';
    if (suBtn) {
      const inv = _isPlainObj(state.inventory) ? state.inventory : {};
      const totalItems = ['speedup_1m', 'speedup_10m', 'speedup_1h', 'speedup_1d'].reduce((s, k) => s + _bInt(inv[k], 0), 0);
      suBtn.innerHTML = `${timerIconHTML(16)} تسریع (${toFa(cost)} طلا) | 📦 ${toFa(totalItems)}`;
    }
    if (typeof renderSpeedupButtons === 'function') renderSpeedupButtons('train-speedups', 'barracks');
  } else {
    if (c.dataset.mode !== 'idle') { c.dataset.mode = 'idle'; c.innerHTML = ''; }
  }
}

// ============================================================
// 🏥 Hospital
// ============================================================
function renderHospitalUI() {
  const container = $('hospital-dynamic-content'); if (!container) return;
  const wounded = (state.hospital && state.hospital.wounded) || {};
  const keys = Object.keys(wounded);
  let html = `<div class="upgrade-section" style="text-align:right;">`;
  if (keys.length === 0) {
    html += `<div style="text-align:center; color:#aaa; padding:20px;">هیچ سرباز زخمی در بیمارستان نیست. ✅</div>`;
  } else {
    html += `<div style="font-family:var(--font-persian); color:var(--gold); font-size:18px; margin-bottom:10px; text-align:center;">🩸 درمان سربازان زخمی</div>`;
    keys.forEach(k => {
      const count = _bInt(wounded[k], 0); if (count <= 0) return;
      const unit = (typeof UNITS_INFO !== 'undefined' && UNITS_INFO[k]);
      const cost = (typeof HEAL_COSTS !== 'undefined' && HEAL_COSTS[k]);
      if (!unit || !cost) return;
      let costHtml = '';
      for (let res in cost) {
        const iconRaw = (typeof RES_ICON !== 'undefined' && RES_ICON[res]) || '';
        const iconHtml = (typeof iconHTML === 'function') ? iconHTML(iconRaw, 18, '🎁') : iconRaw;
        costHtml += `<span style="color:#ff5252; font-size:11px;">${iconHtml} ${toFa(cost[res])} ${(typeof resNames !== 'undefined' && resNames[res]) || res}</span> | `;
      }
      html += `<div class="unit-card" style="cursor:pointer;" onclick="openHealModal('${k}')"><img src="${unit.img || 'ghost/castle.png'}" class="unit-img" onerror="this.onerror=null;this.src='ghost/castle.png'"><div class="unit-info"><div class="unit-name">${unit.name || k} (${toFa(count)} زخمی)</div><div class="unit-cost">هزینه هر عدد: ${costHtml}</div></div><button class="btn-recruit" style="background:linear-gradient(180deg,#4caf50,#2e7d32); color:white;">درمان</button></div>`;
    });
  }
  html += `</div>`;
  if (container.dataset.h !== html) { container.dataset.h = html; container.innerHTML = html; }
}

function openHealModal(unitKey) {
  if (isProcessing) return;
  if (_isBadKey(unitKey)) return;
  const cb = $('qty-confirm-btn'); if (cb) cb.onclick = null;
  const woundedCount = _bInt(state.hospital && state.hospital.wounded && state.hospital.wounded[unitKey], 0);
  if (woundedCount <= 0) return;
  const maxArmy = typeof getMaxArmy === 'function' ? getMaxArmy(_bInt(state.buildings && state.buildings.barracks, 1)) : 9999;
  const curArmy = typeof getTotalArmyCount === 'function' ? getTotalArmyCount() : 0;
  const room = maxArmy - curArmy;
  if (room <= 0) { showToast('⚠️ ظرفیت ارتش پر است!', 'error'); playSFX('error'); return; }
  const cost = (typeof HEAL_COSTS !== 'undefined' && HEAL_COSTS[unitKey]);
  if (!cost) { showToast('خطا: واحد ناشناخته ❌', 'error'); playSFX('error'); return; }
  const unit = (typeof UNITS_INFO !== 'undefined' && UNITS_INFO[unitKey]);
  if (!unit) return;
  
  let maxAffordable = Math.min(woundedCount, room);
  for (let res in cost) {
    const available = state[res] !== undefined ? _bNum(state[res], 0) : _bNum(state.inventory && state.inventory[res], 0);
    const possible = cost[res] > 0 ? Math.floor(available / cost[res]) : Infinity;
    if (possible < maxAffordable) maxAffordable = possible;
  }
  if (maxAffordable <= 0) { showToast('منابع کافی برای درمان نداری یا ظرفیت ارتش پر است! ❌', 'error'); playSFX('error'); return; }
  
  const titleEl = $('qty-title');
  if (titleEl) { titleEl.textContent = `⚔️ درمان ${unit.name || unitKey}`; titleEl.style.color = '#ff5252'; }
  const detailsEl = $('qty-details');
  if (detailsEl) { detailsEl.style.display = 'none'; detailsEl.innerHTML = ''; }
  
  const qtyGrid = $('qty-grid'); if (!qtyGrid) return;
  qtyGrid.innerHTML = '';
  const qtys = [1, 5, 10, 50, 100, 500];
  let anyAffordable = false;
  let _healQty = 1;
  
  qtys.forEach(q => {
    if (q > maxAffordable) return;
    let canAfford = true;
    for (let res in cost) {
      const available = state[res] !== undefined ? _bNum(state[res], 0) : _bNum(state.inventory && state.inventory[res], 0);
      if (available < cost[res] * q) { canAfford = false; break; }
    }
    const btn = document.createElement('button');
    btn.className = 'qty-btn'; btn.textContent = q.toLocaleString('fa-IR');
    if (!canAfford) btn.disabled = true; else anyAffordable = true;
    btn.onclick = () => {
      if (btn.disabled) return;
      qtyGrid.querySelectorAll('.qty-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected'); _healQty = q; updateHealDetails(unitKey, q); playSFX('click');
    };
    qtyGrid.appendChild(btn);
  });
  
  if (maxAffordable > 0) {
    const btnMax = document.createElement('button');
    btnMax.className = 'qty-btn'; btnMax.textContent = 'حداکثر';
    btnMax.onclick = () => {
      qtyGrid.querySelectorAll('.qty-btn').forEach(b => b.classList.remove('selected'));
      btnMax.classList.add('selected'); _healQty = maxAffordable; updateHealDetails(unitKey, maxAffordable); playSFX('click');
    };
    qtyGrid.appendChild(btnMax);
  }
  
  if (!anyAffordable) { showToast("منابع کافی نیست! ❌", 'error'); playSFX('error'); return; }
  const firstBtn = qtyGrid.querySelector('button:not(:disabled)');
  if (firstBtn) firstBtn.click();
  
  $('qty-confirm-btn').onclick = () => {
    if (!acquireLock()) {
      showToast('⏳ لطفاً صبر کنید...', 'error');
      return;
    }
    try {
      const healAmount = _healQty;
      if (!isFinite(healAmount) || healAmount <= 0) {
        showToast('تعداد نامعتبر است! ❌', 'error');
        return;
      }
      const res = typeof confirmHealLogic === 'function' ? confirmHealLogic(unitKey, healAmount) : { status: 'invalid' };
      if (res.status === 'ok') {
        updateUI(); saveGame(); renderHospitalUI(); closeQuantityModal();
        showToast(`⚔️ ${toFa(res.healed)} سرباز با موفقیت درمان شد!`);
        playSFX('success'); playSoundFile('ghost/Collect.mp3', 0.6);
      } else if (res.status === 'army_full') { showToast('ظرفیت ارتش پر است!', 'error'); playSFX('error'); }
      else if (res.status === 'no_res') { showToast('منابع کافی نیست!', 'error'); playSFX('error'); }
      else if (res.status === 'no_wounded') { closeQuantityModal(); showToast('این سربازان دیگر زخمی نیستند. ✅'); }
      else { showToast('خطا در درمان!', 'error'); playSFX('error'); }
    } finally { releaseLock(); }
  };
  
  $('quantityModal').classList.add('show');
}

function updateHealDetails(unitKey, qty) {
  const cost = (typeof HEAL_COSTS !== 'undefined' && HEAL_COSTS[unitKey]);
  const unit = (typeof UNITS_INFO !== 'undefined' && UNITS_INFO[unitKey]);
  if (!cost || !unit) return;
  let costHtml = '';
  for (let res in cost) {
    const iconRaw = (typeof RES_ICON !== 'undefined' && RES_ICON[res]) || '';
    const iconHtml = (typeof iconHTML === 'function') ? iconHTML(iconRaw, 18, '🎁') : iconRaw;
    costHtml += `${iconHtml} ${toFa(cost[res] * qty)} ${(typeof resNames !== 'undefined' && resNames[res]) || res} | `;
  }
  const details = $('qty-details'); if (!details) return;
  details.style.display = 'block';
  details.innerHTML = `<div style="color:#ff5252; font-family:var(--font-persian); font-size:16px; margin-bottom:5px;">به میدان جنگ برمی‌گردند!</div><div>شما ${toFa(qty)} عدد ${unit.name || unitKey} را درمان می‌کنید.</div><div style="margin-top:5px;color:var(--gold);">هزینه: ${costHtml}</div>`;
  const confirmBtn = $('qty-confirm-btn'); if (confirmBtn) confirmBtn.disabled = false;
}

function confirmHealLogic(unitKey, amount) {
  if (_isBadKey(unitKey)) return { status: 'invalid' };
  amount = _bInt(amount, 0);
  if (!amount || amount <= 0) return { status: 'invalid' };
  const woundedCount = _bInt(state.hospital && state.hospital.wounded && state.hospital.wounded[unitKey], 0);
  if (woundedCount <= 0) return { status: 'no_wounded' };
  if (amount > woundedCount) amount = woundedCount;
  const maxArmy = typeof getMaxArmy === 'function' ? getMaxArmy(_bInt(state.buildings && state.buildings.barracks, 1)) : 9999;
  const curArmy = typeof getTotalArmyCount === 'function' ? getTotalArmyCount() : 0;
  const room = maxArmy - curArmy;
  if (room <= 0) return { status: 'army_full' };
  amount = Math.min(amount, room);
  if (amount <= 0) return { status: 'army_full' };
  const costBase = (typeof HEAL_COSTS !== 'undefined' && HEAL_COSTS[unitKey]);
  if (!costBase) return { status: 'invalid' };
  const totalCost = {};
  for (const res in costBase) {
    if (_isBadKey(res)) continue;
    totalCost[res] = _bNum(costBase[res], 0) * amount;
  }
  try {
    transaction(() => {
      if (!deductResources(totalCost)) throw new Error('no_res');
      const finalWounded = _bInt(state.hospital.wounded[unitKey], 0);
      if (finalWounded < amount) {
        const refundAmount = amount - finalWounded;
        for (const res in costBase) {
          if (_isBadKey(res)) continue;
          const refund = _bNum(costBase[res], 0) * refundAmount;
          if (refund > 0) {
            if (state[res] !== undefined) state[res] = _bNum(state[res], 0) + refund;
            else {
              if (!_isPlainObj(state.inventory)) state.inventory = {};
              state.inventory[res] = _bNum(state.inventory[res], 0) + refund;
            }
          }
        }
        amount = finalWounded;
      }
      if (amount <= 0) throw new Error('no_wounded');
      if (!_isPlainObj(state.army)) state.army = JSON.parse(JSON.stringify(DEFAULT_STATE.army));
      state.army[unitKey] = _bInt(state.army[unitKey], 0) + amount;
      state.hospital.wounded[unitKey] = finalWounded - amount;
      if (state.hospital.wounded[unitKey] <= 0) delete state.hospital.wounded[unitKey];
    });
  } catch (e) {
    if (e.message === 'no_res') return { status: 'no_res' };
    if (e.message === 'no_wounded') return { status: 'no_wounded' };
    return { status: 'invalid' };
  }
  if (typeof missionAdd === 'function') missionAdd('heal10', amount);
  return { status: 'ok', healed: amount };
}

// ============================================================
// 🏛️ Academy Research
// ============================================================
function researchAcademy(branch) {
  if (!acquireLock()) return;
  try {
    if (branch !== 'power' && branch !== 'gold' && branch !== 'defense') { showToast('شاخه نامعتبر!', 'error'); playSFX('error'); return; }
    if (!_isPlainObj(state.academyResearch)) state.academyResearch = { power: 0, gold: 0, defense: 0, activeResearch: { branch: null, startTime: 0, endTime: 0, targetLevel: 0 } };
    if (!_isPlainObj(state.academyResearch.activeResearch)) state.academyResearch.activeResearch = { branch: null, startTime: 0, endTime: 0, targetLevel: 0 };
    const ar = state.academyResearch.activeResearch;
    if (ar.branch !== null) { showToast('⏳ یک تحقیق در حال انجام است!', 'error'); playSFX('error'); return; }
    if (!_isPlainObj(state.inventory)) state.inventory = {};
    const currentLvl = _bInt(state.academyResearch[branch], 0);
    if (currentLvl >= 10) { showToast('این شاخه تکمیل شده است! ✅', 'error'); playSFX('error'); return; }
    const targetLevel = currentLvl + 1;
    const booksNeeded = (typeof ACADEMY_RESEARCH_COST !== 'undefined' && ACADEMY_RESEARCH_COST[targetLevel]) || 1;
    const books = _bInt(state.inventory.magicBook, 0);
    if (books < booksNeeded) { showToast(`📖 به ${toFa(booksNeeded)} کتاب جادویی نیاز داری! (داری: ${toFa(books)})`, 'error'); playSFX('error'); return; }
    const researchTime = (typeof ACADEMY_RESEARCH_TIMES !== 'undefined' && ACADEMY_RESEARCH_TIMES[targetLevel]) || (5 * 3600000);
    try {
      transaction(() => {
        state.inventory.magicBook -= booksNeeded;
        const now = Date.now();
        state.academyResearch.activeResearch = { branch: branch, startTime: now, endTime: now + researchTime, targetLevel: targetLevel };
      });
    } catch (e) { showToast('خطا در شروع تحقیق! ❌', 'error'); playSFX('error'); return; }
    updateUI(); saveGame(); updateAcademyUI();
    showToast(`🔬 تحقیق آغاز شد! (${fmtDur(researchTime)})`);
    playSFX('success');
  } finally { releaseLock(); }
}

function finishResearch() {
  if (!_isPlainObj(state.academyResearch)) return;
  if (!_isPlainObj(state.academyResearch.activeResearch)) return;
  const ar = state.academyResearch.activeResearch;
  if (!ar.branch || _bNum(ar.endTime, 0) <= 0) return;
  if (Date.now() < _bNum(ar.endTime, 0)) return;
  const branch = ar.branch;
  const targetLevel = _bInt(ar.targetLevel, 0);
  if (targetLevel <= 0 || targetLevel > 10) { state.academyResearch.activeResearch = { branch: null, startTime: 0, endTime: 0, targetLevel: 0 }; saveGame(); return; }
  try {
    transaction(() => {
      state.academyResearch[branch] = targetLevel;
      state.academyResearch.activeResearch = { branch: null, startTime: 0, endTime: 0, targetLevel: 0 };
    });
  } catch (e) { state.academyResearch.activeResearch = { branch: null, startTime: 0, endTime: 0, targetLevel: 0 }; saveGame(); return; }
  const branchName = branch === 'power' ? 'شمشیرزنی' : branch === 'gold' ? 'مالیات‌گیری' : 'معماری دفاعی';
  updateUI(); saveGame();
  showToast(`📖 تحقیق ${branchName} به سطح ${toFa(targetLevel)} رسید! ✨`);
  playSFX('success');
  if (typeof addMessage === 'function') addMessage('upgrade', '🏛️', `تحقیق ${branchName}`, `تحقیق ${branchName} به سطح ${toFa(targetLevel)} رسید.`);
  if (currentBuilding === 'academy') updateAcademyUI();
}

function speedUpResearch() {
  if (!acquireLock()) return;
  try {
    if (!_isPlainObj(state.academyResearch) || !_isPlainObj(state.academyResearch.activeResearch)) return;
    const ar = state.academyResearch.activeResearch;
    if (!ar.branch || _bNum(ar.endTime, 0) <= 0) return;
    const cost = getSpeedupCost(ar.endTime);
    let _finishNow = false;
    try {
      transaction(() => {
        if (cost > 0 && !spendGold(cost)) throw new Error('no gold');
        if (ar.endTime - Date.now() < 60000) { ar.endTime = Date.now(); _finishNow = true; }
        else { ar.endTime -= 60000; }
      });
    } catch (e) { showToast('طلا کافی نیست!', 'error'); playSFX('error'); return; }
    if (_finishNow) finishResearch();
    else { updateUI(); saveGame(); updateAcademyUI(); }
    playSFX('success');
  } finally { releaseLock(); }
}

function updateAcademyUI() {
  if (currentBuilding !== 'academy') return;
  const img = document.querySelector('.building[data-type="academy"]');
  const mb = document.querySelector('.modal-body'), keepTop = mb ? mb.scrollTop : 0;
  showModalContent('academy', img ? img.getAttribute('src') : null);
  setTimeout(() => { const nb = document.querySelector('.modal-body'); if (nb) nb.scrollTop = keepTop; }, 0);
}

// ============================================================
// 📚 Level Chest
// ============================================================

function updateCastleMessagesUI() {
  if (currentBuilding !== 'castle') return;
  const c = $('castle-dynamic-content'); if (!c) return;
  const btn = c.querySelector('button[onclick="openCastleMessages()"]');
  if (!btn) return;
  const unread = _bInt(state.msgUnread, 0);
  if (unread > 0) {
    btn.innerHTML = `${iconHTML(_ICON.message, 24, '📨')}<span>پیغام‌های سلطنتی</span><span style="background:#e53935;color:#fff;border-radius:50%;min-width:22px;height:22px;display:inline-flex;align-items:center;justify-content:center;font-size:12px;font-weight:bold;padding:0 6px;">${toFa(unread)}</span>`;
  } else {
    btn.innerHTML = `${iconHTML(_ICON.message, 24, '📨')}<span>پیغام‌های سلطنتی</span>`;
  }
}

function openCastleMessages() {
  if (!Array.isArray(state.messages)) state.messages = [];
  const typeColor = { battle: '#e57373', system: '#64b5f6', reward: '#ffd54f', upgrade: '#81c784', training: '#ffb74d' };
  const tabs = [
    { id: 'all',      icon: '📨', label: 'همه' },
    { id: 'battle',   icon: '⚔️', label: 'نبردها' },
    { id: 'upgrade',  icon: '🏗️', label: 'ارتقاها' },
    { id: 'training', icon: '⚔️', label: 'آموزش' },
    { id: 'system',   icon: '📢', label: 'سیستم' }
  ];
  
  let html = `<div style="position:fixed;inset:0;z-index:5000;background:rgba(0,0,0,0.9);backdrop-filter:blur(5px);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:15px;">
    <div style="background:linear-gradient(180deg,#1a252b,#0a1014);border:2px solid var(--gold);border-radius:15px;width:100%;max-width:450px;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 10px 40px rgba(0,0,0,0.9);">
      <div style="padding:15px;border-bottom:1px solid rgba(245,198,107,0.3);text-align:center;">
        <div style="font-family:var(--font-persian);color:var(--gold);font-size:22px;">📨 پیغام‌های سلطنتی</div>
      </div>
      <div style="display:flex;gap:4px;padding:8px 10px;border-bottom:1px solid rgba(245,198,107,0.2);overflow-x:auto;flex-shrink:0;">
        ${tabs.map(t => `<button onclick="_msgActiveTab='${t.id}';openCastleMessages();" style="flex:1;min-width:60px;padding:8px 4px;border-radius:8px;border:1px solid ${_msgActiveTab===t.id?'var(--gold)':'#333'};background:${_msgActiveTab===t.id?'linear-gradient(180deg,#b68b3c,#8a6829)':'#1a252b'};color:${_msgActiveTab===t.id?'#000':'#ccc'};font-family:var(--font-persian);font-size:12px;cursor:pointer;">${t.icon} ${t.label}</button>`).join('')}
      </div>
      <div style="flex:1;overflow-y:auto;padding:10px;display:flex;flex-direction:column;gap:8px;max-height:calc(85vh - 200px);">`;
  
  let filtered = state.messages;
  if (_msgActiveTab === 'system') {
    filtered = state.messages.filter(m => m.type === 'system' || m.type === 'reward');
  } else if (_msgActiveTab !== 'all') {
    filtered = state.messages.filter(m => m.type === _msgActiveTab);
  }
  
  if (!filtered.length) {
    html += `<div style="text-align:center;padding:40px;color:#888;">📭 هیچ پیغامی در این تب نداری</div>`;
  } else {
    const sorted = [...filtered].sort((a, b) => (b.ts || 0) - (a.ts || 0)).slice(0, 20);
    sorted.forEach(m => {
      const color = typeColor[m.type] || '#ccc';
      const date = new Date(m.ts || Date.now());
      const jDate = date.toLocaleDateString('fa-IR');
      const jTime = `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
      const isBattle = m.type === 'battle' && m.data;
      
      // ✅ پاکسازی HTML از متن پیغام برای نمایش در لیست
      const cleanBody = (m.body || '').replace(/<[^>]*>?/gm, '');

      html += `<div class="msg-card ${m.read ? 'read' : 'unread'}" style="cursor:pointer;border-color:${m.read ? 'rgba(255,255,255,0.1)' : color};" onclick="openMessageDetail('${escapeHtml(m.id)}')">
        <div class="msg-icon" style="color:${color};">${escapeHtml(m.icon || '📜')}</div>
        <div class="msg-body">
          <div class="msg-title" style="color:${color};">${escapeHtml(m.title)}</div>
          <div class="msg-text">${escapeHtml(cleanBody)}</div>
          <div class="msg-time">${jDate} • ${jTime}${m.read ? '' : ' • <span style="color:#ffd54f;">جدید</span>'}${isBattle ? ' • <span style="color:#f5c66b;">📊</span>' : ''}</div>
          
          ${isBattle ? `
            <button class="btn-buy" style="margin-top:8px; width:100%; padding:6px; font-size:12px; background:linear-gradient(180deg,#f5c66b,#c8963a); color:#000; border-radius:8px;" onclick="event.stopPropagation(); openMessageDetail('${escapeHtml(m.id)}')">
              📊 مشاهده جزئیات نبرد
            </button>
          ` : ''}
        </div>
      </div>`;
    });
  }
  
  html += `</div>
      <div style="padding:15px;display:flex;gap:8px;">
        <button onclick="markAllMessagesRead()" style="flex:1;background:linear-gradient(180deg,#64b5f6,#1976d2);color:#fff;border:none;border-radius:8px;padding:10px;font-family:inherit;font-weight:bold;cursor:pointer;">همه خوانده شد</button>
        <button onclick="closeCastleMessages()" style="flex:1;background:#a84b4b;color:#fff;border:none;border-radius:8px;padding:10px;font-family:inherit;font-weight:bold;cursor:pointer;">بستن</button>
      </div>
    </div>
  </div>`;
  
  let overlay = document.getElementById('castleMessagesOverlay');
  if (!overlay) { overlay = document.createElement('div'); overlay.id = 'castleMessagesOverlay'; document.body.appendChild(overlay); }
  overlay.innerHTML = html;
  if (typeof playSFX === 'function') playSFX('click');
}

function closeCastleMessages() {
  const overlay = document.getElementById('castleMessagesOverlay');
  if (overlay) overlay.remove();
}

function openMessageDetail(id) {
  if (typeof id !== 'string' || !id) return;
  if (!Array.isArray(state.messages)) return;
  const msg = state.messages.find(m => m.id === id);
  if (!msg) return;
  if (!msg.read) {
    msg.read = true;
    state.msgUnread = state.messages.filter(x => !x.read).length;
    if (typeof saveGame === 'function') saveGame();
    updateCastleMessagesUI();
  }
  if (msg.type === 'battle' && _isPlainObj(msg.data)) {
    closeCastleMessages();
    if (typeof showBattleResult === 'function') showBattleResult(msg.data);
    return;
  }
  openCastleMessages();
}

function markAllMessagesRead() {
  if (!Array.isArray(state.messages)) return;
  state.messages.forEach(m => { m.read = true; });
  state.msgUnread = 0;
  if (typeof saveGame === 'function') saveGame();
  updateCastleMessagesUI();
  openCastleMessages();
}

// ============================================================
// 🗼 Watchtower — Fallback (peace.js override می‌کند)
// ============================================================
if (typeof window !== 'undefined' && typeof window.updatePeaceTreatyUI !== 'function') {
  window.updateWatchtowerUI = function() {
    if (currentBuilding !== 'watchtower') return;
    const c = $('watchtower-dynamic-content'); if (!c) return;
    c.innerHTML = `<div class="farm-ui"><div class="level-text">🗼 برج مراقبت</div><div style="color:#aaa;text-align:center;padding:20px;">این بخش توسط peace.js مدیریت می‌شود. لطفاً peace.js را لود کنید.</div></div>`;
  };
}