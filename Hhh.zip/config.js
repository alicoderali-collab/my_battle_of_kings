// ============================================================
// ⚔️ BATTLE OF KINGS - js/config.js (v6 - MASTER FINAL)
// All phases 1-6 | All configs | No bugs
// ============================================================

// ============================================================
// 🌐 Globals
// ============================================================
const $ = id => document.getElementById(id);
const DEBUG = location.hash === '#debug';
const buzz = p => { try { navigator.vibrate && navigator.vibrate(p); } catch (e) {} };

// ============================================================
// ⏱️ Battle & Economy Constants
// ============================================================
const BATTLE_COOLDOWN_MS = 600000;
const BOSS_COOLDOWNS_MS = [30*60000, 60*60000, 2*3600000, 4*3600000, 6*3600000, 12*3600000, 18*3600000, 24*3600000, 72*3600000, 168*3600000];
const BATTLE_DURATION_MS = 180000;
const TAX_COOLDOWN_MS = 60000;
const TAX_CAP_MINUTES = 60;
const SPEEDUP_GOLD_PER_MIN = 120;

// ============================================================
// 🗼 Watchtower Legacy Config (برای سازگاری با sanitizeState)
// ============================================================
const WATCHTOWER_CONFIG = {
  scoutCost: 50,
  scoutDuration: 30 * 60 * 1000,
  scoutDurationPerLevel: 5 * 60 * 1000,
  maxScoutDuration: 60 * 60 * 1000,
  scoutCooldown: 5 * 60 * 1000,
  patrolCost: 200,
  patrolDuration: 2 * 60 * 60 * 1000,
  patrolDefenseBonus: 0.15,
  patrolXPBonus: 0.05,
  maxAlerts: 20,
  alertMaxAge: 7 * 24 * 60 * 60 * 1000
};

// ============================================================
// 🕊️ Peace Treaty Configuration (فاز ۱)
// ============================================================
const PEACE_TREATY_CONFIG = {
  costPerHour: 50,
  wallPerTreaty: 1,
  durations: [1, 5, 10, 24, 48, 72],
  maxDuration: 72
};

// ============================================================
// 🛡️ Equipment Defense Values (فاز ۱)
// ============================================================
const EQUIPMENT_DEFENSE = {
  wall: 2,
  catapult: 10
};

// ============================================================
// 🏛️ Academy Research Times & Costs (فاز ۵)
// ============================================================
const ACADEMY_RESEARCH_TIMES = {
  1:  5   * 3600000,
  2:  10  * 3600000,
  3:  18  * 3600000,
  4:  28  * 3600000,
  5:  40  * 3600000,
  6:  55  * 3600000,
  7:  70  * 3600000,
  8:  85  * 3600000,
  9:  105 * 3600000,
  10: 130 * 3600000
};

const ACADEMY_RESEARCH_COST = {
  1: 1, 2: 1, 3: 2, 4: 2, 5: 2,
  6: 3, 7: 3, 8: 3, 9: 4, 10: 5
};

// ============================================================
// 🖼️ PNG Icons
// ============================================================
const _ICON = {
  wood:       'ghost/ic_wood.png',
  azooghe:    'ghost/ic_food.png',
  stone:      'ghost/ic_ston.png',
  iron:       'ghost/ic_iron.png',
  coal:       'ghost/ic_cool.png',
  diamond:    'ghost/ic_dimond.png',
  steel:      'ghost/ic_steel.png',
  wall:       'ghost/ic_wall.png',
  timer:      'ghost/ic_timer.png',
  message:    'ghost/ic_message.png',
  chestDay:   'ghost/chest_for_upg_player.png',
  gold:       'ghost/coin.jpg',
  crystal:    'ghost/cristal.png',
  spear:      'ghost/ic_spear.png',
  helmet:     'ghost/ic_helmet.png',
  shield:     'ghost/ic_shield.png',
  armor:      'ghost/ic_armor.png',
  horseArmor: 'ghost/ic_horsearmor.png',
  bow:        'ghost/ic_bow.png',
  arrow:      'ghost/ic_arrow.png',
  staff:      'ghost/ic_staff.png',
  catapult:   'ghost/ic_catapult.png',
  kamanTest: 'ghost/kaman_ic.png',
  magicBook:  'ghost/book.png',
  ironKey: 'ghost/ic_iron.png', goldKey: 'ghost/coin.jpg', purpleKey: 'ghost/cristal.png'
};

// ============================================================
// 🏛️ Buildings
// ============================================================
const BUILDINGS_INFO = {
  castle:     { name: 'قلعه سلاطین', baseCost: { gold: 200, wood: 100, stone: 50 }, bg: 'castle_bg.png' },
  farm:       { name: 'مزرعه', baseCost: { gold: 50, wood: 30, stone: 0 }, bg: 'farm_bg.png' },
  lumber:     { name: 'چوب‌بری', baseCost: { gold: 60, wood: 0, stone: 10 }, bg: 'wood_bg.png' },
  mine:       { name: 'معدن', baseCost: { gold: 80, wood: 40, stone: 20 }, bg: 'main_bg.png' },
  barracks:   { name: 'سربازخانه', baseCost: { gold: 150, wood: 80, iron: 50 }, bg: 'sarbaz_bg.png' },
  academy:    { name: 'معبد', baseCost: { gold: 120, wood: 60, stone: 40 }, bg: 'bg_ghasr.png' },
  hospital:   { name: 'بیمارستان', baseCost: { gold: 100, wood: 50, stone: 20 }, bg: 'bimarestan_bg.png' },
  watchtower: { name: 'برج مراقبت', baseCost: { gold: 100, wood: 70, stone: 80 }, bg: 'tower_bg.png' },
  smith:      { name: 'آهنگری', baseCost: { gold: 120, wood: 50, iron: 60 }, bg: 'iron_bg.png' },
  wall:       { name: 'دیوار دفاعی', baseCost: { gold: 90, wood: 60, stone: 40 }, bg: 'main_bg.png' }
};

// ============================================================
// ⚒️ Smith Recipes
// ============================================================
const SMITH_RECIPES = {
  iron:       { name: 'آهن', icon: _ICON.iron, cost: { stone: 10, coal: 1 }, time: 4000 },
  steel:      { name: 'فولاد', icon: _ICON.steel, cost: { iron: 3, coal: 1 }, time: 4000 },
  spear:      { name: 'نیزه', icon: _ICON.spear, cost: { steel: 2, wood: 10 }, time: 8000 },
  helmet:     { name: 'کلاه‌خود', icon: _ICON.helmet, cost: { steel: 2, gold: 1 }, time: 12000 },
  shield:     { name: 'سپر', icon: _ICON.shield, cost: { steel: 3, wood: 15 }, time: 16000 },
  armor:      { name: 'زره', icon: _ICON.armor, cost: { steel: 5, gold: 2 }, time: 25000 },
  horseArmor: { name: 'زره اسب', icon: _ICON.horseArmor, cost: { steel: 6, gold: 3, iron: 10 }, time: 42000 }
};

// ============================================================
// 🪚 Lumber Recipes
// ============================================================
const LUMBER_RECIPES = {
  bow:      { name: 'کمان', icon: _ICON.bow, cost: { wood: 10, iron: 1 }, time: 8000 },
  arrow:    { name: 'تیر', icon: _ICON.arrow, cost: { spear: 1, wood: 1 }, time: 4000 },
  staff:    { name: 'عصای جادو', icon: _ICON.staff, cost: { wood: 2, diamond: 1 }, time: 12000 },
  wall:     { name: 'دیوار چوبی', icon: _ICON.wall, cost: { wood: 40, steel: 2, spear: 3 }, time: 21000 },
  catapult: { name: 'منجنیق', icon: _ICON.catapult, cost: { wood: 25, iron: 5, stone: 12, azooghe: 3 }, time: 42000 }
};

// ============================================================
// 📝 Resource Names (Persian)
// ============================================================
const resNames = {
  stone: 'سنگ', coal: 'زغال', wood: 'چوب', gold: 'طلا', iron: 'آهن',
  azooghe: 'آذوغه', diamond: 'الماس', crystal: 'کریستال سلطنتی', steel: 'فولاد', spear: 'نیزه',
  helmet: 'کلاه‌خود', shield: 'سپر', armor: 'زره', horseArmor: 'زره اسب',
  bow: 'کمان', arrow: 'تیر', staff: 'عصا', wall: 'دیوار', catapult: 'منجنیق',
  magicBook: 'کتاب جادویی', ironKey: 'کلید آهنی', goldKey: 'کلید طلایی', purpleKey: 'کلید بنفش',
  speedup_1m: 'تسریع ۱ دقیقه', speedup_10m: 'تسریع ۱۰ دقیقه',
  speedup_1h: 'تسریع ۱ ساعت', speedup_1d: 'تسریع ۱ روز'
};

// ============================================================
// ⚔️ Units
// ============================================================
const UNITS_INFO = {
  spearman: {
    name: 'نیزه‌دار', img: 'ghost/neizedar.png', power: 30,
    trainTime: 10000, reqBarracksLevel: 1,
    cost: { gold: 2, azooghe: 5, spear: 1, shield: 1, helmet: 1 }
  },
  archer: {
    name: 'کماندار', img: 'ghost/kamandar.png', power: 55,
    trainTime: 20000, reqBarracksLevel: 2,
    cost: { gold: 3, azooghe: 5, bow: 1, arrow: 3, helmet: 1 }
  },
  cavalry: {
    name: 'سواره‌نظام', img: 'ghost/savarenezam.png', power: 70,
    trainTime: 30000, reqBarracksLevel: 3,
    cost: { gold: 5, azooghe: 10, horseArmor: 1, spear: 1, armor: 1 }
  },
  wizard: {
    name: 'جادوگر', img: 'ghost/jadogar.png', power: 100,
    trainTime: 60000, reqBarracksLevel: 5,
    cost: { gold: 20, azooghe: 15, staff: 1, armor: 2, diamond: 3 }
  }
};

// ============================================================
// 🏥 Heal Costs
// ============================================================
const HEAL_COSTS = {
  spearman: { azooghe: 5, spear: 1, iron: 2 },
  archer:   { azooghe: 5, bow: 1, steel: 1 },
  cavalry:  { azooghe: 10, wood: 1, steel: 3 },
  wizard:   { azooghe: 6, diamond: 1, gold: 1 }
};

// ============================================================
// 👑 Profiles
// ============================================================
const profilesData = [
  { id: 'castle', name: 'قلعه (پیش‌فرض)', img: 'ghost/castle.png', cost: 0 },
  { id: 'knight', name: 'شوالیه', img: 'ghost/knight.jpg', cost: 500 },
  { id: 'doktor', name: 'مرگ', img: 'ghost/doktor.jpg', cost: 800 },
  { id: 'blood',  name: 'شیطان', img: 'ghost/blood.jpg', cost: 1200 },
  { id: 'king',   name: 'فرمانروا', img: 'ghost/kingn.jpg', cost: 2000 },
  { id: 'wich',   name: 'جادوگر', img: 'ghost/wich.jpg', cost: 1500 },
  { id: 'robot',  name: 'ربات', img: 'ghost/robot.jpg', cost: 2500 }
];

// ============================================================
// 🎨 Resource Icons (mapped to PNG)
// ============================================================
const RES_ICON = {
  gold:       _ICON.gold,
  wood:       _ICON.wood,
  azooghe:    _ICON.azooghe,
  stone:      _ICON.stone,
  iron:       _ICON.iron,
  coal:       _ICON.coal,
  diamond:    _ICON.diamond,
  steel:      _ICON.steel,
  crystal:    _ICON.crystal,
  spear:      _ICON.spear,
  helmet:     _ICON.helmet,
  shield:     _ICON.shield,
  armor:      _ICON.armor,
  horseArmor: _ICON.horseArmor,
  bow:        _ICON.bow,
  arrow:      _ICON.arrow,
  staff:      _ICON.staff,
  wall:       _ICON.wall,
  catapult:   _ICON.catapult,
  magicBook:  _ICON.magicBook,
  speedup_1m:  _ICON.timer,
  speedup_10m: _ICON.timer,
  speedup_1h:  _ICON.timer,
  speedup_1d:  _ICON.timer,
  ironKey: _ICON.ironKey, goldKey: _ICON.goldKey, purpleKey: _ICON.purpleKey
};

// ============================================================
// 🐉 Enemies (10 enemies / 10 levels)
// ============================================================
const ENEMIES = [
  { name: 'راهزنان', icon: '🏴‍☠️', power: 100, minLevel: 1, reward: { gold: 80, wood: 40 }, img: 'ghost/rahzanan.jpg', lore: 'گروهی از راهزنان بی‌رحم که به کاروان‌های تجاری حمله می‌کنند.' },
  { name: 'اورک‌های وحشی', icon: '👹', power: 500, minLevel: 2, reward: { gold: 200, wood: 100 }, img: 'ghost/everek.jpg', lore: 'اورک‌های خونخوار که با گرزهای سنگین به دهکده‌ها هجوم می‌آورند.' },
  { name: 'غول‌های برفی', icon: '❄️', power: 3000, minLevel: 3, reward: { gold: 700, stone: 100 }, img: 'ghost/gholbarfi.jpg', lore: 'غول‌های وحشی که از کوهستان‌های یخی پایین می‌آیند.' },
  { name: 'سواران سرگردان', icon: '🐎', power: 5500, minLevel: 4, reward: { gold: 1200, diamond: 2 }, img: 'ghost/savare_sargardan.jpg', lore: 'سواران صحراگرد که در جستجوی جنگ و غنیمت، در سرزمین‌ها پرسه می‌زنند.' },
  { name: 'مومیایی‌های نفرین‌شده', icon: '🧟', power: 9000, minLevel: 5, reward: { gold: 2000, diamond: 3 }, img: 'ghost/momiaii.jpg', lore: 'اجساد کهنی که با جادوی سیاه زنده شده‌اند.' },
  { name: 'غول‌های جنگلی', icon: '🌲', power: 15000, minLevel: 6, reward: { gold: 3500, crystal: 1 }, img: 'ghost/gholjangali.jpg', lore: 'موجودات عظیم‌الجثه‌ای که در جنگل‌های تاریک پنهان شده‌اند.' },
  { name: 'شیاطین جهنم', icon: '🔥', power: 25000, minLevel: 7, reward: { gold: 5000, crystal: 2 }, img: 'ghost/shayatin.jpg', lore: 'شیاطین آتشینی که از دروازه‌های جهنم بیرون آمده‌اند.' },
  { name: 'جادوگر اعظم (باس)', icon: '🧙‍♂️', power: 45000, minLevel: 8, reward: { gold: 10000, diamond: 15, crystal: 5 }, img: 'ghost/jadogar.jpg', lore: 'جادوگری قدرتمند که با طلسم‌های سیاه، ارتش‌ها را از بین می‌برد.' },
  { name: 'دنیای وارونه (باس)', icon: '👑', power: 70000, minLevel: 9, reward: { gold: 20000, diamond: 25, crystal: 10 }, img: 'ghost/donyayevarone_final.jpg', lore: 'فرمانروای تاریکی از دنیای وارونه.' },
  { name: 'اژدهای کهن (سخت‌ترین باس)', icon: '🐉', power: 100000, minLevel: 10, reward: { gold: 50000, diamond: 50, crystal: 20 }, img: 'ghost/final_dragon.png', lore: 'اژدهای عظیم‌الجثه‌ای که آسمان را به آتش می‌کشد.' }
];

// ============================================================
// 📜 Missions
// ============================================================
const MISSIONS = [
  { id: 'harvest', tier: 'beginner', icon: '🧺', title: '۳ بار از منابع برداشت کن', target: 3 },
  { id: 'collectTax2', tier: 'beginner', icon: '🏰', title: '۲ بار مالیات قلعه را جمع‌آوری کن', target: 2 },
  { id: 'recruit5', tier: 'beginner', icon: '🛡️', title: '۵ سرباز آموزش بده', target: 5 },
  { id: 'upgrade1', tier: 'beginner', icon: '🏗️', title: '۱ ساختمان را ارتقا بده', target: 1 },
  { id: 'pveAttack', tier: 'beginner', icon: '⚔️', title: '۱ بار به دشمن PvE حمله کن', target: 1 },

  { id: 'win3', tier: 'intermediate', icon: '🏆', title: '۳ نبرد را پیروز شو', target: 3 },
  { id: 'craft10', tier: 'intermediate', icon: '⚒️', title: '۱۰ آیتم در آهنگری یا چوب‌بری بساز', target: 10 },
  { id: 'heal10', tier: 'intermediate', icon: '🩹', title: '۱۰ سرباز زخمی را درمان کن', target: 10 },
  { id: 'spend2000', tier: 'intermediate', icon: '💸', title: '۲٬۰۰۰ طلا خرج کن', target: 2000 },
  { id: 'mine5', tier: 'intermediate', icon: '⛏️', title: '۵ بار معدن را پر و برداشت کن', target: 5 },
  { id: 'peace24', tier: 'intermediate', icon: '🕊️', title: 'پیمان صلح ۲۴ ساعته فعال کن', target: 1 },
  { id: 'collect10000', tier: 'intermediate', icon: '🪙', title: '۱۰٬۰۰۰ طلا جمع‌آوری کن', target: 10000 },

  { id: 'dragon', tier: 'special', icon: '🐉', title: 'اژدهای کهن را شکست بده', target: 1 },
  { id: 'win5', tier: 'special', icon: '👑', title: '۵ نبرد را پیروز شو', target: 5 },
  { id: 'siegeBuild', tier: 'special', icon: '🧱', title: '۲ منجنیق یا معادل ۵ دیوار چوبی بساز', target: 2 },
  { id: 'exchange100', tier: 'special', icon: '💎', title: '۱۰۰ الماس در صرافی تبدیل کن', target: 100 },
  { id: 'upgrade10', tier: 'special', icon: '🏗️', title: '۱۰ ساختمان را ارتقا بده', target: 10 },
  { id: 'tax50', tier: 'special', icon: '🏰', title: '۵۰ بار مالیات قلعه را جمع‌آوری کن', target: 50 }
];

// ============================================================
// 🛒 Shop Items (فاز ۵: حذف special + قیمت تسریع جدید)
// ============================================================
const SHOP_ITEMS = {
  resources: [
    { name: '۱,۰۰۰ چوب',   icon: _ICON.wood,    cost: { gold: 150 },   give: { wood: 1000 } },
    { name: '۱,۰۰۰ سنگ',   icon: _ICON.stone,   cost: { gold: 150 },   give: { stone: 1000 } },
    { name: '۱,۰۰۰ آذوغه', icon: _ICON.azooghe, cost: { gold: 150 },   give: { azooghe: 1000 } },
    { name: '۵۰۰ آهن',     icon: _ICON.iron,    cost: { gold: 300 },   give: { iron: 500 } },
    { name: '۵۰۰ زغال',    icon: _ICON.coal,    cost: { gold: 300 },   give: { coal: 500 } },
  ],
  speedups: [
    { name: 'تسریع ۱ دقیقه',  icon: _ICON.timer, cost: { diamond: 1 },              give: { inv: 'speedup_1m', n: 1 } },
    { name: 'تسریع ۱۰ دقیقه', icon: _ICON.timer, cost: { diamond: 7 },              give: { inv: 'speedup_10m', n: 1 } },
    { name: 'تسریع ۱ ساعت',   icon: _ICON.timer, cost: { diamond: 30, gold: 10 },   give: { inv: 'speedup_1h', n: 1 } },
    { name: 'تسریع ۱ روز',    icon: _ICON.timer, cost: { crystal: 1, diamond: 20 }, give: { inv: 'speedup_1d', n: 1 } }
  ]
};

// ============================================================
// ⏱️ Speedup Items
// ============================================================
const SPEEDUP_ITEMS = {
  speedup_1m:  { ms: 60000,    name: 'تسریع ۱ دقیقه',  icon: _ICON.timer },
  speedup_10m: { ms: 600000,   name: 'تسریع ۱۰ دقیقه', icon: _ICON.timer },
  speedup_1h:  { ms: 3600000,  name: 'تسریع ۱ ساعت',   icon: _ICON.timer },
  speedup_1d:  { ms: 86400000, name: 'تسریع ۱ روز',    icon: _ICON.timer }
};

// ============================================================
// 📦 Crates (بدون guarantee - ۱۰۰٪ شانسی)
// ============================================================
const CRATE_DEFS = {
  bronze: { name: 'صندوق برنز', icon: 'ghost/chest1.png', key: 'ironKey',
    pool: [
      { w: 50, res: 'gold', n: 200 }, { w: 35, res: 'azooghe', n: 500 },
      { w: 15, inv: 'spear', n: 3 }
    ] },
  silver: { name: 'صندوق نقره', icon: 'ghost/chest2.png', key: 'goldKey',
    pool: [
      { w: 45, res: 'steel', n: 20 }, { w: 30, inv: 'helmet', n: 3 },
      { w: 15, inv: 'shield', n: 3 }, { w: 10, inv: 'speedup_1h', n: 1 }
    ] },
  gold: { name: 'صندوق افسانه‌ای', icon: 'ghost/ultrachest.png', key: 'purpleKey',
    pool: [
      { w: 45, inv: 'speedup_1h', n: 2 }, { w: 25, res: 'diamond', n: 5 },
      { w: 15, inv: 'catapult', n: 1 }, { w: 10, inv: 'speedup_1d', n: 1 },
      { w: 5, res: 'gold', n: 15000 }
    ] }
};

// ============================================================
// 💳 Diamond Packages — 7 تومانی (فاز ۵)
// ============================================================
const DIAMOND_PACKAGES = [
  { id: 'dia_100',   name: 'بسته شروع',      amount: 100,   bonusGold: 100,   price: 20000,   discount: 0  },
  { id: 'dia_300',   name: 'بسته ماجراجو',    amount: 300,   bonusGold: 500,   price: 55000,   discount: 8  },
  { id: 'dia_1000',  name: 'بسته حرفه ای', amount: 1000,  bonusGold: 700,   price: 149000,  discount: 25 },
  { id: 'dia_2000',  name: 'بسته فرمانده',    amount: 2000,  bonusGold: 2000,  price: 259000,  discount: 35, bonusCrystal: 3  },
  { id: 'dia_3000',  name: 'بسته امپراتور',   amount: 3000,  bonusGold: 5000,  price: 349000,  discount: 42, bonusCrystal: 10 },
  { id: 'dia_5000',  name: 'بسته سلطان',      amount: 5000,  bonusGold: 10000, price: 499000,  discount: 50, bonusCrystal: 30 },
  { id: 'dia_10000', name: 'بسته افسانه‌ای', amount: 10000, bonusGold: 30000, price: 899000,  discount: 55, bonusCrystal: 50 }
];

// ============================================================
// 💳 Gold Packages — 9 تومانی (فاز ۵)
// ============================================================
const GOLD_PACKAGES = [
  { id: 'gold_100',    name: 'کیف پول',        amount: 100,    price: 10000,    discount: 0  },
  { id: 'gold_500',    name: 'صندوقچه',        amount: 500,    price: 45000,    discount: 10 },
  { id: 'gold_1000',   name: 'گنج کوچک',       amount: 1000,   price: 80000,    discount: 20 },
  { id: 'gold_2000',   name: 'گنج بزرگ',       amount: 2000,   price: 149000,   discount: 25 },
  { id: 'gold_5000',   name: 'خزانه',          amount: 5000,   price: 349000,   discount: 30 },
  { id: 'gold_10000',  name: 'خزانه سلطنتی',   amount: 10000,  price: 649000,   discount: 35 },
  { id: 'gold_50000',  name: 'ثروت پادشاه',    amount: 50000,  price: 2999000,  discount: 40 },
  { id: 'gold_100000', name: 'گنج افسانه‌ای', amount: 100000, price: 5499000,  discount: 45, bonusCrystal: 10 },
  { id: 'gold_300000', name: 'خدای ثروت',     amount: 300000, price: 14999000, discount: 50, bonusCrystal: 30 }
];